import 'package:google_maps_flutter/google_maps_flutter.dart';

class TripDetails {
  String destinationAddress;
  String pickupAddress;
  LatLng pickup;
  LatLng destination;
  String rideID;
  String rideType;
  String paymentMethod;
  String riderName;
  String riderPhone;

  TripDetails(
      {this.pickupAddress = '',
      this.rideID = '',
      this.rideType = '',
      this.destinationAddress = '',
      this.destination  = const LatLng(24.860966, 66.990501),
      this.pickup  = const LatLng(24.860966, 66.990501),
      this.paymentMethod = '',
      this.riderName = '',
      this.riderPhone = ''});
}

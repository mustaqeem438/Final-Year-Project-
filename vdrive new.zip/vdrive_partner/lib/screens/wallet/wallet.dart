import 'dart:async';
import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/screens/wallet/howToPay.dart';
import 'package:vdriver_partner/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:vdriver_partner/statics.dart' as appcolors;

class Wallet extends StatefulWidget {
  const Wallet({Key? key}) : super(key: key);
  static const String id = 'wallet';

  @override
  State<Wallet> createState() => _WalletState();
}

class _WalletState extends State<Wallet> {
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  Timer? timer;
  String selected = 'bank';

  // Controllers
  var bankNameController = TextEditingController();
  var accountNumberController = TextEditingController();
  var accountTitleController = TextEditingController();
  var ibanNumberController = TextEditingController();

  @override
  void initState() {
    super.initState();

    bankNameController.text = bankName!;
    accountNumberController.text = accountNumber!;
    ibanNumberController.text = ibanNumber!;
    accountTitleController.text = accountTitle!;

    // Repeating Function
    // if (!mounted) return;
    // timer = Timer.periodic(
    //   repeatTime,
    //   (Timer t) => setState(() {
    //     MainController.checkEarning();
    //     MainController.dueBalance();
    //   }),
    // );
  }

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      MainController.checkEarning();
      MainController.dueBalance();
    });
  }

  @override
  void dispose() {
    super.dispose();
    bankNameController.dispose();
    accountNumberController.dispose();
    ibanNumberController.dispose();
    accountTitleController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      key: refreshKey,
      onRefresh: refreshList,
      color: appcolors.secondaryColorSharp,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'My Wallet',
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: appcolors.dashboardBG,
          elevation: 0.0,
          toolbarHeight: 70,
          leading: IconButton(
            onPressed: () {
              setState(() {
                Navigator.pop(context);
              });
            },
            icon: const Icon(
              FeatherIcons.arrowLeft,
              color: Colors.black,
            ),
          ),
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              Container(
                decoration: const BoxDecoration(
                  borderRadius:
                      BorderRadius.only(bottomRight: Radius.circular(50)),
                  image: DecorationImage(
                    image: AssetImage("images/drawerbg.jpg"),
                    fit: BoxFit.cover,
                  ),
                ),
                width: double.infinity,
                height: 100,
                child: Stack(
                  children: [
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                          top: 10,
                        ),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text(
                                      'Current Earnings',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: appcolors.primaryColorblue,
                                      ),
                                    ),
                                    earningDataLoading
                                        ? const DataLoadedProgress()
                                        : Text(
                                            '$currencySymbol${UserPreferences.getUserEarning() ?? getUserEarning}',
                                            style: const TextStyle(
                                              color: appcolors.primaryColorblue,
                                              fontSize: 30,
                                              fontFamily: 'Brand-Bold',
                                            ),
                                          ),
                                  ],
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 0,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 30,
                                    ),
                                    child: Row(
                                      children: [
                                        const Text(
                                          'Due Balance',
                                          style: TextStyle(
                                            color: Colors.red,
                                            fontSize: 15,
                                            fontFamily: 'Brand-Bold',
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Text(
                                          '$currencySymbol${dueBalanceValue.toInt()}',
                                          style: const TextStyle(
                                            color: Colors.red,
                                            fontSize: 15,
                                            fontFamily: 'Brand-Bold',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 15,
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height * .68,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    children: [
                      const SizedBox(height: 20),
                      dueBalanceValue.toInt() > dueLimit!
                          ? const Text(
                              'Account is on Hold',
                              style: TextStyle(
                                color: Colors.red,
                                fontFamily: 'Roboto-Bold',
                              ),
                              textAlign: TextAlign.center,
                            )
                          : const SizedBox(),
                      dueBalanceValue < dueLimit!
                          ? const SizedBox()
                          : Text(
                              'Current Due Balance is exceed the limit of ${dueLimit!.toInt()}',
                              style: const TextStyle(
                                color: Colors.red,
                              ),
                              textAlign: TextAlign.center,
                            ),
                      const SizedBox(height: 10),
                      const Text(
                        'Pay Now To Get More Orders',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          InkWell(
                            onTap: () {
                              selected = 'bank';
                              bankNameController.text = bankName!;
                              accountNumberController.text = accountNumber!;
                              ibanNumberController.text = ibanNumber!;
                              accountTitleController.text = accountTitle!;
                            },
                            child: Column(
                              children: [
                                Image.asset(
                                  'images/bankpay.png',
                                  width: 60,
                                ),
                                selected == 'bank'
                                    ? const Icon(Icons.arrow_drop_down)
                                    : const SizedBox(),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const Text(
                              'Bank Name:',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextField(
                              readOnly: true,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.all(0),
                              ),
                              controller: bankNameController,
                              textAlign: TextAlign.start,
                            ),
                            const Text(
                              'Account Title:',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextField(
                              readOnly: true,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.all(0),
                                border: InputBorder.none,
                              ),
                              textAlign: TextAlign.start,
                              controller: accountTitleController,
                            ),
                            const Text(
                              'Account Number:',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextField(
                              readOnly: true,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.all(0),
                                border: InputBorder.none,
                              ),
                              textAlign: TextAlign.start,
                              controller: accountNumberController,
                            ),
                            ibanNumberController.text != ''
                                ? const Text(
                                    'IBAN Number:',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : const SizedBox(),
                            ibanNumberController.text != ''
                                ? TextField(
                                    readOnly: true,
                                    decoration: const InputDecoration(
                                      contentPadding: EdgeInsets.all(0),
                                      border: InputBorder.none,
                                    ),
                                    textAlign: TextAlign.start,
                                    controller: ibanNumberController,
                                  )
                                : const SizedBox(),
                          ],
                        ),
                      ),
                      const Divider(
                        color: Colors.black26,
                      ),
                      MaterialButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const HowToPay()),
                          );
                        },
                        height: 50,
                        color: appcolors.primaryColorblue,
                        textColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: const Text(
                          'How to Pay?',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/helpers/pushnotificationservice.dart';
import 'package:vdriver_partner/models/driver.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/screens/bookings.dart';
import 'package:vdriver_partner/screens/earnings.dart';
import 'package:vdriver_partner/screens/mapPage.dart';
import 'package:vdriver_partner/widget/ProfileBottomSheet.dart';
import 'package:vdriver_partner/widget/appDrawer.dart';
import 'package:vdriver_partner/widget/bottomNav.dart';
import '../globalvariable.dart';
import '../widget/DataLoadedProgress.dart';
import '../widget/brandDivider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../statics.dart' as Static;
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import '../permissions.dart';

class HomePage extends StatefulWidget {
  static const String id = 'HomePage';

  final String? currentScreen;
  final int? currentTab;

  const HomePage({Key? key, this.currentScreen, this.currentTab})
      : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  var refreshKey = GlobalKey<RefreshIndicatorState>();

  String? getUserName = '';
  String? getuserPhone = '';
  String? getcarRate = '';
  String? getcarColor = '';
  String? getcarModel = '';
  String? getcarNmbr = '';
  String? getUserEarning = '';
  var bounusReach;
  bool bonusDataLoading = true;
  String? availability = 'You\'re Offline';

  void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
      setState(() {
        if (CurrentDriverInfo?.fullName.toString() == null) {
          getUserName = UserPreferences.getUsername() ?? '';
        } else {
          getUserName = CurrentDriverInfo?.fullName.toString();
          UserPreferences.setUsername(getUserName!);
        }
        if (CurrentDriverInfo?.phone.toString() == null) {
          getuserPhone = UserPreferences.getUserPhone() ?? '';
        } else {
          getuserPhone = CurrentDriverInfo?.phone.toString();
          UserPreferences.setUserPhone(getuserPhone!);
        }
        if (CurrentDriverInfo?.carRate.toString() == null) {
          getcarRate = UserPreferences.getUserCarRate() ?? '';
        } else {
          getcarRate = CurrentDriverInfo?.carRate.toString();
          UserPreferences.setUserCarRate(getcarRate!);
        }

        if (CurrentDriverInfo?.carColor.toString() == null) {
          getcarColor = UserPreferences.getUserCarColor() ?? '';
        } else {
          getcarColor = CurrentDriverInfo?.carColor.toString();
          UserPreferences.setUserCarColor(getcarColor!);
        }

        if (CurrentDriverInfo?.newtrip.toString() == 'waiting' ||
            CurrentDriverInfo?.newtrip.toString() == 'timeout' ||
            CurrentDriverInfo?.newtrip.toString() == 'cancelled' ||
            CurrentDriverInfo?.newtrip.toString() == 'ended') {
          MainController.enableHomTabLocationUpdates();
        }

        final newRideRef = FirebaseDatabase.instance
            .ref()
            .child('drivers')
            .child(currentFirebaseUser!.uid)
            .child('newtrip');

        newRideRef.set('waiting');

        // if (CurrentDriverInfo?.carModel.toString() == null) {
        //   getcarModel = UserPreferences.getUserCarModel() ?? '';
        // } else {
        //   getcarModel = CurrentDriverInfo?.carModel.toString();
        //   UserPreferences.setUserCarModel(getcarModel!);
        // }

        // if (CurrentDriverInfo?.vehicleNumber.toString() == null) {
        //   getcarNmbr = UserPreferences.getUserCarNmbr() ?? '';
        // } else {
        //   getcarNmbr = CurrentDriverInfo?.vehicleNumber.toString();
        //   UserPreferences.setUserCarNmbr(getcarNmbr!);
        // }
      });
    });
  }

  void checkAvailability() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    if (currentFirebaseUser != null) {
      String? userid = currentFirebaseUser?.uid;

      final UserRef =
          FirebaseDatabase.instance.ref().child("drivers").child(userid!);
      UserRef.once().then((e) async {
        final DataSnapshot = e.snapshot;

        CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
        if (!mounted) return;
        setState(() {
          if (CurrentDriverInfo?.newtrip.toString() == 'waiting' ||
              CurrentDriverInfo?.newtrip.toString() == 'timeout' ||
              CurrentDriverInfo?.newtrip.toString() == 'cancelled' ||
              CurrentDriverInfo?.newtrip.toString() == 'ended') {
            MainController.enableHomTabLocationUpdates();
            availability = "You're Online";
          } else {
            availability = "You're Offline";
          }
        });
      });
    }
  }

  void checkEarning() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;
    final UserRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);

    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
      String getEarning = DataSnapshot.child('earnings').value.toString();
      setState(() {
        if (getEarning == null) {
          if (UserPreferences.getUserEarning() != null) {
            getUserEarning = UserPreferences.getUserEarning();
          } else {
            getUserEarning = '';
          }
        } else {
          getUserEarning = getEarning;
          UserPreferences.setUserEarning(getUserEarning!);
        }
      });
    });
  }

  //  Check if Partner reached a bonus level
  Future<void> validateBounusReach() async {
    //
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final bounusRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('history');
    bounusRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      bonusDataLoading = false;
      bounusReach = DataSnapshot.children.length;

      print(bounusReach > 1 ? 'two' : 'none');
    });
  }

  //   Initialization
  @override
  void initState() {
    super.initState();
    locationPermision();
    getUserInfo();
    validateBounusReach();
    checkEarning();
    MainController.enableHomTabLocationUpdates();
    PushNotificationService pushNotificationService = PushNotificationService();

    pushNotificationService.initialize(context);
    pushNotificationService.getToken();
  }

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      locationPermision();
      getUserInfo();
      validateBounusReach();
      checkAvailability();
      checkEarning();
      MainController.enableHomTabLocationUpdates();
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    checkAvailability();
  }

  @override
  Widget build(BuildContext context) {
    // checkAvailability();
    return RefreshIndicator(
      key: refreshKey,
      onRefresh: refreshList,
      color: Static.secondaryColorSharp,
      child: Scaffold(
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: Static.dashboardBG,
        // drawer: const SizedBox(
        //   width: 280,
        //   child: Drawer(
        //     child: AppDrawer(),
        //   ),
        // ),
        // bottomNavigationBar: const BottomNav(),
        appBar: AppBar(
          // actions: [
          //   Padding(
          //     padding: const EdgeInsets.symmetric(horizontal: 30),
          //     child: Row(
          //       children: [
          //         Icon(
          //           availability == 'You\'re Offline'
          //               ? Icons.person_off_outlined
          //               : Icons.person,
          //           color: availability == 'You\'re Offline'
          //               ? Colors.red
          //               : Static.secondaryColorSharp,
          //         ),
          //         Text(
          //           "$availability",
          //           style: TextStyle(
          //             color: availability == 'You\'re Offline'
          //                 ? Colors.red
          //                 : Static.secondaryColorSharp,
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ],
          // backgroundColor: HttpStatus.switchingProtocols.colorPrimary,
          backgroundColor: Static.dashboardBG,
          elevation: 0.0,
          toolbarHeight: 70,
          leadingWidth: 100,
          leading: Row(
            children: [
              Container(
                margin: const EdgeInsets.only(left: 15),
                child: MaterialButton(
                  elevation: 0.0,
                  hoverElevation: 0.0,
                  focusElevation: 0.0,
                  highlightElevation: 0.0,
                  minWidth: 60,
                  height: 60,
                  color: Colors.transparent,
                  onPressed: () {
                    scaffoldKey.currentState?.openDrawer();
                  },
                  shape: const CircleBorder(),
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 0),
                        child: ProfileButtonWithBottomSheet(
                          getUserName: getUserName,
                          getuserPhone: getuserPhone,
                          pageIs: 'home',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding:
                const EdgeInsets.only(left: 24, top: 20, right: 24, bottom: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ///   TOP CONTAINER
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text(
                        'Welcome!',
                        style: TextStyle(
                            color: Static.primaryColorblue,
                            fontSize: 22,
                            fontFamily: 'Brand-Bold'),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '$currencySymbol${UserPreferences.getUserEarning() ?? getUserEarning}',
                            style: const TextStyle(
                                color: Static.primaryColorblue,
                                fontSize: 20,
                                fontFamily: 'Brand-Bold'),
                          ),
                          const Text(
                            'Current Earnings',
                            style: TextStyle(
                                color: Static.colorTextLight,
                                fontSize: 12,
                                fontFamily: 'Brand-Regular'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const BrandDivider(),
                const SizedBox(height: 20),

                ///   2ND CONTAINER
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MaterialButton(
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Static.dashboardCard,
                        minWidth: 15,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        onPressed: () async {
                          setState(() {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const MapPage()),
                            );
                          });
                        },
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Image.asset(
                                'images/ubergo.png',
                                height: 60,
                                width: 120,
                              ),
                              const SizedBox(height: 5),
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Find Rides'),
                                  SizedBox(width: 10),
                                  Icon(Icons.arrow_forward),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(child: Container()),
                      MaterialButton(
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Static.dashboardCard,
                        minWidth: 15,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        onPressed: () {
                          setState(() {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const Earnings(type: 'navigation')),
                            );
                          });
                        },
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * .25,
                          height: 100,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                'images/debit3d.png',
                                height: 60,
                                width: 60,
                              ),
                              const SizedBox(height: 5),
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Earnings'),
                                  SizedBox(width: 10),
                                  Icon(Icons.arrow_forward),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                ///   2ND CONTAINER
                const SizedBox(height: 30),
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      MaterialButton(
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Static.dashboardCard,
                        minWidth: 15,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        onPressed: () async {
                          setState(() {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const Bookings(type: 'navigation')),
                            );
                          });
                        },
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * .6,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Image.asset(
                                'images/ubergo.png',
                                height: 60,
                                width: 120,
                              ),
                              const SizedBox(height: 5),
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Car Bookings'),
                                  SizedBox(width: 10),
                                  Icon(Icons.arrow_forward),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                //
                const SizedBox(height: 30),

                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        // ignore: prefer_const_literals_to_create_immutables
                        children: [
                          const SizedBox(height: 5),
                          const Text(
                            'Bounus Reached',
                            style: TextStyle(
                              fontSize: 18,
                              fontFamily: 'Brand-Bold',
                            ),
                          ),
                          Expanded(child: Container()),
                          bounusReach != null && bounusReach > 250
                              ? TextButton(
                                  onPressed: () {},
                                  child: const Row(
                                    children: [
                                      Text(
                                        'Withdraw',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontFamily: 'Brand-Bold',
                                        ),
                                      ),
                                      Icon(Icons.arrow_right),
                                    ],
                                  ),
                                )
                              : Expanded(child: Container()),
                        ],
                      ),
                      const SizedBox(height: 15),
                      bonusDataLoading
                          ? const DataLoadedProgress()
                          : BonusList(bounusReach: bounusReach),

                      //
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class BonusList extends StatefulWidget {
  const BonusList({
    Key? key,
    required this.bounusReach,
  }) : super(key: key);

  final bounusReach;

  @override
  State<BonusList> createState() => _BonusListState();
}

class _BonusListState extends State<BonusList> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              '250  Rides',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 250
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 250
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
            Expanded(child: Container()),
            Expanded(child: Container()),
            Text(
              '$currencySymbol 3000',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 250
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 250
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              '500  Rides',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 500
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 500
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
            Expanded(child: Container()),
            Expanded(child: Container()),
            Text(
              '$currencySymbol 5000',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 500
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 500
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              '1000  Rides',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 1000
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 1000
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
            Expanded(child: Container()),
            Expanded(child: Container()),
            Text(
              '$currencySymbol 1200',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 1000
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 1000
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              '1500  Rides',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 1500
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 1500
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
            Expanded(child: Container()),
            Expanded(child: Container()),
            Text(
              '$currencySymbol 1200',
              style: TextStyle(
                fontSize: 14,
                fontFamily:
                    widget.bounusReach != null && widget.bounusReach >= 1500
                        ? 'Brand-Bold'
                        : 'Brand-Regular',
                color: widget.bounusReach != null && widget.bounusReach >= 1500
                    ? Static.secondaryColorSharp
                    : Colors.black,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

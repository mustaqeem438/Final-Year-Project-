import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/models/driver.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:vdriver_partner/widget/DataLoadedProgress.dart';
import 'package:vdriver_partner/widget/profileWidget.dart';
import 'package:vdriver_partner/statics.dart' as appcolors;

class Account extends StatefulWidget {
  const Account({Key? key}) : super(key: key);
  static const String id = 'Account';

  @override
  _AccountState createState() => _AccountState();
}

class _AccountState extends State<Account> with TickerProviderStateMixin {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  final _formKey = GlobalKey<FormState>();
  int groupValue = 1;
  bool manualAdressExists = false;
  String? getUserName = '';
  String? getuserPhone = '';
  // Text Field Controllers

  late final _nameController = TextEditingController();
  late final _carRateController = TextEditingController();
  late final _carModelController = TextEditingController();
  late final _carColorController = TextEditingController();
  late final _carNmbrController = TextEditingController();
  final _phoneController = TextEditingController();

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
  }

  Future<void> updateProfile() async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const Center(
        child: DataLoadedProgress(),
      ),
    );

    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    DatabaseReference profileRef =
        FirebaseDatabase.instance.ref().child('drivers/$userid');

    await profileRef.update({
      "fullname": _nameController.text.toString(),
      "carrate": _carRateController.text.toString(),
      "phone": _phoneController.text.toString(),
    });

    DatabaseReference profileVehicleRef = FirebaseDatabase.instance
        .ref()
        .child('drivers/$userid/vehicle_details');

    await profileVehicleRef.update({
      "vehicle_color": _carColorController.text.toString(),
      "vehicle_model": _carModelController.text.toString(),
      "vehicle_number": _carNmbrController.text.toString(),
    });

    Navigator.pop(context);
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => Center(
        child: Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          backgroundColor: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.all(16.0),
            width: double.infinity,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(4)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Icon(
                    FeatherIcons.userCheck,
                    size: 40,
                    color: Colors.green,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Profile Updated Successfully!',
                    style: TextStyle(fontSize: 15),
                  ),
                  const SizedBox(height: 20),
                  Center(
                      child: TextButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(
                        Colors.black,
                      ),
                      foregroundColor: MaterialStateProperty.all(
                        Colors.white,
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Close'),
                  ))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    // getUserInfo();
    print(_carRateController.toString());
    print(_carColorController.toString());
    _carColorController.text = CurrentDriverInfo!.carColor.toString();
    _carRateController.text = CurrentDriverInfo!.carRate.toString();
    _carModelController.text = CurrentDriverInfo!.carModel.toString();
    _carNmbrController.text = CurrentDriverInfo!.vehicleNumber.toString();
    _phoneController.text = CurrentDriverInfo!.phone.toString();
    _nameController.text = CurrentDriverInfo!.fullName.toString();
  }

  @override
  void dispose() {
    super.dispose();
    _nameController.dispose();
    _carRateController.dispose();
    _carModelController.dispose();
    _carColorController.dispose();
    _carNmbrController.dispose();
    _phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: appcolors.dashboardCard,
      appBar: AppBar(
        elevation: .7,
        toolbarHeight: 70,
        backgroundColor: appcolors.dashboardBG,
        centerTitle: true,
        title: const Text(
          'Account',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.only(
              left: leftPadding,
              right: rightPadding,
              bottom: bottomPadding,
              top: topPadding,
            ),
            child: Column(
              children: [
                const SizedBox(height: 30),
                ProfileWidget(
                  imagePath: 'images/user_icon.png',
                  onClicked: () async {},
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              controller: _nameController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Name',
                                hintText: 'Enter Full Name',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Full Name';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),

                        const SizedBox(height: 5),
                        // const Text(
                        //   'Phone Number Can Not be Changed!',
                        //   style: TextStyle(fontSize: 14),
                        // ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              // enabled: false,
                              controller: _phoneController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Phone',
                                hintText: 'Enter Phone Number',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Phone Number';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              controller: _carRateController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Car Rates',
                                hintText: 'Enter Car Booking Rates / day',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Car Booking Rates';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              controller: _carColorController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Car Color',
                                hintText: 'Enter Car Color',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Car Color';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              controller: _carModelController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Car Model',
                                hintText: 'Enter Car Model',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Car Model';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 5),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 5,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            child: TextFormField(
                              controller: _carNmbrController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                isDense: true,
                                labelText: 'Car Number',
                                hintText: 'Enter Car Number',
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please Enter Car Number';
                                }
                                return null;
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Center(
                          child: SizedBox(
                            width: 150,
                            height: 50,
                            child: MaterialButton(
                              elevation: 0.0,
                              hoverElevation: 0,
                              highlightElevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(50),
                              ),
                              height: 40,
                              color: appcolors.secondaryColorSharp,
                              textColor: Colors.white,
                              disabledColor: Colors.grey,
                              child: const Text('Update Profile'),
                              //
                              onPressed: () {
                                if (_formKey.currentState!.validate()) {
                                  //
                                  updateProfile();
                                }
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 15),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget addressRadio(
      {required String title,
      required int value,
      required bool selected,
      required Function(int?) onChanged}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.black87,
          border: Border.all(color: Colors.black26),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(),
          child: RadioListTile(
            value: value,
            groupValue: groupValue,
            onChanged: onChanged,
            selected: selected,
            title: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

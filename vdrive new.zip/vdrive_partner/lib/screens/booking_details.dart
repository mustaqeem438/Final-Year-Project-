import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';

class BookingDetails extends StatefulWidget {
  final String? bookingid;

  // Remove the const keyword from the constructor
  const BookingDetails({
    Key? key,
    this.bookingid,
  }) : super(key: key);

  static const String id = 'BookingDetails';

  @override
  State<BookingDetails> createState() => _BookingDetailsState();
}

class _BookingDetailsState extends State<BookingDetails> {
  String driverToken = '';
  String driverName = '';
  String driverPhone = '';
  String vcolor = '';
  String vModel = '';
  String status = '';
  String customerName = '';
  String startDate = '';
  String endDate = '';
  String customerCnic = '';
  String customerEmail = '';
  String customerPhone = '';
  String carRate = '';

  void getDetails() {
    DatabaseReference bookingRef = FirebaseDatabase.instance
        .ref()
        .child('bookingHistory')
        .child(widget.bookingid!);

    bookingRef.once().then((e) async {
      final snapshot = e.snapshot;

      setState(() {
        status = snapshot.child('status').value.toString();
        vcolor = snapshot.child('vehicle_color').value.toString();
        vModel = snapshot.child('vehicle_model').value.toString();
        startDate = snapshot.child('bookingFrom').value.toString();
        endDate = snapshot.child('bookingTill').value.toString();
        customerName = snapshot.child('bookedbyName').value.toString();
        customerPhone = snapshot.child('bookedbyPhone').value.toString();
        customerEmail = snapshot.child('bookedbyEmail').value.toString();
        customerCnic = snapshot.child('bookedbyName').value.toString();
        carRate = snapshot.child('carrate').value.toString();
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getDetails();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardBG,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: Text(
          vModel.isNotEmpty
              ? MainController.capitalize(vModel)
              : 'Booking Details',
          style: const TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Scaffold(
        backgroundColor: appcolors.dashboardCard,
        body: customerName.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  children: [
                    carItems(),
                    const SizedBox(height: 15),
                    customerName.isNotEmpty ? button() : const SizedBox(),
                  ],
                ),
              )
            : const SafeArea(
                child: Center(
                  child: DataLoadedProgress(),
                ),
              ),
      ),
    );
  }

  Widget button() {
    return Column(
      children: [
        status == 'Pending'
            ? Padding(
                padding: const EdgeInsets.only(left: 30, right: 30),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: MaterialButton(
                    color: appcolors.secondaryColorSharp,
                    elevation: 0,
                    hoverElevation: 0,
                    focusElevation: 0,
                    highlightElevation: 0,
                    height: 50,
                    minWidth: double.infinity,
                    onPressed: () {
                      //
                      DatabaseReference newUserRef = FirebaseDatabase.instance
                          .ref()
                          .child('bookingHistory/${widget.bookingid}');

                      newUserRef.update({
                        'status': 'Approved',
                      });

                      Navigator.pop(context);
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          showCloseIcon: true,
                          content: Text(
                            'Booking Approved',
                          ),
                        ),
                      );
                    },
                    child: const Text(
                      'Approve Now',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
              )
            : const SizedBox(),
        const SizedBox(height: 15),
        status == 'Pending'
            ? Padding(
                padding: const EdgeInsets.only(left: 30, right: 30),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: MaterialButton(
                    color: Colors.red,
                    elevation: 0,
                    hoverElevation: 0,
                    focusElevation: 0,
                    highlightElevation: 0,
                    height: 50,
                    minWidth: double.infinity,
                    onPressed: () {
                      //
                    },
                    child: const Text(
                      'Reject',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
              )
            : const SizedBox(),
      ],
    );
  }

  Widget carItems() {
    return Container(
      padding: const EdgeInsets.only(top: 15, bottom: 15),
      width: double.infinity,
      height: 350,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: appcolors.dashboardBG,
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    customerName.isNotEmpty
                        ? '' + MainController.capitalize(customerName)
                        : '',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: 'Roboto-Regular',
                      color: Colors.black,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Text(
                      status.isNotEmpty
                          ? MainController.capitalize(status)
                          : '',
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Roboto-Regular',
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 40),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Car Model:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  vModel.isNotEmpty ? MainController.capitalize(vModel) : '',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Car Color:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  vcolor.isNotEmpty ? MainController.capitalize(vcolor) : '',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Booking Date:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  startDate + ' - ' + endDate,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            'Customer Details:',
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Roboto-Regular',
              color: Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Phone:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                InkWell(
                  onTap: () {
                    launchUrl(Uri.parse("tel://$customerPhone"));
                  },
                  child: Text(
                    customerPhone,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: 'Roboto-Regular',
                      color: Colors.black38,
                      fontSize: 16,
                    ),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Email:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black87,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  customerEmail,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

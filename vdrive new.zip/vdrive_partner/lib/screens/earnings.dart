import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/models/driver.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/widget/DataLoadedProgress.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'history.dart';
import '../statics.dart' as Static;
import '../widget/brandDivider.dart';

class Earnings extends StatefulWidget {
  final String type;
  const Earnings({Key? key, required this.type}) : super(key: key);

  @override
  State<Earnings> createState() => _EarningsState();
}

class _EarningsState extends State<Earnings> {
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  String? getUserEarning = '';
  var totaltrips;
  bool DataLoading = true;
  double dueBalanceValue = 0;

  //
  void checkEarning() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;
    final UserRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);

    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      DataLoading = false;
      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
      String getEarning = DataSnapshot.child('earnings').value.toString();
      setState(() {
        if (getEarning == null) {
          if (UserPreferences.getUserEarning() != null) {
            getUserEarning = UserPreferences.getUserEarning();
          } else {
            getUserEarning = '';
          }
        } else {
          getUserEarning = getEarning;
          UserPreferences.setUserEarning(getUserEarning!);
        }
      });
    });
  }

  void dueBalance() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final earningsRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('earnings');

    earningsRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      double oldEarnings = double.parse(DataSnapshot.value.toString());

      double getDueBalance = (oldEarnings.toDouble() * 0.15);

      setState(() {
        if (getDueBalance == null) {
          if (UserPreferences.getDueBalance() != null) {
            dueBalanceValue =
                double.parse(UserPreferences.getDueBalance().toString());
          } else {
            dueBalanceValue = 0;
          }
        } else {
          dueBalanceValue = getDueBalance;
          UserPreferences.setDueBalance(getDueBalance.toString());
        }
      });
    });
  }

  Future<void> validatetotaltrips() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final totaltripsRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('history');
    totaltripsRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      DataLoading = false;
      totaltrips = DataSnapshot.children.length;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkEarning();
    validatetotaltrips();
    dueBalance();
  }

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      checkEarning();
      validatetotaltrips();
      dueBalance();
    });
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      key: refreshKey,
      onRefresh: refreshList,
      color: Static.secondaryColorSharp,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            'Earnings',
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Static.dashboardBG,
          elevation: 0.0,
          toolbarHeight: 70,
          leading: widget.type == 'navigation'
              ? IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(
                    Icons.arrow_back,
                    color: Colors.black,
                  ),
                )
              : const Text(''),
        ),
        body: ListView(
          children: [
            Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                  image: AssetImage("images/drawerbg.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
              width: double.infinity,
              child: Stack(
                children: [
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.only(
                        top: 70,
                        bottom: 20,
                      ),
                      child: Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text(
                                    'Total Earnings',
                                    style: TextStyle(
                                        color: Static.primaryColorblue),
                                  ),
                                  const SizedBox(height: 10),
                                  DataLoading
                                      ? const DataLoadedProgress()
                                      : Text(
                                          '$currencySymbol${UserPreferences.getUserEarning() ?? getUserEarning}',
                                          style: const TextStyle(
                                              color: Static.primaryColorblue,
                                              fontSize: 40,
                                              fontFamily: 'Brand-Bold'),
                                        ),
                                ],
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 30,
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 30,
                                  ),
                                  child: Row(
                                    children: [
                                      const Text(
                                        'Due Balance',
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontSize: 15,
                                          fontFamily: 'Brand-Bold',
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Text(
                                        '$currencySymbol$dueBalanceValue',
                                        style: const TextStyle(
                                          color: Colors.red,
                                          fontSize: 15,
                                          fontFamily: 'Brand-Bold',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            MaterialButton(
              splashColor: Colors.transparent,
              highlightElevation: 0,
              elevation: 0,
              focusElevation: 0,
              hoverElevation: 0,
              enableFeedback: false,
              padding: const EdgeInsets.all(0),
              onPressed: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => const HistoryPage()),
                // );
              },
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 18),
                child: Row(
                  children: [
                    Image.asset(
                      'images/taxi.png',
                      width: 70,
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    const Text(
                      'Total Trips',
                      style: TextStyle(fontSize: 16),
                    ),
                    Expanded(
                        child: Container(
                            child: Text(
                      '${totaltrips ?? '0'}',
                      textAlign: TextAlign.end,
                      style: const TextStyle(fontSize: 18),
                    ))),
                  ],
                ),
              ),
            ),
            const BrandDivider(),
          ],
        ),
      ),
    );
  }
}

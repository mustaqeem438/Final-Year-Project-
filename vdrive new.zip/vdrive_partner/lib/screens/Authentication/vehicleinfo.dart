// ignore_for_file: prefer_const_constructors
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/screens/homepage.dart';
import 'package:vdriver_partner/screens/uploadCarImags.dart';
import 'package:vdriver_partner/widget/FareButton.dart';
import 'package:vdriver_partner/widget/progressDialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as Static;

class VehicleInfoPage extends StatefulWidget {
  static const String id = 'vehicleinfo';

  String? userid;
  String? name;

  VehicleInfoPage({
    Key? key,
    this.userid,
    this.name,
  }) : super(key: key);

  @override
  State<VehicleInfoPage> createState() => _VehicleInfoPageState();
}

class _VehicleInfoPageState extends State<VehicleInfoPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  var vehicleModelController = TextEditingController();
  var vehicleColorController = TextEditingController();
  var vehiclenumberController = TextEditingController();
  var carRateController = TextEditingController();

  void updateProfile() {
    showDialog(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) => ProgressDialog(
        status: 'Registering Details...',
      ),
    );

    DatabaseReference driverRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(widget.userid!)
        .child('vehicle_details');

    Map map = {
      'vehicle_color': vehicleColorController.text,
      'vehicle_model': vehicleModelController.text,
      'vehicle_number': vehiclenumberController.text,
    };

    driverRef.set(map);

    DatabaseReference profileRef =
        FirebaseDatabase.instance.ref().child('drivers/${widget.userid}');

    profileRef.update({
      "fullname": widget.name.toString(),
      "carrate": carRateController.toString().isNotEmpty
          ? carRateController.text
          : '100',
    });
    carRateController.text = UserPreferences.getUserCarRate() ?? '';

    // Navigator.pushNamedAndRemoveUntil(context, HomePage.id, (route) => false);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const UploadImages()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 70,
                ),
                //
                Image(
                  image: AssetImage("images/logo.png"),
                  alignment: Alignment.center,
                  height: 100.0,
                  width: 200.0,
                ),
                SizedBox(
                  height: 10,
                ),
                //
                //
                Text(
                  'Enter Vehicle Details',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                  ),
                ),

                SizedBox(height: 20),
                //
                // Full Name
                Padding(
                  padding: EdgeInsets.only(
                    right: 20,
                    left: 20,
                  ),
                  child: TextField(
                    controller: vehicleModelController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Car Model / Name",
                      labelStyle: TextStyle(
                        fontSize: 14.0,
                      ),
                      hintStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 10.0,
                      ),
                    ),
                    style: TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ),
                SizedBox(height: 15),
                //
                //  Phone Number TEXT FIELD
                //
                Padding(
                  padding: EdgeInsets.only(
                    right: 20,
                    left: 20,
                  ),
                  child: TextField(
                    controller: vehicleColorController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Car Color",
                      labelStyle: TextStyle(
                        fontSize: 14.0,
                      ),
                      hintStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 10.0,
                      ),
                    ),
                    style: TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ),
                //
                //
                SizedBox(
                  height: 15,
                ),
                //
                //  Email Address TEXT FIELD
                //
                Padding(
                  padding: EdgeInsets.only(
                    right: 20,
                    left: 20,
                  ),
                  child: TextField(
                    controller: vehiclenumberController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Car Number",
                      labelStyle: TextStyle(
                        fontSize: 14.0,
                      ),
                      hintStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 10.0,
                      ),
                    ),
                    style: TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ),
                SizedBox(height: 15),
                Padding(
                  padding: EdgeInsets.only(
                    right: 20,
                    left: 20,
                  ),
                  child: TextField(
                    controller: carRateController,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      labelText: "Car Rental Charges / Day",
                      labelStyle: TextStyle(
                        fontSize: 14.0,
                      ),
                      hintStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 10.0,
                      ),
                    ),
                    style: TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ),
                //
                //
                SizedBox(height: 15),
                //
                //    Register Button
                Padding(
                  padding: EdgeInsets.only(
                    right: 50,
                    left: 50,
                  ),
                  child: SizedBox(
                    height: 50.0,
                    width: double.infinity,
                    child: FareButton(
                      title: 'PROCEED',
                      color: Static.primaryColorblue,
                      onPressed: () async {
                        var connectivityResult =
                            await (Connectivity().checkConnectivity());
                        if (connectivityResult != ConnectivityResult.wifi &&
                            connectivityResult != ConnectivityResult.mobile) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'No Internet Connection',
                              ),
                            ),
                          );
                          return;
                        }

                        if (vehicleModelController.text.length < 3) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Enter Valid Vehicle Model',
                              ),
                            ),
                          );
                          return;
                        }
                        if (vehicleColorController.text.length < 3 ||
                            vehicleColorController.text.length > 9) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Enter Valid Color Name!',
                              ),
                            ),
                          );
                          return;
                        }
                        if (vehiclenumberController.text.length < 4 ||
                            !vehiclenumberController.text.contains('-')) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Enter a Valid Vehicle Number!',
                              ),
                            ),
                          );
                          return;
                        }
                        updateProfile();
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

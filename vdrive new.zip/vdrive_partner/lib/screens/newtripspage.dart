import 'dart:async';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';
import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/models/directiondetails.dart';
import 'package:vdriver_partner/models/tripdetails.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/mapkithelper.dart';
import 'package:vdriver_partner/widget/ProgressDialog.dart';
import 'package:vdriver_partner/widget/FareButton.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../statics.dart' as Static;
import '../widget/CollectPaymentDialog.dart';

class NewTripPage extends StatefulWidget {
  final TripDetails? tripDetails;
  const NewTripPage({Key? key, this.tripDetails}) : super(key: key);
  @override
  _NewTripPageState createState() => _NewTripPageState();
}

class _NewTripPageState extends State<NewTripPage> {
  GoogleMapController? rideMapController;
  final Completer<GoogleMapController> _controller = Completer();
  double mapPaddingBottom = 0;

  Set<Marker> _markers = <Marker>{};
  final Set<Circle> _circles = <Circle>{};

  Map<PolylineId, Polyline> polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();

  var geoLocator = Geolocator();
  var locationOptions =
      const LocationSettings(accuracy: LocationAccuracy.bestForNavigation);

  BitmapDescriptor? movingMarkerIcon;
  BitmapDescriptor? destIcon;
  BitmapDescriptor? pickIcon;

  Position? myPosition;
  Position? currentPosition;

  DirectionDetails? tripDirectionDetails;

  String status = 'accepted';

  String durationString = '';

  bool isRequestingDirection = false;

  String buttonTitle = 'Arrived';

  Color buttonColor = Static.secondaryColorSharp;

  Timer? timer;

  int durationCounter = 0;

  void createMarker() {
    if (movingMarkerIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context, size: const Size(2, 2));
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/car_ios.png'
                  : 'images/car_android.png')
          .then((icon) {
        movingMarkerIcon = icon;
      });
    }
  }

  void getCurrentPosition() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;
    LatLng pos = LatLng(position.latitude, position.longitude);
    CameraPosition cp = CameraPosition(target: pos, zoom: 16);
    rideMapController?.animateCamera(CameraUpdate.newCameraPosition(cp));
  }

  void destinationMarker() {
    if (destIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context);
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/desticon-black.png'
                  : 'images/desticon-black.png')
          .then((icon) {
        destIcon = icon;
      });
    }
  }

  void pickupMarker() {
    if (pickIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context);
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/pickicon-black.png'
                  : 'images/pickicon-black.png')
          .then((icon) {
        pickIcon = icon;
      });
    }
  }

  void acceptTrip() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;

    String? rideID = widget.tripDetails?.rideID;
    DatabaseReference rideRef =
        FirebaseDatabase.instance.ref().child('rideRequest').child(rideID!);

    rideRef.child('status').set('accepted');
    rideRef.child('driver_name').set(CurrentDriverInfo?.fullName);
    rideRef
        .child('car_details')
        .set('${CurrentDriverInfo?.carColor} - ${CurrentDriverInfo?.carModel}');
    rideRef.child('driver_phone').set(CurrentDriverInfo?.phone);
    rideRef.child('driver_id').set(CurrentDriverInfo?.id);

    Position userposition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    Map locationMap = {
      'latitude': userposition.latitude.toString(),
      'longitude': userposition.longitude.toString(),
    };

    rideRef.child('driver_location').set(locationMap);

    DatabaseReference historyRef = FirebaseDatabase.instance
        .ref()
        .child('drivers/${currentFirebaseUser?.uid}/history/$rideID');
    historyRef.set(true);
  }

  void getLocationUpdates() {
    LatLng oldPosition = const LatLng(0, 0);

    ridePositionStream =
        Geolocator.getPositionStream(locationSettings: locationOptions)
            .listen((Position position) {
      myPosition = position;
      currentPosition = position;
      LatLng pos = LatLng(position.latitude, position.longitude);

      var rotation = MapKitHelper.getMarkerRotation(oldPosition.latitude,
          oldPosition.longitude, pos.latitude, pos.longitude);

      print('my rotation = $rotation');

      Marker movingMaker = Marker(
          markerId: const MarkerId('moving'),
          position: pos,
          icon: movingMarkerIcon!,
          rotation: rotation as double,
          infoWindow: const InfoWindow(title: 'Current Location'));

      setState(() {
        CameraPosition cp = CameraPosition(target: pos, zoom: 16);
        rideMapController?.animateCamera(CameraUpdate.newCameraPosition(cp));

        _markers.removeWhere((marker) => marker.markerId.value == 'moving');
        _markers.add(movingMaker);
      });

      oldPosition = pos;

      updateTripDetails();

      Map locationMap = {
        'latitude': myPosition?.latitude.toString(),
        'longitude': myPosition?.longitude.toString(),
      };

      String? rideID = widget.tripDetails?.rideID;
      DatabaseReference rideRef =
          FirebaseDatabase.instance.ref().child('rideRequest').child(rideID!);

      rideRef.child('driver_location').set(locationMap);
    });
  }

  void updateTripDetails() async {
    if (!isRequestingDirection) {
      isRequestingDirection = true;

      if (myPosition == null) {
        return;
      }

      var positionLatLng = LatLng(myPosition!.latitude, myPosition!.longitude);
      LatLng destinationLatLng;

      if (status == 'accepted') {
        destinationLatLng = widget.tripDetails!.pickup;
      } else {
        destinationLatLng = widget.tripDetails!.destination;
      }

      var directionDetails = await MainController.getDirectionDetails(
          positionLatLng, destinationLatLng);

      print(directionDetails.durationText);

      setState(() {
        durationString = directionDetails.durationText;
      });
      isRequestingDirection = false;
    }
  }

  ///   Start Timer to Change Status of Ride
  void startTimer() {
    const interval = Duration(seconds: 1);
    timer = Timer.periodic(interval, (timer) {
      durationCounter++;
    });
  }

  ///   End Ride
  void endTrip() async {
    String? rideID = widget.tripDetails?.rideID;
    DatabaseReference rideRef =
        FirebaseDatabase.instance.ref().child('rideRequest').child(rideID!);

    timer?.cancel();

    MainController.showProgressDialog(context);

    var currentLatLng = LatLng(myPosition!.latitude, myPosition!.longitude);

    var directionDetails = await MainController.getDirectionDetails(
        widget.tripDetails!.pickup, currentLatLng);

    Navigator.pop(context);

    int fares =
        MainController.estimateFaresCar(directionDetails, durationCounter);

    rideRef.child('fares').set(fares.toString());

    rideRef.child('status').set('ended');

    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final availRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('newtrip');

    availRef.set('waiting');

    ridePositionStream?.cancel();

    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => CollectPayment(
              paymentMethod: widget.tripDetails?.paymentMethod,
              fares: fares,
            ));

    topUpEarnings(fares);
  }

  void topUpEarnings(int fares) async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final earningsRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('earnings');

    earningsRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      if (DataSnapshot != null) {
        double oldEarnings = double.parse(DataSnapshot.value.toString());

        double adjustedEarnings = (fares.toDouble() * 0.85) + oldEarnings;

        earningsRef.set(adjustedEarnings.toStringAsFixed(2));
      } else {
        double adjustedEarnings = (fares.toDouble() * 0.85);
        earningsRef.set(adjustedEarnings.toStringAsFixed(2));
      }
    });
  }

  // Future<void> setProviderLocation() async {
  //   Position userposition = await Geolocator.getCurrentPosition(
  //       desiredAccuracy: LocationAccuracy.high);
  // }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentPosition();
    acceptTrip();
  }

  @override
  Widget build(BuildContext context) {
    createMarker();
    pickupMarker();
    destinationMarker();
    return Scaffold(
      body: Stack(
        children: <Widget>[
          GoogleMap(
            padding: EdgeInsets.only(bottom: mapPaddingBottom),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            compassEnabled: false,
            mapToolbarEnabled: false,
            trafficEnabled: true,
            zoomGesturesEnabled: true,
            zoomControlsEnabled: false,
            circles: _circles,
            markers: _markers,
            polylines: Set<Polyline>.of(polylines.values),
            initialCameraPosition: googlePlex,
            onMapCreated: (GoogleMapController controller) async {
              _controller.complete(controller);
              controller.setMapStyle(MainController.mapStyle());
              rideMapController = controller;

              setState(() {
                mapPaddingBottom = (Platform.isIOS) ? 255 : 260;
              });

              Position userposition = await Geolocator.getCurrentPosition(
                  desiredAccuracy: LocationAccuracy.high);

              var currentLatLng =
                  LatLng(userposition.latitude, userposition.longitude);
              // var currentLatLng =
              //     LatLng(currentPosition.latitude, currentPosition.longitude);
              var pickupLatLng = widget.tripDetails!.pickup;
              await getDirection(currentLatLng, pickupLatLng);

              getLocationUpdates();
            },
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Column(
              children: [
                //  ZoomIn Button
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 2,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Expanded(child: Container()),
                        GestureDetector(
                          onTap: () async {
                            var currentZoomLevels =
                                await rideMapController?.getZoomLevel();

                            var currentZoomLevel = currentZoomLevels! + 1;
                            rideMapController?.animateCamera(
                              CameraUpdate.zoomTo(currentZoomLevel),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              // ignore: prefer_const_literals_to_create_immutables
                              boxShadow: [
                                const BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 5.0,
                                    spreadRadius: 0.5,
                                    offset: Offset(.7, .7))
                              ],
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Icon(
                                FontAwesomeIcons.plus,
                                color: Static.secondaryColorSharp,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                //
                //  ZoomOut Button
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 2,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Expanded(child: Container()),
                        GestureDetector(
                          onTap: () async {
                            var currentZoomLevels =
                                await rideMapController?.getZoomLevel();

                            var currentZoomLevel = currentZoomLevels! - 1;
                            rideMapController?.animateCamera(
                              CameraUpdate.zoomTo(currentZoomLevel),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              // ignore: prefer_const_literals_to_create_immutables
                              boxShadow: [
                                const BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 5.0,
                                    spreadRadius: 0.5,
                                    offset: Offset(.7, .7))
                              ],
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Icon(
                                FontAwesomeIcons.minus,
                                color: Static.secondaryColorSharp,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                //
                /// Location Button
                SizedBox(
                  width: double.infinity,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 16,
                      right: 16,
                      bottom: 16,
                      top: 5,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Expanded(child: Container()),
                        GestureDetector(
                          onTap: getCurrentPosition,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Static.primaryColorblue,
                              borderRadius: BorderRadius.circular(20),
                              // ignore: prefer_const_literals_to_create_immutables
                              boxShadow: [
                                const BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 5.0,
                                    spreadRadius: 0.5,
                                    offset: Offset(.7, .7))
                              ],
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Icon(
                                Icons.my_location,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                //
                Container(
                  decoration: const BoxDecoration(
                    color: Static.primaryColorblue,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 15.0,
                        spreadRadius: 0.5,
                        offset: Offset(
                          0.7,
                          0.7,
                        ),
                      )
                    ],
                  ),
                  height: Platform.isIOS ? 280 : 250,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          durationString ?? '14 Min',
                          style: const TextStyle(
                              fontSize: 14,
                              fontFamily: 'Brand-Bold',
                              color: Colors.white),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              MainController.capitalize(
                                  widget.tripDetails!.riderName),
                              style: const TextStyle(
                                fontSize: 22,
                                fontFamily: 'Brand-Bold',
                                color: Colors.white,
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                launchUrl(Uri.parse(
                                    "tel://${widget.tripDetails!.riderPhone}"));
                              },
                              child: const Padding(
                                padding: EdgeInsets.only(right: 10),
                                child: Icon(
                                  Icons.call,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 25,
                        ),
                        widget.tripDetails!.pickupAddress.isEmpty
                            ? const SizedBox()
                            : Row(
                                children: <Widget>[
                                  Image.asset(
                                    'images/pickicon.png',
                                    height: 16,
                                    width: 16,
                                  ),
                                  const SizedBox(
                                    width: 18,
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: Text(
                                        widget.tripDetails!.pickupAddress,
                                        style: const TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                        widget.tripDetails!.pickupAddress.isEmpty
                            ? const SizedBox()
                            : const SizedBox(
                                height: 15,
                              ),
                        widget.tripDetails!.destinationAddress.isEmpty
                            ? const SizedBox()
                            : Row(
                                children: <Widget>[
                                  Image.asset(
                                    'images/desticon.png',
                                    height: 16,
                                    width: 16,
                                  ),
                                  const SizedBox(
                                    width: 18,
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: Text(
                                        widget.tripDetails!.destinationAddress,
                                        style: const TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                        const SizedBox(
                          height: 25,
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: FareButton(
                            title: buttonTitle,
                            color: buttonColor,
                            onPressed: () async {
                              String? rideID = widget.tripDetails?.rideID;
                              DatabaseReference rideRef = FirebaseDatabase
                                  .instance
                                  .ref()
                                  .child('rideRequest')
                                  .child(rideID!);

                              if (status == 'accepted') {
                                status = 'arrived';
                                rideRef.child('status').set(('arrived'));

                                setState(() {
                                  buttonTitle = 'Start Ride';
                                  buttonColor =
                                      const Color.fromARGB(255, 0, 155, 222);
                                });

                                MainController.showProgressDialog(context);

                                await getDirection(widget.tripDetails!.pickup,
                                    widget.tripDetails!.destination);

                                Navigator.pop(context);
                              } else if (status == 'arrived') {
                                status = 'ontrip';
                                rideRef.child('status').set('ontrip');

                                setState(() {
                                  buttonTitle = 'End Ride';
                                  buttonColor = Colors.red;
                                });

                                startTimer();
                              } else if (status == 'ontrip') {
                                endTrip();
                              }
                            },
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  _addPolyLine() {
    PolylineId id = const PolylineId("poly");
    Polyline polyline = Polyline(
      polylineId: id,
      color: Static.primaryColorblue,
      width: 3,
      jointType: JointType.round,
      points: polylineCoordinates,
      startCap: Cap.roundCap,
      endCap: Cap.roundCap,
      geodesic: true,
    );
    polylines[id] = polyline;
    setState(() {});
  }

  Future<void> getDirection(
      LatLng pickupLatLng, LatLng destinationLatLng) async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const ProgressDialog(
        status: 'Finding Route...',
      ),
    );

    var thisDetails = await MainController.getDirectionDetails(
        pickupLatLng, destinationLatLng);

    Navigator.pop(context);

    PolylinePoints polylinePoints = PolylinePoints();

    polylineCoordinates.clear();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        mapKey,
        PointLatLng(pickupLatLng.latitude, pickupLatLng.longitude),
        PointLatLng(destinationLatLng.latitude, destinationLatLng.longitude),
        travelMode: TravelMode.driving);
    if (result.points.isNotEmpty) {
      for (var point in result.points) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      }
    }
    polylines.clear();

    _addPolyLine();

    LatLngBounds bounds;

    if (pickupLatLng.latitude > destinationLatLng.latitude &&
        pickupLatLng.longitude > destinationLatLng.longitude) {
      bounds =
          LatLngBounds(southwest: destinationLatLng, northeast: pickupLatLng);
    } else if (pickupLatLng.longitude > destinationLatLng.longitude) {
      bounds = LatLngBounds(
          southwest: LatLng(pickupLatLng.latitude, destinationLatLng.longitude),
          northeast:
              LatLng(destinationLatLng.latitude, pickupLatLng.longitude));
    } else if (pickupLatLng.latitude > destinationLatLng.latitude) {
      bounds = LatLngBounds(
        southwest: LatLng(destinationLatLng.latitude, pickupLatLng.longitude),
        northeast: LatLng(pickupLatLng.latitude, destinationLatLng.longitude),
      );
    } else {
      bounds =
          LatLngBounds(southwest: pickupLatLng, northeast: destinationLatLng);
    }

    rideMapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 70));

    setState(() {
      _markers.clear();
    });

    Set<Marker> tempPDMarkers = <Marker>{};

    Marker pickupMarker = Marker(
      markerId: const MarkerId('pickup'),
      position: pickupLatLng,
      icon: pickIcon!,
    );

    Marker destinationMarker = Marker(
      markerId: const MarkerId('destination'),
      position: destinationLatLng,
      icon: destIcon!,
    );

    setState(() {
      tempPDMarkers.add(pickupMarker);
      tempPDMarkers.add(destinationMarker);
      _markers = tempPDMarkers;
    });

    setState(() {
      _markers.add(pickupMarker);
      _markers.add(destinationMarker);
    });

    Circle pickupCircle = Circle(
      circleId: const CircleId('pickup'),
      strokeColor: Static.primaryColorblue,
      strokeWidth: 1,
      radius: 12,
      center: pickupLatLng,
      fillColor: Static.primaryColorblue,
    );

    Circle destinationCircle = Circle(
      circleId: const CircleId('destination'),
      strokeColor: Static.primaryColorblue,
      strokeWidth: 1,
      radius: 12,
      center: destinationLatLng,
      fillColor: Static.primaryColorblue,
    );

    setState(() {
      _circles.add(pickupCircle);
      _circles.add(destinationCircle);
    });
  }
}

import 'dart:async';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/screens/homepage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:vdriver_partner/screens/tabspage.dart';
import '../models/driver.dart';
import '../statics.dart' as Static;
import '../globalvariable.dart';
import '../widget/ConfirmSheet.dart';
import '../widget/availabilityButton.dart';

class MapPage extends StatefulWidget {
  const MapPage({Key? key}) : super(key: key);
  static const String id = 'maptab';

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  //
  GoogleMapController? mapController;
  final Completer<GoogleMapController> _controller = Completer();
  var geoLocator = Geolocator();
  //

  var locationOptions = const LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 4);
  //
  Position? currentPosition;
  DatabaseReference? tripRequestRef;

  String availabilityTitle = 'Go Online';
  Color availabilityColor = Colors.red;
  String availabilityStatus = 'Offline';
  bool isAvailable = false;

  void getCurrentPosition() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;
    LatLng pos = LatLng(position.latitude, position.longitude);
    CameraPosition cp = CameraPosition(target: pos, zoom: 14);
    mapController?.animateCamera(CameraUpdate.newCameraPosition(cp));
    GoOnline();
  }

  void checkAvailability() async {
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
      if (mounted) {
        setState(() {
          if (CurrentDriverInfo?.newtrip.toString() == 'waiting' ||
              CurrentDriverInfo?.newtrip.toString() == 'timeout' ||
              CurrentDriverInfo?.newtrip.toString() == 'cancelled' ||
              CurrentDriverInfo?.newtrip.toString() == 'ended') {
            availabilityTitle = 'Go Offline';
            availabilityColor = Static.secondaryColorSharp;
            availabilityStatus = 'Online';
            isAvailable = true;
          }
        });
      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCurrentPosition();
    MainController.getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    checkAvailability();
    return Center(
      child: Stack(
        children: [
          //
          GoogleMap(
            padding: const EdgeInsets.only(top: 135),
            myLocationButtonEnabled: false,
            initialCameraPosition: googlePlex,
            myLocationEnabled: true,
            zoomGesturesEnabled: true,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            trafficEnabled: true,
            rotateGesturesEnabled: true,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
              mapController = controller;
              controller.setMapStyle(MainController.mapStyle());
              getCurrentPosition();
            },
          ),
          //
          Positioned(
            bottom: 20,
            right: 20,
            child: GestureDetector(
              onTap: () {
                getCurrentPosition();
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Static.primaryColorblue,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black26,
                        blurRadius: 5.0,
                        spreadRadius: 0.5,
                        offset: Offset(.7, .7))
                  ],
                ),
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.my_location,
                    color: Colors.white,
                    size: 25,
                  ),
                ),
              ),
            ),
          ),
          //
          //
          Positioned(
            left: 0,
            right: 0,
            bottom: 15,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const TabsPage()),
                    );
                  },
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        color: Static.secondaryColorSharp,
                        borderRadius: BorderRadius.circular(50)),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          FeatherIcons.arrowLeft,
                          color: Colors.white,
                          size: 25,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          //
          Container(
            height: 135,
            width: double.infinity,
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    // ignore: prefer_const_literals_to_create_immutables
                    children: [
                      Text(
                        'You are $availabilityStatus!',
                        style: const TextStyle(
                          color: Static.colorText,
                          fontFamily: 'Brand-Regular',
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AvailabilityButton(
                        title: availabilityTitle,
                        color: availabilityColor,
                        onPressed: () {
                          //
                          showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            shape: const RoundedRectangleBorder(
                              borderRadius: BorderRadius.vertical(
                                top: Radius.circular(20),
                              ),
                            ),
                            builder: (BuildContext context) => ConfirmSheet(
                              title:
                                  (!isAvailable) ? 'Go Online' : 'Go Offline',
                              subtitle: (!isAvailable)
                                  ? 'You are about to become available to receive trip requests'
                                  : 'you will stop receiving new trip requests',
                              onPressed: () {
                                if (!isAvailable) {
                                  GoOnline();
                                  getLocationUpdates();
                                  Navigator.pop(context);
                                  setState(() {
                                    availabilityColor =
                                        Static.secondaryColorSharp;
                                    availabilityTitle = 'Go Offline';
                                    availabilityStatus = 'Online';
                                    isAvailable = true;
                                  });
                                } else {
                                  GoOffline();
                                  Navigator.pop(context);
                                  setState(() {
                                    availabilityColor = Colors.red;
                                    availabilityTitle = 'Go Online';
                                    availabilityStatus = 'Offline';
                                    isAvailable = false;
                                  });
                                }
                              },
                            ),
                          );
                          //
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          //
        ],
      ),
    );
  }

  Future<void> GoOnline() async {
    Geofire.initialize('driversAvailable');
    Geofire.setLocation(currentFirebaseUser!.uid, currentPosition!.latitude,
        currentPosition!.longitude);

    String? userid = currentFirebaseUser?.uid;

    final tripRequestRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(userid!)
        .child('newtrip');

    final tokenRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('token');

    tripRequestRef.set('waiting');

    final FirebaseMessaging fcm = FirebaseMessaging.instance;
    String? token = await fcm.getToken();

    tokenRef.set(token);

    tripRequestRef.onValue.listen((event) {});
  }

  void GoOffline() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    DatabaseReference? tripRequestRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(userid!)
        .child('newtrip');

    Geofire.removeLocation(currentFirebaseUser!.uid);
    tripRequestRef.onDisconnect();
    tripRequestRef.remove();
    tripRequestRef = null;
  }

  void getLocationUpdates() {
    HomePagePositionStream =
        Geolocator.getPositionStream(locationSettings: locationOptions)
            .listen((Position position) {
      currentPosition = position;

      if (isAvailable) {
        Geofire.setLocation(
            currentFirebaseUser!.uid, position.latitude, position.longitude);
      }

      LatLng pos = LatLng(position.latitude, position.longitude);
      CameraPosition cp = CameraPosition(target: pos, zoom: 14);
      mapController?.animateCamera(CameraUpdate.newCameraPosition(cp));
    });
  }
}

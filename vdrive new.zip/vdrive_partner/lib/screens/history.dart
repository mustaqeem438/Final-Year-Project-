import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:provider/provider.dart';
import 'package:vdriver_partner/provider/Appdata.dart';
import 'package:vdriver_partner/widget/BrandDivider.dart';
import 'package:vdriver_partner/widget/HistoryTile.dart';
import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class HistoryPage extends StatefulWidget {
  static const String id = 'historypage';

  const HistoryPage({Key? key}) : super(key: key);

  @override
  _HistoryPageState createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  late Widget historylistData;

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      historylistData = const HistoryList();
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    historylistData = const HistoryList();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(builder: (context) {
      return RefreshIndicator(
        key: refreshKey,
        onRefresh: refreshList,
        color: Static.secondaryColorSharp,
        child: Scaffold(
          appBar: AppBar(
            title: const Text(
              'Ride History',
              style: TextStyle(color: Colors.black),
            ),
            // backgroundColor: HttpStatus.switchingProtocols.colorPrimary,
            backgroundColor: Static.dashboardBG,
            elevation: 0.0,
            toolbarHeight: 70,
            leading: IconButton(
              onPressed: () {
                setState(() {
                  Navigator.pop(context);
                });
              },
              icon: const Icon(
                FeatherIcons.arrowLeft,
                color: Colors.black,
              ),
            ),
          ),
          body: ListView(
            children: [
              historylistData,
            ],
          ),
        ),
      );
    });
  }
}

class HistoryList extends StatelessWidget {
  const HistoryList({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(0),
      itemBuilder: (context, index) {
        return HistoryTile(
          history: Provider.of<AppData>(context).tripHistory[index],
        );
      },
      separatorBuilder: (BuildContext context, int index) =>
          const BrandDivider(),
      itemCount: Provider.of<AppData>(context).tripHistory.length,
      shrinkWrap: true,
      physics: const ClampingScrollPhysics(),
    );
  }
}

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/permissions.dart';
import 'package:path/path.dart' as path;
import 'package:vdriver_partner/screens/homepage.dart';
import 'package:vdriver_partner/widget/progressDialog.dart';
import 'package:vdriver_partner/statics.dart' as Static;

class UploadImages extends StatefulWidget {
  const UploadImages({Key? key}) : super(key: key);
  static const String id = 'HomePage';

  @override
  State<UploadImages> createState() => _UploadImagesState();
}

class _UploadImagesState extends State<UploadImages> {
  CollectionReference? imgref;
  final ImagePicker imagePicker = ImagePicker();
  final List<File> _selectedFiles = [];
  final List<String> _arrImageURLs = [];
  int? catIndex;
  File? imagePath;
  String? imageName;
  String? imagedata;

  @override
  void initState() {
    super.initState();
    locationPermision();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: const Text(
            "Upload Car Images",
            style: TextStyle(color: Colors.black),
          ),
        ),
        bottomNavigationBar: _selectedFiles.length <= 6 &&
                _selectedFiles.isNotEmpty
            ? SizedBox(
                height: 55,
                child: Center(
                  child: MaterialButton(
                    color: Colors.orange,
                    minWidth: MediaQuery.sizeOf(context).width,
                    onPressed: () {
                      showDialog(
                          barrierDismissible: false,
                          context: context,
                          builder: (BuildContext context) => Dialog(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0)),
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                child: const Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        Static.colorOrange),
                                  ),
                                ),
                              ));

                      UploadImages().whenComplete(() {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Registration Successfull!',
                            ),
                          ),
                        );
                        // Navigator.pushNamedAndRemoveUntil(context, HomePage.id, (route) => false);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const HomePage()),
                        );
                      });
                    },
                    height: 56,
                    child: const Text(
                      'SUBMIT',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              )
            : const SizedBox(),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.only(
                    left: 40, top: 31, right: 40, bottom: 5),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                margin: const EdgeInsets.only(top: 23),
                                child: MaterialButton(
                                  elevation: 0,
                                  highlightElevation: 0,
                                  focusElevation: 0,
                                  hoverElevation: 0,
                                  color: Colors.grey.shade100,
                                  onPressed: () => getImages(),
                                  height: 56,
                                  child: const Text('Select Images'),
                                ),
                              ),
                              _selectedFiles.isNotEmpty
                                  ? Container(
                                      margin: const EdgeInsets.only(
                                          top: 23, left: 25),
                                      child: MaterialButton(
                                        elevation: 0,
                                        highlightElevation: 0,
                                        focusElevation: 0,
                                        hoverElevation: 0,
                                        color: Colors.grey.shade100,
                                        onPressed: () {
                                          setState(() {
                                            _selectedFiles.clear();
                                          });
                                        },
                                        height: 56,
                                        child: const Text('Reset'),
                                      ),
                                    )
                                  : const SizedBox(),
                            ],
                          ),
                        ],
                      ),
                      _selectedFiles.isNotEmpty
                          ? _selectedFiles.length > 4
                              ? const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 50),
                                  child: Center(
                                      child: Text('Max 4 Images Allowed')),
                                )
                              : SizedBox(
                                  width: 300,
                                  height: _selectedFiles.length > 3 ? 200 : 100,
                                  child: buildGridView(),
                                )
                          : const SizedBox(),
                    ]))),
      ),
    );
  }

  Widget buildGridView() {
    return GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _selectedFiles.length,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.file(
              File(_selectedFiles[index].path),
              width: 200,
              height: 80,
              fit: BoxFit.cover,
            ),
          );
        });
  }

  Future<void> UploadImages() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? currentUserID = currentFirebaseUser?.uid;

    for (var img in _selectedFiles) {
      Reference ref = FirebaseStorage.instance
          .ref()
          .child('images')
          .child(path.basename(img.path));

      await ref.putFile(img).whenComplete(() async {
        await ref.getDownloadURL().then((value) {
          DatabaseReference driverImagesRef = FirebaseDatabase.instance
              .ref()
              .child('drivers')
              .child(currentUserID!)
              .child('vehicle_details')
              .child('images');

          Map map = {
            MainController.generateRandomString(15): value,
          };

          driverImagesRef.set(map);
        });
      });
    }
  }

  Future<void> getImages() async {
    final pickedfile = await imagePicker.pickImage(source: ImageSource.gallery);

    setState(() {
      _selectedFiles.add(File(pickedfile!.path));
    });
    if (pickedfile!.path == null) retreiveData();
  }

  Future<void> retreiveData() async {
    final LostDataResponse response = await imagePicker.retrieveLostData();

    if (response.file != null) {
      setState(() {
        _selectedFiles.add(File(response.file!.path));
      });
    } else {
      print(response.file);
    }
  }
}

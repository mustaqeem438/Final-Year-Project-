import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/screens/booking_details.dart';
import 'package:vdriver_partner/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';

class Bookings extends StatefulWidget {
  final String type;
  const Bookings({Key? key, required this.type}) : super(key: key);
  static const String id = 'Bookings';

  @override
  State<Bookings> createState() => _BookingsState();
}

class _BookingsState extends State<Bookings> {
  void fetchDataFromFirebase() {
    DatabaseReference databaseReference =
        FirebaseDatabase.instance.ref().child('bookingHistory');

    databaseReference.once().then((e) async {
      final snapshot = e.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;

      values.forEach((key, values) {
        if (values['carowner'] == CurrentDriverInfo?.id) {
          Map<String, dynamic> vehicleDetails = {
            'bookingID': values['bookingID'],
            'vehicleColor': values['vehicle_color'],
            'vehicleModel': values['vehicle_model'],
            'ownerName': values['ownername'],
            'bookingFrom': values['bookingFrom'],
            'bookingTill': values['bookingTill'],
            'status': values['status'],
            'bookedbyName': values['bookedbyName'],
          };

          setState(() {
            rentalHistoryList.add(vehicleDetails);
            rentalHistoryLoaded = true;
            rentalDataLoaded = true;
          });
        } else {
          setState(() {
            rentalHistoryLoaded = true;
            rentalDataLoaded = true;
          });
        }
      });
    });
  }

  @override
  void initState() {
    super.initState();
    rentalHistoryList.clear();
    if (rentalDataLoaded == false && rentalHistoryLoaded == false) {
      fetchDataFromFirebase();
    }

    if (rentalDataLoaded == true && rentalHistoryList.isEmpty) {
      fetchDataFromFirebase();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardBG,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        centerTitle: true,
        title: const Text(
          'Car Bookings',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        leading: widget.type == 'navigation'
            ? IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                ),
              )
            : const Text(''),
      ),
      body: Scaffold(
        backgroundColor: appcolors.dashboardCard,
        body: Padding(
          padding: const EdgeInsets.all(8),
          child: carItems(),
        ),
      ),
    );
  }

  // Pending Orders
  Widget carItems() {
    return rentalDataLoaded == true
        ? rentalHistoryList.isNotEmpty || rentalHistoryLoaded == true
            ? rentalHistoryList.isNotEmpty
                ? ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    separatorBuilder: (BuildContext context, int index) =>
                        const SizedBox(),
                    itemCount: rentalHistoryList.length,
                    itemBuilder: (context, index) {
                      return carDetails(
                        bookingData: rentalHistoryList[index],
                      );
                    },
                  )
                : const Center(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('No Booking Found'),
                        ],
                      ),
                    ),
                  )
            : const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('No Booking Found'),
                    ],
                  ),
                ),
              )
        : Container(
            color: appcolors.dashboardCard,
            child: const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DataLoadedProgress(),
                  ],
                ),
              ),
            ),
          );
  }

  carDetails({required Map<String, dynamic> bookingData}) {
    return detailsModel(bookingData: bookingData);
  }

//  Service Item Model
  detailsModel({required Map<String, dynamic> bookingData}) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: GestureDetector(
        onTap: () {},
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: appcolors.dashboardBG,
            border: Border.all(color: Colors.black12),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 5,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 10,
            ),
            child: Column(
              children: [
                // Image Row
                //      'vehicleColor': driverDetails['vehicle_details']['vehicle_color'],
                // 'vehicleModel': driverDetails['vehicle_details']['vehicle_model'],
                // 'vehicleNumber': driverDetails['vehicle_details']['vehicle_number'],
                InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookingDetails(
                          bookingid: bookingData['bookingID'],
                        ),
                      ),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const SizedBox(width: 10),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * .4,
                            child: Text(
                              MainController.capitalize(
                                    bookingData['vehicleModel'],
                                  ) +
                                  ' ' +
                                  MainController.capitalize(
                                    bookingData['vehicleColor'],
                                  ),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontFamily: 'Roboto-Regular',
                                color: Colors.black,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * .4,
                            child: Text(
                              bookingData['bookedbyName'],
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontFamily: 'Roboto-Regular',
                                color: Colors.black45,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                bookingData['bookingFrom'] +
                                    ' - ' +
                                    bookingData['bookingTill'],
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontFamily: 'Roboto-Regular',
                                  color: Colors.black45,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            TextButton(
                              style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        appcolors.colorBackground),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BookingDetails(
                                      bookingid: bookingData['bookingID'],
                                    ),
                                  ),
                                );
                              },
                              child: const Text(
                                'View',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: 'Roboto-Regular',
                                  color: Colors.black,
                                  // color: appcolors.secondaryColorSharp,
                                  fontSize: 15,
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              bookingData['status'],
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: 'Roboto-Regular',
                                color: bookingData['status'] == 'Pending'
                                    ? Colors.red
                                    : Colors.green,
                                // color: appcolors.secondaryColorSharp,
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

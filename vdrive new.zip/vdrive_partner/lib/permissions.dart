import 'package:permission_handler/permission_handler.dart';

get locationStatus => null;
get storageStatus => null;
locationPermision() async {
  PermissionStatus locationStatus = await Permission.location.request();

  if (locationStatus == PermissionStatus.denied) {
    await Permission.location.request();
    openAppSettings();
  } else if (locationStatus == PermissionStatus.permanentlyDenied) {
    openAppSettings();
  }

  // PermissionStatus mediaStatus = await Permission.mediaLibrary.request();

  // if (mediaStatus == PermissionStatus.denied) {
  //   await Permission.mediaLibrary.request();
  //   openAppSettings();
  // } else if (mediaStatus == PermissionStatus.permanentlyDenied) {
  //   openAppSettings();
  // }

  PermissionStatus storageStatus = await Permission.storage.request();

  if (storageStatus == PermissionStatus.denied) {
    await Permission.storage.request();
    // openAppSettings();
  } else if (storageStatus == PermissionStatus.permanentlyDenied) {
    // openAppSettings();
    await Permission.storage.request();
  }

  // PermissionStatus photoStatus = await Permission.photos.request();

  // if (photoStatus == PermissionStatus.denied) {
  //   await Permission.photos.request();
  //   openAppSettings();
  // } else if (photoStatus == PermissionStatus.permanentlyDenied) {
  //   openAppSettings();
  // }

  // PermissionStatus videosStatus = await Permission.videos.request();

  // if (videosStatus == PermissionStatus.denied) {
  //   await Permission.videos.request();
  //   openAppSettings();
  // } else if (videosStatus == PermissionStatus.permanentlyDenied) {
  //   openAppSettings();
  // }
  
}

import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/widget/brandDivider.dart';
import 'package:vdriver_partner/widget/FareButton.dart';
import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class CollectPayment extends StatelessWidget {
  String? paymentMethod;
  int? fares;

  CollectPayment({Key? key, this.paymentMethod, this.fares}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(4.0),
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(4)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(
              height: 20,
            ),
            Text('${paymentMethod?.toUpperCase()} PAYMENT'),
            const SizedBox(
              height: 20,
            ),
            const BrandDivider(),
            const SizedBox(
              height: 16.0,
            ),
            Text(
              currencySymbol! + fares.toString(),
              style: const TextStyle(fontFamily: 'Brand-Bold', fontSize: 50),
            ),
            const SizedBox(
              height: 16,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Amount above is the total fares to be charged to the rider',
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            SizedBox(
              width: 230,
              child: FareButton(
                title: (paymentMethod == 'cash') ? 'COLLECT CASH' : 'CONFIRM',
                color: Static.secondaryColorSharp,
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);

                  MainController.enableHomTabLocationUpdates();
                },
              ),
            ),
            const SizedBox(
              height: 40,
            )
          ],
        ),
      ),
    );
  }
}

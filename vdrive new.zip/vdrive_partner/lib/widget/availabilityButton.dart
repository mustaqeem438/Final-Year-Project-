import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as Static;

class AvailabilityButton extends StatelessWidget {
  final String? title;
  final Color? color;
  final Function()? onPressed;

  const AvailabilityButton({Key? key, this.title, this.onPressed, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      child: SizedBox(
        height: 50,
        width: 180,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '$title',
                  style: const TextStyle(
                    fontSize: 22.0,
                    fontFamily: 'Brand-Regular',
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(width: 10),
                const Icon(Icons.arrow_forward),
              ],
            ),
          ],
        ),
      ),
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(color),
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50.0),
          ),
        ),
      ),
    );
  }
}

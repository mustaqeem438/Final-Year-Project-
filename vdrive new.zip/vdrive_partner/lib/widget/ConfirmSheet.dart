import 'package:vdriver_partner/widget/FareButton.dart';
import 'package:vdriver_partner/widget/FareOutlineButton.dart';
import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class ConfirmSheet extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final Function()? onPressed;

  const ConfirmSheet({Key? key, this.title, this.subtitle, this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
        child: Column(
          children: <Widget>[
            const SizedBox(
              height: 10,
            ),
            Text(
              title!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 22,
                  fontFamily: 'Brand-Bold',
                  color: Static.colorText),
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              subtitle!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Static.colorTextLight),
            ),
            const SizedBox(
              height: 24,
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: Container(
                    child: FareOutlineButton(
                      title: 'Cancel',
                      color: Static.colorLightGrayFair,
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
                const SizedBox(
                  width: 16,
                ),
                Expanded(
                  child: Container(
                    child: FareButton(
                      onPressed: onPressed,
                      color: (title == 'Go Online')
                          ? Static.secondaryColorSharp
                          : Colors.red,
                      title: 'Confirm',
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

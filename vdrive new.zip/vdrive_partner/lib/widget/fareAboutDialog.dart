import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class FareAboutDialog extends StatelessWidget {
  const FareAboutDialog({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(30.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Image.asset(
                    'images/logo.png',
                    height: 50,
                  ),
                  Text(
                    'v1.0.0',
                    style: TextStyle(
                      color: Static.colorTextLight,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Text(
                  'Fare Partner is helping you reach work at rates cheaper than a rickshaw to transferring money to friends and family, Fare can do it all and more. Ride.'),
              SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: Container()),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Close'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class FareOutlineButton extends StatelessWidget {
  final String? title;
  final Function()? onPressed;
  final Color? color;

  FareOutlineButton({this.title, this.onPressed, this.color});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
        onPressed: onPressed,
        child: Container(
          height: 50.0,
          child: Center(
            child: Text(title!,
                style: TextStyle(
                    fontSize: 15.0,
                    fontFamily: 'Brand-Bold',
                    color: Static.colorText)),
          ),
        ));
  }
}

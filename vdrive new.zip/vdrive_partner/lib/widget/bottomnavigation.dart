import 'package:flutter/material.dart';

enum TabItem { red, green, blue }

Map<TabItem, String> tabName = {
  TabItem.red: 'red',
  TabItem.green: 'green',
  TabItem.blue: 'blue',
};

Map<TabItem, MaterialColor> activeTabColor = {
  TabItem.red: Colors.red,
  TabItem.green: Colors.green,
  TabItem.blue: Colors.blue,
};

class BottomNavigation extends StatelessWidget {
  BottomNavigation({this.currentTab, this.onSelectTab});
  final TabItem? currentTab;
  final ValueChanged<TabItem>? onSelectTab;

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      items: [
        _buildItem(tabItem: TabItem.red),
        _buildItem(tabItem: TabItem.green),
        _buildItem(tabItem: TabItem.blue),
      ],
      onTap: (index) => onSelectTab!(
        TabItem.values[index],
      ),
    );
  }

  BottomNavigationBarItem _buildItem({required TabItem tabItem}) {
    String? text = tabName[tabItem];
    IconData icon = Icons.layers;
    return BottomNavigationBarItem(
      icon: Icon(
        icon,
        color: _colorTabMatching(item: tabItem),
      ),
    );
  }

  MaterialColor? _colorTabMatching({required TabItem item}) {
    return currentTab == item ? activeTabColor[item] : Colors.grey;
  }
}
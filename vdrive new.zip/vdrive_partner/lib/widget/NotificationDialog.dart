import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/models/tripdetails.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/screens/newtripspage.dart';
import 'package:vdriver_partner/widget/brandDivider.dart';
import 'package:vdriver_partner/widget/ProgressDialog.dart';
import 'package:vdriver_partner/widget/FareButton.dart';
import 'package:vdriver_partner/widget/FareOutlineButton.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:toast/toast.dart';
import '../statics.dart' as Static;

class NotificationDialog extends StatelessWidget {
  final TripDetails? tripDetails;

  const NotificationDialog({Key? key, this.tripDetails}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      elevation: 0.0,
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(4),
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(4)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(
              height: 30.0,
            ),
            Image.asset(
              'images/taxi.png',
              width: 100,
            ),
            const SizedBox(
              height: 16.0,
            ),
            Text(
              tripDetails?.rideType == 'ride'
                  ? 'New Ride Request'
                  : 'New Help Request',
              style: const TextStyle(fontFamily: 'Brand-Bold', fontSize: 18),
            ),
            const SizedBox(
              height: 30.0,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Image.asset(
                        'images/pickicon-dark.png',
                        height: 16,
                        width: 16,
                      ),
                      const SizedBox(
                        width: 18,
                      ),
                      Expanded(
                          child: Container(
                              child: Text(
                        tripDetails?.pickupAddress ?? '',
                        style: const TextStyle(fontSize: 18),
                      )))
                    ],
                  ),
                  tripDetails?.rideType == 'ride'
                      ? const SizedBox(
                          height: 15,
                        )
                      : const SizedBox(),
                  tripDetails?.rideType == 'ride'
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Image.asset(
                              'images/desticon-dark.png',
                              height: 16,
                              width: 16,
                            ),
                            const SizedBox(
                              width: 18,
                            ),
                            Expanded(
                                child: Container(
                                    child: Text(
                              tripDetails?.destinationAddress ?? '',
                              style: const TextStyle(fontSize: 18),
                            )))
                          ],
                        )
                      : const SizedBox(),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const BrandDivider(),
            const SizedBox(
              height: 8,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      child: FareOutlineButton(
                        title: 'DECLINE',
                        color: Static.primaryColorblue,
                        onPressed: () async {
                          // assetsAudioPlayer.stop();
                          Navigator.pop(context);
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Container(
                      child: FareButton(
                        title: 'ACCEPT',
                        color: Static.secondaryColorSharp,
                        onPressed: () async {
                          assetsAudioPlayer.stop();
                          checkAvailablity(context);
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10.0,
            ),
          ],
        ),
      ),
    );
  }

  void checkAvailablity(context) async {
    //show please wait dialog
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const ProgressDialog(
        status: 'Accepting request',
      ),
    );

    final newRideRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('newtrip');

    newRideRef.once().then((e) async {
      final DataSnapshot = e.snapshot;
      Navigator.pop(context);
      Navigator.pop(context);

      String thisRideID = "";
      if (DataSnapshot != null) {
        thisRideID = DataSnapshot.value.toString();
      } else {
        Toast.show("Request not found",
            duration: Toast.lengthShort, gravity: Toast.bottom);
      }
      if (thisRideID == tripDetails?.rideID) {
        newRideRef.set('accepted');
        MainController.disableHomTabLocationUpdates();
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => NewTripPage(
                tripDetails: tripDetails,
              ),
            ));
      } else if (thisRideID == 'cancelled') {
        Toast.show("Request has been cancelled",
            duration: Toast.lengthShort, gravity: Toast.bottom);
      } else if (thisRideID == 'timeout') {
        Toast.show("Request has timed out",
            duration: Toast.lengthShort, gravity: Toast.bottom);
      } else {
        Toast.show("Request not found",
            duration: Toast.lengthShort, gravity: Toast.bottom);
      }
    });
  }
}

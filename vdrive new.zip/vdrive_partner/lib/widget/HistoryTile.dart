import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/helpers/MainController.dart';
import 'package:vdriver_partner/models/history.dart';
import 'package:flutter/material.dart';
import '../statics.dart' as Static;

class HistoryTile extends StatelessWidget {
  History history;
  HistoryTile({Key? key, required this.history}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Row(
                  children: <Widget>[
                    Image.asset(
                      'images/pickicon-dark.png',
                      height: 16,
                      width: 16,
                    ),
                    const SizedBox(
                      width: 18,
                    ),
                    Expanded(
                        child: Container(
                            child: Text(
                      history.pickup != null ? history.pickup.toString() : '',
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 18),
                    ))),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      '$currencySymbol${history.fares != 'null' ? history.fares : '0'}',
                      style: const TextStyle(
                          fontFamily: 'Brand-Bold',
                          fontSize: 16,
                          color: Static.colorPrimary),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 8,
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  Image.asset(
                    'images/desticon-dark.png',
                    height: 16,
                    width: 16,
                  ),
                  const SizedBox(
                    width: 18,
                  ),
                  Text(
                    history.destination != null
                        ? history.destination.toString()
                        : '',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 18),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Text(
                MainController.formatMyDate(
                  history.createdAt != null ? history.createdAt.toString() : '',
                ),
                style: const TextStyle(color: Static.colorTextLight),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

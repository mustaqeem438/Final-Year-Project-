import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/styles/styles.dart';
import 'package:vdriver_partner/screens/earnings.dart';
import 'package:vdriver_partner/widget/fareAboutDialog.dart';
import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as Static;
import 'package:flutter_feather_icons/flutter_feather_icons.dart';

class AppDrawer extends StatefulWidget {
  const AppDrawer({
    Key? key,
  }) : super(key: key);

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.all(0),
        children: <Widget>[
          Container(
            height: 160,
            color: Colors.white,
            child: DrawerHeader(
              decoration: const BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                    image: AssetImage("images/drawerbg.jpg"),
                    fit: BoxFit.cover),
              ),
              child: Row(
                children: <Widget>[
                  Image.asset('images/user_icon.png', height: 60, width: 60),
                  const SizedBox(
                    width: 15,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${UserPreferences.getUsername() != null ? UserPreferences.getUsername()?.toUpperCase() : fullname?.toUpperCase()}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontFamily: 'Brand-Bold',
                          color: Colors.black,
                        ),
                      ),
                      const Text(
                        '5.0 Rating',
                        style: TextStyle(
                          fontSize: 13,
                          fontFamily: 'Brand-Regular',
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          //
          const SizedBox(height: 10),
          //
          MaterialButton(
            onPressed: () {},
            child: ListTile(
              selectedTileColor: Static.colorLightGrayFair,
              leading:
                  const Icon(FeatherIcons.gift, color: Static.primaryColorblue),
              title: Text('Free Rides', style: kDrawerItemStyle),
            ),
          ),
          //
          MaterialButton(
            onPressed: () {
              setState(() {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Earnings( type: 'navigation',)),
                );
              });
            },
            child: ListTile(
              leading: const Icon(FeatherIcons.creditCard,
                  color: Static.primaryColorblue),
              title: Text('Earnings', style: kDrawerItemStyle),
            ),
          ),

          MaterialButton(
            onPressed: () {},
            child: ListTile(
              leading: const Icon(FeatherIcons.dollarSign,
                  color: Static.primaryColorblue),
              title: Text('Pay to Admin', style: kDrawerItemStyle),
            ),
          ),

          // MaterialButton(
          //   onPressed: () {
          //     MainController.changeTab('profile');
          //   },
          //   child: ListTile(
          //     leading: Icon(FeatherIcons.user, color: Static.primaryColorblue),
          //     title: Text('My Account', style: kDrawerItemStyle),
          //   ),
          // ),
          //
          MaterialButton(
            onPressed: () {},
            child: ListTile(
              leading: const Icon(FeatherIcons.phoneCall,
                  color: Static.primaryColorblue),
              title: Text('Support', style: kDrawerItemStyle),
            ),
          ),

          MaterialButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) => const Center(
                  child: FareAboutDialog(),
                ),
              );
            },
            child: ListTile(
              leading:
                  const Icon(FeatherIcons.info, color: Static.primaryColorblue),
              title: Text('About', style: kDrawerItemStyle),
            ),
          ),
          const SizedBox(height: 40),

          Image.asset(
            'images/logo.png',
            height: 50,
          ),
          const SizedBox(height: 10),
          Center(
              child: Text(
            '$appName v1.0.0',
            style: const TextStyle(color: Static.colorTextLight),
          )),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:vdriver_partner/statics.dart' as Static;

class DataLoadedProgress extends StatelessWidget {
  const DataLoadedProgress({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const CircularProgressIndicator(
      valueColor: AlwaysStoppedAnimation<Color>(Static.secondaryColorSharp),
    );
  }
}

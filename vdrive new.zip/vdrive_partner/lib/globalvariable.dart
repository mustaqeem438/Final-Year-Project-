import 'dart:async';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:vdriver_partner/models/driver.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

const CameraPosition googlePlex = CameraPosition(
  target: LatLng(24.860966, 66.990501),
  zoom: 14.4746,
);

StreamSubscription<Position>? HomePagePositionStream;

StreamSubscription<Position>? ridePositionStream;

User? currentFirebaseUser;

Driver? CurrentDriverInfo;

final assetsAudioPlayer = AssetsAudioPlayer();

String? fullname;
String? userPhone;

DatabaseReference? rideRef;

TabController? tabController;
int selecetdIndex = 0;

// Global Durations
const repeatTime = Duration(seconds: 2); // Function Repeater
const pageLoadAnimation = Duration(milliseconds: 150); // Page Loading

// App Padding
double leftPadding = 13;
double rightPadding = 13;
double topPadding = 0;
double bottomPadding = 0;

// Earnings Variables
String? getUserEarning = '';
bool earningDataLoading = true;
bool earningsCountLoaded = false;
double dueBalanceValue = 0;



List<Map<String, dynamic>> rentalHistoryList = [];

bool rentalHistoryLoaded = false;
bool rentalDataLoaded = false;


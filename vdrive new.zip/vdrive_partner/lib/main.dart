// ignore_for_file: prefer_const_constructors

import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:vdriver_partner/screens/Authentication/otp.dart';
import 'package:vdriver_partner/screens/Authentication/register.dart';
import 'package:vdriver_partner/screens/account.dart';
import 'package:vdriver_partner/screens/history.dart';
import 'package:vdriver_partner/screens/Authentication/vehicleinfo.dart';
import 'package:vdriver_partner/screens/homepage.dart';
import 'package:vdriver_partner/screens/loginpage.dart';
import 'package:vdriver_partner/screens/registerationpage.dart';
import 'package:vdriver_partner/screens/tabspage.dart';
import 'package:vdriver_partner/screens/uploadCarImags.dart';
import 'package:vdriver_partner/theme.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:provider/provider.dart';
import 'provider/Appdata.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  currentFirebaseUser = FirebaseAuth.instance.currentUser;

  await UserPreferences.init();

  await Future.delayed(const Duration(seconds: 2), () {
    FlutterNativeSplash.remove();
  });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AppData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: myTheme,
        initialRoute: (currentFirebaseUser == null)
            ? LoginPage.id
            : TabsPage.id,
        routes: {
          // Upload.id: (context) => Upload(),
          Account.id: (context) => Account(),
          TabsPage.id: (context) => TabsPage(),
          HomePage.id: (context) => HomePage(),
          OtpPage.id: (context) => OtpPage(),
          Register.id: (context) => Register(),
          RegistrationPage.id: (context) => RegistrationPage(),
          LoginPage.id: (context) => LoginPage(),
          VehicleInfoPage.id: (context) => VehicleInfoPage(),
          HistoryPage.id: (context) => HistoryPage(),
        },
      ),
    );
  }
}

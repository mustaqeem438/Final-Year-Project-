import 'dart:io';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:vdriver_partner/models/tripdetails.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/widget/NotificationDialog.dart';
import 'package:vdriver_partner/widget/progressDialog.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class PushNotificationService {
  final FirebaseMessaging fcm = FirebaseMessaging.instance;

  Future<void> _firebaseMessagingBackgroundHandler(
      RemoteMessage message) async {
    await Firebase.initializeApp();
  }

  Future initialize(context) async {
    // FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    await fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (Platform.isAndroid) {
        String rideId = message.data['ride_id'];
        print('Ride ID $rideId');
        if (getRideType(message) == 'help') {
          fetchHelpRequestInfo(
              getRideID(message), getRideType(message), context);
        }
        if (getRideType(message) == 'ride') {
          fetchRideInfo(getRideID(message), getRideType(message), context);
        }
      }
      if (message.notification != null) {
        print('Message Data: ${message.notification?.toMap()}');
      }
    });
  }

  Future getToken() async {
    String? token = await fcm.getToken();
    print('token: $token');

    DatabaseReference tokenRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('token');
    tokenRef.set(token);

    fcm.subscribeToTopic('alldrivers');
    fcm.subscribeToTopic('allusers');
  }

  String getRideID(RemoteMessage message) {
    String rideID = '';

    if (Platform.isAndroid) {
      rideID = message.data['ride_id'];
    }
    return rideID;
  }

  String getRideType(RemoteMessage message) {
    String rideType = '';

    rideType = message.data['type'];
    return rideType;
  }

  void fetchRideInfo(String rideID, String rideType, context) async {
    //show please wait dialog
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const ProgressDialog(
        status: 'Incoming Request',
      ),
    );
    final rideRef =
        FirebaseDatabase.instance.ref().child('rideRequest').child(rideID);
    rideRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      // assetsAudioPlayer.open(
      //   Audio("sounds/alert.mp3"),
      //   autoStart: false,
      //   // loopMode: LoopMode.single,
      // );
      // assetsAudioPlayer.setLoopMode(LoopMode.single);
      // assetsAudioPlayer.play();

      double pickupLat = double.parse(
          DataSnapshot.child('location').child('latitude').value.toString());

      double pickupLng = double.parse(
          DataSnapshot.child('location').child('longitude').value.toString());

      String pickupAddress =
          DataSnapshot.child('pickup_address').value.toString();

      //

      double destinationLat = double.parse(
          DataSnapshot.child('destination').child('latitude').value.toString());
      double destinationLng = double.parse(DataSnapshot.child('destination')
          .child('longitude')
          .value
          .toString());
      String destinationAddress =
          DataSnapshot.child('destination_address').value.toString();
      // String paymentMethod =
      //     DataSnapshot.child('payment_method').value.toString();
      String paymentMethod = 'cash';
      String riderName = DataSnapshot.child('rider_name').value.toString();
      String riderPhone = DataSnapshot.child('rider_phone').value.toString();

      TripDetails tripDetails = TripDetails();

      tripDetails.rideType = rideType;
      tripDetails.rideID = rideID;
      tripDetails.pickupAddress = pickupAddress;
      tripDetails.riderName = riderName;
      tripDetails.riderPhone = riderPhone;
      tripDetails.destinationAddress = destinationAddress;
      tripDetails.pickup = LatLng(pickupLat, pickupLng);
      tripDetails.destination = LatLng(destinationLat, destinationLng);
      tripDetails.paymentMethod = paymentMethod;

      Navigator.pop(context);
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => NotificationDialog(
          tripDetails: tripDetails,
        ),
      );
    });
  }

  void fetchHelpRequestInfo(String rideID, String rideType, context) async {
    //show please wait dialog
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const ProgressDialog(
        status: 'Incoming Request',
      ),
    );
    final rideRef =
        FirebaseDatabase.instance.ref().child('rideRequest').child(rideID);
    rideRef.once().then((e) async {
      final DataSnapshot = e.snapshot;
      Navigator.pop(context);

      // assetsAudioPlayer.open(
      //   Audio("sounds/alert.mp3"),
      //   autoStart: false,
      //   // loopMode: LoopMode.single,
      // );
      // assetsAudioPlayer.setLoopMode(LoopMode.single);
      // assetsAudioPlayer.play();

      double pickupLat = double.parse(
          DataSnapshot.child('location').child('latitude').value.toString());

      double pickupLng = double.parse(
          DataSnapshot.child('location').child('longitude').value.toString());

      String pickupAddress =
          DataSnapshot.child('pickup_address').value.toString();

      //

      String paymentMethod =
          DataSnapshot.child('payment_method').value.toString();
      String riderName = DataSnapshot.child('rider_name').value.toString();
      String riderPhone = DataSnapshot.child('rider_phone').value.toString();

      TripDetails tripDetails = TripDetails();

      tripDetails.rideType = rideType;
      tripDetails.rideID = rideID;
      tripDetails.pickupAddress = pickupAddress;
      tripDetails.riderName = riderName;
      tripDetails.riderPhone = riderPhone;
      tripDetails.pickup = LatLng(pickupLat, pickupLng);
      tripDetails.paymentMethod = paymentMethod;

      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => NotificationDialog(
          tripDetails: tripDetails,
        ),
      );
    });
  }
}

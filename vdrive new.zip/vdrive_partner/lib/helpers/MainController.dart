import 'dart:math';

import 'package:vdriver_partner/config.dart';
import 'package:vdriver_partner/models/directiondetails.dart';
import 'package:vdriver_partner/models/driver.dart';
import 'package:vdriver_partner/globalvariable.dart';
import 'package:vdriver_partner/helpers/requesthelper.dart';
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../provider/Appdata.dart';
import '../models/history.dart';
import '../widget/ProgressDialog.dart';
import 'package:intl/intl.dart';

class MainController {
  static void changeTab(String title) {
    switch (title) {
      case 'home':
        selecetdIndex = 0;
        tabController?.index = 0;
        break;
      case 'earning':
        selecetdIndex = 1;
        tabController?.index = 1;
        break;
      case 'rating':
        selecetdIndex = 2;
        tabController?.index = 2;
        break;
      case 'profile':
        selecetdIndex = 3;
        tabController?.index = 3;
        break;
      case 'history':
        selecetdIndex = 4;
        tabController?.index = 4;
        break;
      default:
        selecetdIndex = 0;
        tabController?.index = 0;
    }
  }

// Capitalize
  static String capitalize(String str) {
    return str
        .split(' ')
        .map((word) => word.substring(0, 1).toUpperCase() + word.substring(1))
        .join(' ');
  }

  static String generateRandomString(int length) {
    const String _chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random _random = Random();
    String result = '';

    for (int i = 0; i < length; i++) {
      result += _chars[_random.nextInt(_chars.length)];
    }

    return result;
  }

  static void getCurrentDriverInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
    });
  }

  static mapStyle() {
    return '''
            [
                {
                    "featureType": "all",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#7c93a3"
                        },
                        {
                            "lightness": "-10"
                        }
                    ]
                },
                {
                    "featureType": "administrative.country",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "administrative.country",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#c2d1d6"
                        }
                    ]
                },
                {
                    "featureType": "landscape",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#dde3e3"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#c2d1d6"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#a9b4b8"
                        },
                        {
                            "lightness": "0"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#a3c7df"
                        }
                    ]
                }
            ]
            ''';
  }

  static void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("users").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentDriverInfo = Driver.fromSnapshot(DataSnapshot);
      if (CurrentDriverInfo?.fullName.toString() == null) {
        fullname = UserPreferences.getUsername() ?? '';
      } else {
        fullname = CurrentDriverInfo?.fullName.toString();
        UserPreferences.setUsername(fullname!);
      }
      if (CurrentDriverInfo?.phone.toString() == null) {
        userPhone = UserPreferences.getUserPhone() ?? '';
      } else {
        userPhone = CurrentDriverInfo?.phone.toString();
        UserPreferences.setUserPhone(userPhone!);
      }
    });
  }

  static Future<DirectionDetails> getDirectionDetails(
      LatLng startPosition, LatLng endPosition) async {
    var url = Uri.parse(
        'https://maps.googleapis.com/maps/api/directions/json?origin=${startPosition.latitude},${startPosition.longitude}&destination=${endPosition.latitude},${endPosition.longitude}&mode=driving&key=$mapKey');

    var response = await RequestHelper.getRequest(url);

    if (response == 'failed') {}

    DirectionDetails directionDetails = DirectionDetails();

    try {
      directionDetails.durationText =
          response['routes'][0]['legs'][0]['duration']['text'];
      directionDetails.durationValue =
          response['routes'][0]['legs'][0]['duration']['value'];

      directionDetails.distanceText =
          response['routes'][0]['legs'][0]['distance']['text'];
      directionDetails.distanceValue =
          response['routes'][0]['legs'][0]['distance']['value'];

      directionDetails.encodedPoints =
          response['routes'][0]['overview_polyline']['points'];
    } catch (e) {
      print(e.toString());
    }

    print(directionDetails.durationText);
    print(directionDetails.durationValue);
    print(directionDetails.distanceText);
    print(directionDetails.distanceValue);
    return directionDetails;
  }

  static void disableHomTabLocationUpdates() {
    HomePagePositionStream?.pause();
    Geofire.removeLocation(currentFirebaseUser!.uid);
  }

  static void enableHomTabLocationUpdates() async {
    late Position currentPosition;

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;

    HomePagePositionStream?.resume();
    Geofire.setLocation(currentFirebaseUser!.uid, currentPosition.latitude,
        currentPosition.longitude);
  }

  static void showProgressDialog(context) {
    //show please wait dialog
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => ProgressDialog(
        status: 'Please wait',
      ),
    );
  }

  static int estimateFaresCar(DirectionDetails details, int durationValue) {
    int? baseFareValue = 15;
    int? distanceFareValue = 17;
    int? timeFareValue = 0;

    int baseFare = baseFareValue;
    double distanceFare = (details.distanceValue / 1000) * distanceFareValue;
    double timeFare = (durationValue / 60) * timeFareValue;

    double totalFare = baseFare + distanceFare + timeFare;

    return totalFare.truncate();
  }

  static void getHistoryInfo(context) async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    DatabaseReference earningRef = FirebaseDatabase.instance
        .ref()
        .child('drivers/${currentFirebaseUser!.uid}/earnings');

    earningRef.once().then((e) async {
      final snapshot = e.snapshot;
      String earnings = snapshot.value.toString();
      Provider.of<AppData>(context, listen: false).updateEarnings(earnings);
    });

    DatabaseReference historyRef = FirebaseDatabase.instance
        .ref()
        .child('drivers/${currentFirebaseUser?.uid}/history');

    historyRef.once().then((e) async {
      final snapshot = e.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;
      snapshot.value;
      int tripCount = values.length;

      // update trip count to data provider
      Provider.of<AppData>(context, listen: false).updateTripCount(tripCount);

      List<String> tripHistoryKeys = [];
      values.forEach((key, value) {
        tripHistoryKeys.add(key);
      });

      // update trip keys to data provider
      Provider.of<AppData>(context, listen: false)
          .updateTripKeys(tripHistoryKeys);

      getHistoryData(context);
    });
  }

  static void getHistoryData(context) {
    var keys = Provider.of<AppData>(context, listen: false).tripHistoryKeys;

    for (String key in keys) {
      DatabaseReference historyRef =
          FirebaseDatabase.instance.ref().child('rideRequest/$key');

      historyRef.once().then((e) async {
        final snapshot = e.snapshot;
        if (snapshot.value != null) {
          var history = History.fromSnapshot(snapshot);
          Provider.of<AppData>(context, listen: false)
              .updateTripHistory(history);

          print(history.destination);
        }
      });
    }
  }

  static String formatMyDate(String datestring) {
    DateTime thisDate = DateTime.parse(datestring);
    String formattedDate =
        '${DateFormat.MMMd().format(thisDate)}, ${DateFormat.y().format(thisDate)} - ${DateFormat.jm().format(thisDate)}';

    return formattedDate;
  }

  // Check Earnings
  static void checkEarning() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;
    final userRef =
        FirebaseDatabase.instance.ref().child("drivers").child(userid!);

    userRef.once().then((e) async {
      final _dataSnapshot = e.snapshot;

      earningsCountLoaded = true;
      earningDataLoading = false;
      CurrentDriverInfo = Driver.fromSnapshot(_dataSnapshot);
      String getEarning = _dataSnapshot.child('earnings').value.toString();
      if (getEarning.isEmpty) {
        if (UserPreferences.getUserEarning() != null) {
          getUserEarning = UserPreferences.getUserEarning();
        } else {
          getUserEarning = '';
        }
      } else {
        getUserEarning = getEarning;
        UserPreferences.setUserEarning(getUserEarning!);
      }
    });
  }

  static void dueBalance() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    final earningsRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(currentFirebaseUser!.uid)
        .child('earnings');

    earningsRef.once().then((e) async {
      final _dataSnapshot = e.snapshot;

      if (_dataSnapshot.value != null) {
        double oldEarnings = double.parse(_dataSnapshot.value.toString());
        double getDueBalance = (oldEarnings.toDouble() * vendorFee! / 100);

        if (getDueBalance.toString().isEmpty) {
          if (UserPreferences.getDueBalance() != null) {
            dueBalanceValue =
                double.parse(UserPreferences.getDueBalance().toString());
          } else {
            dueBalanceValue = 0;
          }
        } else {
          dueBalanceValue = getDueBalance;
          UserPreferences.setDueBalance(getDueBalance.toString());
        }
      }
    });
  }
}

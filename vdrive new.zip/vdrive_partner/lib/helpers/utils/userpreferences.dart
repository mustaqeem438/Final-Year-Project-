import 'package:shared_preferences/shared_preferences.dart';

class UserPreferences {
  static SharedPreferences? _preferences;

  static const _keyUsername = 'username';
  static const _keyPhone = 'phone';
  static const _keyCarRate = 'carRate';
  static const _keyCarModel = 'carRate';
  static const _keyCarColor = 'carRate';
  static const _keyCarNmbr = 'carRate';
  static const _keyEmail = 'email';
  static const _keyEarning = 'earning';
  static const _keyDueBalance = 'duebalance';

  static Future init() async =>
      _preferences = await SharedPreferences.getInstance();

  static Future setUsername(String username) async =>
      await _preferences?.setString(_keyUsername, username);

  static String? getUsername() => _preferences?.getString(_keyUsername);

  static Future setUserPhone(String phone) async =>
      await _preferences?.setString(_keyPhone, phone);

  static String? getUserPhone() => _preferences?.getString(_keyPhone);

  static Future setUserCarRate(String carRate) async =>
      await _preferences?.setString(_keyCarRate, carRate);

  static String? getUserCarRate() => _preferences?.getString(_keyCarRate);

  static Future setUserCarColor(String carColor) async =>
      await _preferences?.setString(_keyCarColor, carColor);

  static String? getUserCarColor() => _preferences?.getString(_keyCarColor);

  static Future setUserCarModel(String carModel) async =>
      await _preferences?.setString(_keyCarModel, carModel);

  static String? getUserCarModel() => _preferences?.getString(_keyCarModel);

  static Future setUserCarNmbr(String carNmbr) async =>
      await _preferences?.setString(_keyCarNmbr, carNmbr);

  static String? getUserCarNmbr() => _preferences?.getString(_keyCarNmbr);

  static Future setUserEmail(String email) async =>
      await _preferences?.setString(_keyEmail, email);

  static String? getUserEmail() => _preferences?.getString(_keyEmail);

  static Future setUserEarning(String earning) async =>
      await _preferences?.setString(_keyEarning, earning);

  static String? getUserEarning() => _preferences?.getString(_keyEarning);

  static Future setDueBalance(String duebalance) async =>
      await _preferences?.setString(_keyDueBalance, duebalance);

  static String? getDueBalance() => _preferences?.getString(_keyDueBalance);
}

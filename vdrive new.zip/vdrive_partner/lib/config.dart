// You Google Maps API
import 'package:vdriver_partner/helpers/utils/userpreferences.dart';

String mapKey = 'AIzaSyDQSc6o6InOQgEPbsgmrTPIsGQCRBXap7A';

String serverKey =
    'AAAAQtrXTTI:APA91bFoI5HU9XLZ0ZC8JkkEoAH6crx7Ei0OX3r_lMx6ffE_ru4rhy7os-cX1TymsjSLp9R4FpaVHLDzzYe2Wmzk9IhaIFeTmIlDdyWIeR6ySJS0buCoA-nW1g408B8FvyyPmQCoYNPp';

// General Info
String? appName = 'VDrive Partner';
String? appVersion = '1.0.0';
String? currencySymbol = 'Rs.';

// Support Contacts
String? supportWhatsapp = '+1234567890';
String? supportPhone = '+1234567890';

// Bank Account Details
String? bankName = 'Bank Name Here';
String? accountNumber = 'Account Number Here';
String? accountTitle = 'Account Title Here';
String? ibanNumber = 'IBAN Number Here';

// Vendor Fee
double? vendorFee = double.parse('8.5');
double? dueLimit = double.parse('200');

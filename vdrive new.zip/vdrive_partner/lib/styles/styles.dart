import 'package:flutter/material.dart';

final kDrawerItemStyle = TextStyle(fontSize: 16);

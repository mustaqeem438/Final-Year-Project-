// https://fcm.googleapis.com/fcm/send

// key=AAAAQtrXTTI:APA91bFoI5HU9XLZ0ZC8JkkEoAH6crx7Ei0OX3r_lMx6ffE_ru4rhy7os-cX1TymsjSLp9R4FpaVHLDzzYe2Wmzk9IhaIFeTmIlDdyWIeR6ySJS0buCoA-nW1g408B8FvyyPmQCoYNPp

// application/json
// Content-Type
// Authorization



// {
//     "notification": {
//         "body": "Techno City",
//         "title": "New Trip Request"
//     },
//     "priority": "high",
//     "data": {
//         "click_action": "FLUTTER_NOTIFICATION_CLICK",
//         "id": "1",
//         "status": "done",
//         "ride_id": "-N4dZZqEhmgWqSFQd2va"
//     },
//     "to": "ftkJHxszTyiQeWszCF2XGl:APA91bGTezdDuMi0jPegmulH9Nobj_aB155FT3OLHhR6jJEJM52nYdYaQp-FJBlgTtcfK-yNqE-2-VmPTPccwOEfi3e1o7qpNkjznAwl7szFC9lDDzZdoDbjOUZiBmTJQ3OyLidX14j4"
// }
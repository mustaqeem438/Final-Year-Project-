import 'package:vdrive/models/address.dart';
import 'package:vdrive/models/cars.dart';
import 'package:vdrive/models/historyModal.dart';
import 'package:flutter/cupertino.dart';

import '../views/onboarding/pages/boarding/data/onboard_page_data.dart';

class AppData extends ChangeNotifier {
  Address? pickupAddress;
  Address? destinationAddress;

  void updatePickupAddress(Address pickup) {
    pickupAddress = pickup;
    notifyListeners();
  }

  void updateDestinationAddress(Address destination) {
    destinationAddress = destination;
    notifyListeners();
  }

  Color _color = onboardData[0].accentColor; //default color

  Color get color => _color;

  set color(Color color) {
    _color = color;
    notifyListeners();
  }

  // User Order Services Lists
  List<String> requestKeys = [];
  List<String> requestServicesKeys = [];
  List<HistoryModal> requestdata = [];

  // Order Details Lists
  List<String> historyDetailsKeys = [];
  List<HistoryModal> historyDetailsData = [];

  // Orders Data
  void updateHistoryKeys(List<String> newKeys) {
    requestKeys = newKeys;
    notifyListeners();
  }

  void updateHistoryData(HistoryModal servicesItem) {
    requestdata.add(servicesItem);
    notifyListeners();
  }

}

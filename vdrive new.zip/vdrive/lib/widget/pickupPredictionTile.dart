import 'package:vdrive/models/address.dart';
import 'package:vdrive/models/prediction.dart';
import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/controller/requesthelper.dart';
import 'package:vdrive/widget/progressDialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:geolocator/geolocator.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:provider/provider.dart';

import '../config.dart';
import '../views/searchpage.dart';

class PickupPredicitionTile extends StatelessWidget {
  //
  final Prediction prediction;
  final String placename;
  const PickupPredicitionTile(
      {required this.prediction, required this.placename});

  static String pickuptext = '';
  //
  void getPlaceDetails(String PlaceID, context) async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => ProgressDialog(status: 'Please Wait'),
    );
    //
    var url = Uri.parse(
        'https://maps.googleapis.com/maps/api/place/details/json?placeid=$PlaceID&key=$mapKey&omponents=country:pk');

    var response = await RequestHelper.getRequest(url);

    Navigator.pop(context);

    if (response == 'failed') {
      return;
    }

    if (response['status'] == 'OK') {
      Address thisPlace = Address();

      thisPlace.placeName = response['result']['name'];
      thisPlace.placeId = PlaceID;
      thisPlace.latitude = response['result']['geometry']['location']['lat'];
      thisPlace.longitude = response['result']['geometry']['location']['lng'];

      Provider.of<AppData>(context, listen: false)
          .updatePickupAddress(thisPlace);

      print(thisPlace.placeName);

      var pickupLocation = pickupController.text;
      var destiLocation = destinationController.text;

      if (pickupLocation != '' && destiLocation != '') {
        // Navigator.pop(context, 'getDirection');
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => SearchPage(
                    placename: thisPlace.placeName,
                  )),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Fill All The Required Fileds!',
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () async {
        getPlaceDetails(prediction.placeId, context);
      },
      child: Container(
        child: Column(
          children: <Widget>[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(FeatherIcons.mapPin, color: Static.colorDimText),
                const SizedBox(width: 12),
                //
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(prediction.mainText,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                          style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 2.0),
                      //
                      Text(prediction.secondaryText,
                          style: const TextStyle(
                              overflow: TextOverflow.ellipsis,
                              fontSize: 12,
                              color: Static.colorDimText)),
                    ],
                  ),
                )
              ],
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

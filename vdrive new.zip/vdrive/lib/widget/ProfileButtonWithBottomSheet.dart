import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:vdrive/views/RentalHistoryPage.dart';
import 'package:vdrive/views/about.dart';
import 'package:vdrive/views/account.dart';
import 'package:vdrive/views/history.dart';
import 'package:vdrive/views/registerationpage.dart';
import 'package:vdrive/views/safety.dart';
import 'package:vdrive/views/termspage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/models/userdata.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:vdrive/widget/ProfileWidget.dart';

import '../utils/userpreferences.dart';

class ProfileButtonWithBottomSheet extends StatefulWidget {
  const ProfileButtonWithBottomSheet({
    Key? key,
    required this.getUserName,
    required this.getuserPhone,
    required this.pageIs,
  }) : super(key: key);

  final String? getUserName;
  final String? getuserPhone;
  final String? pageIs;

  @override
  State<ProfileButtonWithBottomSheet> createState() =>
      _ProfileButtonWithBottomSheetState();
}

class _ProfileButtonWithBottomSheetState
    extends State<ProfileButtonWithBottomSheet> {
  String? getUserName = '';
  String? getuserPhone = '';
  String? getuserEmail = '';

  Future<void> share() async {
    await FlutterShare.share(
      title: appName!,
      text:
          'Hi! I Used $appName and found very helpfull for Home Care Services try Now!',
      linkUrl: "https://play.google.com/store/apps/details?id="
          "com.vdrive.riderapp",
    );
  }

  Future<void> _signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("users").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentUserInfo = UserData.fromSnapshot(DataSnapshot);
      if (mounted) {
        var connectivityResults = await Connectivity().checkConnectivity();

        if (connectivityResults != ConnectivityResult.mobile &&
            connectivityResults != ConnectivityResult.wifi) {
          //
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'No Internet Connection',
              ),
            ),
          );
        } else {
          setState(() {
            if (CurrentUserInfo?.fullName.toString() == null) {
              getUserName = UserPreferences.getUsername() ?? '';
            } else {
              getUserName = CurrentUserInfo?.fullName.toString();
              UserPreferences.setUsername(getUserName!);
            }
            if (CurrentUserInfo?.phone.toString() == null) {
              getuserPhone = UserPreferences.getUserPhone() ?? '';
            } else {
              getuserPhone = CurrentUserInfo?.phone.toString();
              UserPreferences.setUserPhone(getuserPhone!);
            }
            if (CurrentUserInfo?.email.toString() == null) {
              getuserEmail = UserPreferences.getUserEmail() ?? '';
            } else {
              getuserEmail = CurrentUserInfo?.email.toString();
              UserPreferences.setUserEmail(getuserEmail!);
            }
          });
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      elevation: 0.0,
      hoverElevation: 0.0,
      focusElevation: 0.0,
      highlightElevation: 0.0,
      color: widget.pageIs == 'map' ? Static.primaryColorblue : Colors.white,
      minWidth: 15,
      height: 15,
      shape: const CircleBorder(),
      padding: EdgeInsets.all(widget.pageIs == 'map' ? 18 : 10),
      onPressed: () => showMaterialModalBottomSheet(
        backgroundColor: Static.dashboardBG,
        duration: const Duration(milliseconds: 200),
        context: context,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(20),
          ),
        ),
        builder: (context) => Padding(
          padding:
              const EdgeInsets.only(left: 24, top: 10, right: 24, bottom: 20),
          child: ListView(
            physics: const BouncingScrollPhysics(),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  MaterialButton(
                    onPressed: () => Navigator.pop(context),
                    elevation: 0.0,
                    hoverElevation: 0.0,
                    focusElevation: 0.0,
                    highlightElevation: 0.0,
                    color: Colors.transparent,
                    minWidth: 20,
                    height: 20,
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(15),
                    child: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
                  ),
                ],
              ),
              ProfileWidget(
                imagePath: 'images/user_icon.png',
                onClicked: () async {},
              ),
              const SizedBox(height: 24),
              // ignore: prefer_if_null_operators
              buildName(UserPreferences.getUsername() != null
                  ? UserPreferences.getUsername()
                  : getUserName),
              const SizedBox(height: 24),

              Center(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Static.dashboardCard,
                  ),
                  child: Column(
                    children: [
                      ProfileButton(
                        buttonName: 'Invite Friends',
                        onCLicked: () {
                          share();
                        },
                        icon: FeatherIcons.share2,
                      ),
                      const Divider(color: Colors.black12),
                      ProfileButton(
                        buttonName: 'Terms & Conditions',
                        onCLicked: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const TermsPage()));
                          //
                        },
                        icon: FeatherIcons.clipboard,
                      ),
                      const Divider(color: Colors.black12),
                      ProfileButton(
                        buttonName: 'About Us',
                        onCLicked: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const AboutPage()));
                        },
                        icon: FeatherIcons.info,
                      ),
                      const Divider(color: Colors.black12),
                      ProfileButton(
                        buttonName: 'Logout',
                        onCLicked: () {
                          _signOut().then((value) => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const RegistrationPage())));
                          //
                        },
                        icon: FeatherIcons.logOut,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                widget.pageIs == 'map'
                    ? const Icon(
                        FeatherIcons.user,
                        size: 25,
                        color: Colors.white,
                      )
                    : SvgPicture.asset(
                        'images/svg_icons/menu3.svg',
                        color: Colors.black,
                        width: 30,
                      ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget buildName(String? getUserName) => Column(
        children: [
          Text(
            '${UserPreferences.getUsername() ?? getUserName}',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
          ),
          const SizedBox(height: 4),
          Text(
            '${UserPreferences.getUserPhone() ?? widget.getuserPhone}',
            style: const TextStyle(color: Static.colorTextLight),
          )
        ],
      );
}

class ProfileButton extends StatelessWidget {
  final String buttonName;
  final IconData icon;
  final Function() onCLicked;
  //
  const ProfileButton({
    Key? key,
    required this.buttonName,
    required this.icon,
    required this.onCLicked,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: MaterialButton(
        elevation: 0.0,
        highlightElevation: 0.0,
        onPressed: onCLicked,
        padding: const EdgeInsets.all(8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundColor: Static.secondaryColor,
              child: Icon(
                icon,
                color: Colors.white,
                size: 20,
              ),
            ),
            SizedBox(
              width: 150,
              child: Text(
                buttonName,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(),
              ),
            ),
            const Icon(FeatherIcons.chevronRight),
          ],
        ),
      ),
    );
  }
}

// ignore_for_file: prefer_const_constructors

import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/views/Authentication/Database_Entry.dart';
import 'package:vdrive/views/Authentication/otp.dart';
import 'package:vdrive/views/homepage.dart';
import 'package:vdrive/views/loginpage.dart';
import 'package:vdrive/views/mainpage.dart';
import 'package:vdrive/views/onboarding/pages/boarding/onboarding.dart';
import 'package:vdrive/views/registerationpage.dart';
import 'package:provider/provider.dart';
import 'package:vdrive/theme.dart';
import 'package:vdrive/utils/userpreferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:vdrive/views/tabspage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Widget Binding
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();

  // Splash Screen
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  FlutterNativeSplash.remove();

  currentFirebaseUser = FirebaseAuth.instance.currentUser;

  await UserPreferences.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AppData(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: myTheme,
        initialRoute:
            currentFirebaseUser != null ? TabsPage.id : LoginPage.id,
        routes: {
          TabsPage.id: (context) => TabsPage(),
          HomePage.id: (context) => HomePage(),
          Mainpage.id: (context) => Mainpage(),
          Onboarding.id: (context) => Onboarding(),
          RegistrationPage.id: (context) => RegistrationPage(),
          LoginPage.id: (context) => LoginPage(),
          OtpPage.id: (context) => OtpPage(),
          DatabaeEntry.id: (context) => DatabaeEntry(),
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

get locationStatus => null;
locationPermision() async {
  PermissionStatus locationStatus = await Permission.location.request();

  if (locationStatus == PermissionStatus.denied) {
    PermissionStatus locationStatus = await Permission.location.request();
    openAppSettings();
  } else if (locationStatus == PermissionStatus.permanentlyDenied) {
    openAppSettings();
  }
}

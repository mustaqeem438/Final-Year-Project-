// ignore_for_file: file_names

import 'package:vdrive/models/historyModal.dart';
import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:provider/provider.dart';

class HistoryController {
  // Get Order Keys
  static void getHistoryInfo(context) async {
    DatabaseReference orderRef = FirebaseDatabase.instance
        .ref()
        .child('users')
        .child(currentFirebaseUser!.uid)
        .child('history');

    orderRef.once().then((e) async {
      final snapshot = e.snapshot;

      if (snapshot.exists && snapshot.value != "0") {
        Map<dynamic, dynamic> values = snapshot.value as Map;
        snapshot.value;

        List<String> servicesKeys = [];
        values.forEach((key, value) {
          servicesKeys.add(key);
        });
        Provider.of<AppData>(context, listen: false)
            .updateHistoryKeys(servicesKeys);
        getHistoryDataItems(context);
      } else {
        historyListLoaded = true;
      }
      historyDataLoaded = true;
      historyItemsList =
          Provider.of<AppData>(context, listen: false).requestdata;
    });
  }

  // Get Order Items Keys
  static void getHistoryDataItems(context) {
    var keys = Provider.of<AppData>(context, listen: false).requestKeys;

    for (String key in keys) {
      DatabaseReference currentReq =
          FirebaseDatabase.instance.ref().child('rideRequest').child(key);

      currentReq.once().then((e) async {
        final snapshot = e.snapshot;
        if (snapshot.value != null) {
          print(snapshot.value);
          var services = HistoryModal.fromSnapshot(snapshot);
          Provider.of<AppData>(context, listen: false)
              .updateHistoryData(services);
        }
      });
    }
    historyListLoaded = true;
  }
}

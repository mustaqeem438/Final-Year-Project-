import 'dart:convert';
import 'dart:math';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/models/address.dart';
import 'package:vdrive/models/directiondetails.dart';
import 'package:vdrive/models/userdata.dart';
import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/controller/requesthelper.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/utils/userpreferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

class MainController {
  //
  static Future<String> findCordinateAddress(Position position, context) async {
    String placeAddress = '';

    var connectivityResults = await Connectivity().checkConnectivity();

    if (connectivityResults != ConnectivityResult.mobile &&
        connectivityResults != ConnectivityResult.wifi) {
      return placeAddress;
    }

    var url = Uri.parse(
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=$mapKey');

    var response = await RequestHelper.getRequest(url);

    if (response != 'failed') {
      placeAddress = response['results'][0]['formatted_address'];

      // ignore: unnecessary_new
      Address pickupAddress = new Address(
          latitude: position.latitude,
          longitude: position.longitude,
          placeFormattedAddress: '',
          placeId: '',
          placeName: '');
      pickupAddress.longitude = position.longitude;
      pickupAddress.latitude = position.latitude;
      pickupAddress.placeName = placeAddress;

      Provider.of<AppData>(context, listen: false)
          .updatePickupAddress(pickupAddress);
    }

    return placeAddress;
  }

  static Future<DirectionDetails> getDirectionDetails(
      LatLng startPosition, LatLng endPosition) async {
    var url = Uri.parse(
        'https://maps.googleapis.com/maps/api/directions/json?origin=${startPosition.latitude},${startPosition.longitude}&destination=${endPosition.latitude},${endPosition.longitude}&mode=driving&key=$mapKey');

    var response = await RequestHelper.getRequest(url);

    if (response == 'failed') {}

    DirectionDetails directionDetails = DirectionDetails();

    try {
      directionDetails.durationText =
          response['routes'][0]['legs'][0]['duration']['text'];
      directionDetails.durationValue =
          response['routes'][0]['legs'][0]['duration']['value'];

      directionDetails.distanceText =
          response['routes'][0]['legs'][0]['distance']['text'];
      directionDetails.distanceValue =
          response['routes'][0]['legs'][0]['distance']['value'];

      directionDetails.encodedPoints =
          response['routes'][0]['overview_polyline']['points'];
    } catch (e) {
      print(e.toString());
    }

    print(directionDetails.durationText);
    print(directionDetails.durationValue);
    print(directionDetails.distanceText);
    print(directionDetails.distanceValue);
    return directionDetails;
  }

  static mapStyle() {
    return '''
            [
                {
                    "featureType": "all",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#7c93a3"
                        },
                        {
                            "lightness": "-10"
                        }
                    ]
                },
                {
                    "featureType": "administrative.country",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "visibility": "on"
                        }
                    ]
                },
                {
                    "featureType": "administrative.country",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#c2d1d6"
                        }
                    ]
                },
                {
                    "featureType": "landscape",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#dde3e3"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#c2d1d6"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#a9b4b8"
                        },
                        {
                            "lightness": "0"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#a3c7df"
                        }
                    ]
                }
            ]
            ''';
  }

  static int estimateFaresCar(DirectionDetails details) {
    int? baseFareValue = 50;
    int distanceFareValue = 10;
    int? timeFareValue = 5;

    int baseFare = baseFareValue;
    double distanceFare = (details.distanceValue / 1000) * distanceFareValue;
    double timeFare = (details.durationValue / 15) * timeFareValue;

    double totalFare =
        baseFare + double.parse(distanceFare.toStringAsFixed(0)) + timeFare;

    return totalFare.truncate();
  }

  static int estimateFaresBike(DirectionDetails details) {
    int? baseFareValue = 1;
    int distanceFareValue = 1;
    int? timeFareValue = 1;

    int baseFare = baseFareValue;
    double distanceFare = (details.distanceValue / 1000) * distanceFareValue;
    double timeFare = (details.durationValue / 60) * timeFareValue;

    double totalFare =
        baseFare + double.parse(distanceFare.toStringAsFixed(0)) + timeFare;

    return totalFare.truncate();
  }

//
  static void getCurrentUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;

    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("users").child(userid!);

    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentUserInfo = UserData.fromSnapshot(DataSnapshot);
    });
  }

  static void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("users").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      // ignore: unnecessary_null_comparison
      if (DataSnapshot != null) {
        CurrentUserInfo = UserData.fromSnapshot(DataSnapshot);
        if (CurrentUserInfo?.fullName.toString() == null) {
          getUserName = UserPreferences.getUsername() ?? '';
        } else {
          getUserName = CurrentUserInfo?.fullName.toString();
          UserPreferences.setUsername(getUserName!);
        }
        if (CurrentUserInfo?.phone.toString() == null) {
          getuserPhone = UserPreferences.getUserPhone() ?? '';
        } else {
          getuserPhone = CurrentUserInfo?.phone.toString();
          UserPreferences.setUserPhone(getuserPhone!);
        }
      }
    });
  }

  static double generateRandomNumber(int max) {
    var randomGenerator = Random();
    int randInt = randomGenerator.nextInt(max);

    return randInt.toDouble();
  }

  static String generateRandomString(int length) {
    const String chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    Random random = Random();
    String randomString = '';

    for (int i = 0; i < length; i++) {
      randomString += chars[random.nextInt(chars.length)];
    }

    return randomString;
  }

  static sendNotification(
      String token, context, String? rideId, String title, String type) async {
    Address? destination;
    if (type == 'help') {
      destination = Provider.of<AppData>(context, listen: false).pickupAddress;
    } else {
      destination =
          Provider.of<AppData>(context, listen: false).destinationAddress;
    }

    Map<String, String> headerMap = {
      'Content-Type': 'application/json',
      'Authorization': 'key=$serverKey',
    };

    Map notificationMap = {
      'title': title,
      'body': 'Destination, ${destination?.placeName}'
    };

    Map dataMap;

    if (type == 'help') {
      dataMap = {
        'click_action': 'FLUTTER_NOTIFICATION_CLICK',
        'id': '1',
        'status': 'done',
        'type': 'help',
        'ride_id': rideId,
      };
    } else {
      dataMap = {
        'click_action': 'FLUTTER_NOTIFICATION_CLICK',
        'id': '1',
        'status': 'done',
        'type': 'ride',
        'ride_id': rideId,
      };
    }

    Map bodyMap = {
      'notification': notificationMap,
      'data': dataMap,
      'priority': 'high',
      'to': token,
    };

    var response = await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: headerMap,
        body: jsonEncode(bodyMap));
  }

  static sendBookingNotification(String token, context, String? userid) async {
    Map<String, String> headerMap = {
      'Content-Type': 'application/json',
      'Authorization': 'key=$serverKey',
    };

    Map notificationMap = {
      'title': 'A New Car Rental Request',
      'body': 'A new car rental request is received'
    };

    Map dataMap;

    dataMap = {
      'click_action': 'FLUTTER_NOTIFICATION_CLICK',
      'id': '1',
      'status': 'done',
      'type': 'help',
      'ride_id': userid,
    };

    Map bodyMap = {
      'notification': notificationMap,
      'data': dataMap,
      'priority': 'high',
      'to': token,
    };

    var response = await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: headerMap,
        body: jsonEncode(bodyMap));
  }

// Capitalize
  static String capitalize(String str) {
    return str
        .split(' ')
        .map((word) => word.substring(0, 1).toUpperCase() + word.substring(1))
        .join(' ');
  }

  //  Bottom Sheet
  static void bottomSheet(context, String title, Function() onPressed) {
    showModalBottomSheet(
      enableDrag: true,
      isDismissible: false,
      backgroundColor: Colors.white,
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      builder: (context) => Padding(
        padding:
            const EdgeInsets.only(left: 40, top: 24, right: 24, bottom: 10),
        child: Wrap(
          children: [
            Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.black54,
                  ),
                  height: 4,
                  width: 50,
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 50, top: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MaterialButton(
                        onPressed: () => Navigator.pop(context),
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Colors.white,
                        textColor: Colors.black,
                        minWidth: 50,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 50,
                          vertical: 20,
                        ),
                        child: const Text('Cancel'),
                      ),
                      MaterialButton(
                        onPressed: onPressed,
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Colors.red,
                        textColor: Colors.white,
                        minWidth: 50,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 50,
                          vertical: 20,
                        ),
                        child: const Text('Confirm'),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

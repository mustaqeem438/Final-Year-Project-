// You Google Maps API
import 'package:vdrive/models/cars.dart';

String mapKey = 'AIzaSyDQSc6o6InOQgEPbsgmrTPIsGQCRBXap7A';

// Your Firebase App Server Key
String serverKey =
    'AAAAaKLHUaw:APA91bEjMdzwSDt6NnKtirmsEkbnSjz0ZTpk1O4J0Lpr8_K366Nw6Tdo7fz28xA1q6Wx0aq_5xcNE_djpelkcLY_W4ILXEceIFopELkT8kn8BNC6Lmah6kxZBN4b5fZZifrm4fVmjxQD';

// General Info
String? appName = 'vDrive';
String? appVersion = '1.0.0';

// Support Contacts
String? supportWhatsapp = '+1234567890';
String? supportPhone = '+1234567890';

String? currency = 'Rs.';

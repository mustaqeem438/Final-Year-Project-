import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/models/cars.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/views/termspage.dart';
import 'package:vdrive/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';
import 'package:custom_date_range_picker/custom_date_range_picker.dart';

class CarDetails extends StatefulWidget {
  final String? driverid;

  // Remove the const keyword from the constructor
  const CarDetails({
    Key? key,
    this.driverid,
  }) : super(key: key);

  static const String id = 'CarDetails';

  @override
  State<CarDetails> createState() => _CarDetailsState();
}

class _CarDetailsState extends State<CarDetails> {
  bool _isChecked = false;
  String driverToken = '';
  String driverName = '';
  String driverCNIC = '';
  String driverPhone = '';
  String vcolor = '';
  String vrate = '';
  String vModel = '';
  DateTime? startDate;
  DateTime? endDate;
  List<String> imageUrls = [];

  void getDetails() {
    DatabaseReference driverRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(widget.driverid!)
        .child('vehicle_details');

    driverRef.once().then((e) async {
      final snapshot = e.snapshot;

      carInfo = Cars.fromSnapshot(snapshot);

      setState(() {
        vcolor = carInfo!.vehicle_color.toString();
        vModel = carInfo!.vehicle_model.toString();
      });
    });
  }

  Future<List<String>> getCarImages() async {
    DatabaseReference driverRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(widget.driverid!)
        .child('vehicle_details')
        .child('images');

    driverRef.once().then((value) async {
      final snapshot = value.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;

      values.forEach((key, value) {
        imageUrls.add(value.toString());
      });
    });
    return imageUrls;
  }

  void getDriverDetails() {
    DatabaseReference driverRef = FirebaseDatabase.instance
        .ref()
        .child('drivers')
        .child(widget.driverid!);

    driverRef.once().then((e) async {
      final snapshot = e.snapshot;

      carInfo = Cars.fromSnapshot(snapshot);

      setState(() {
        driverName = snapshot.child('fullname').value.toString();
        driverCNIC = snapshot.child('cnic').value.toString();
        driverPhone = snapshot.child('phone').value.toString();
        driverToken = snapshot.child('token').value.toString();
        vrate = snapshot.child('carrate').value.toString();
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getDetails();
    getDriverDetails();
    getCarImages();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardCard,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: Text(
          vModel.isNotEmpty ? MainController.capitalize(vModel) : 'Car Details',
          style: const TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Scaffold(
        body: driverName.isNotEmpty
            ? SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
                  child: Column(
                    children: [
                      imageUrls.isNotEmpty
                          ? SizedBox(
                              width: MediaQuery.sizeOf(context).width,
                              height: 250,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(25),
                                child: PhotoViewGallery.builder(
                                  itemCount: imageUrls.length,
                                  builder: (context, index) {
                                    return PhotoViewGalleryPageOptions(
                                      imageProvider:
                                          NetworkImage(imageUrls[index]),
                                      minScale:
                                          PhotoViewComputedScale.covered * 1,
                                      maxScale:
                                          PhotoViewComputedScale.covered * 1.5,
                                    );
                                  },
                                  scrollPhysics: const BouncingScrollPhysics(),
                                  backgroundDecoration: const BoxDecoration(
                                    color: Colors.transparent,
                                  ),
                                  pageController: PageController(),
                                ),
                              ),
                            )
                          : const SizedBox(),
                      imageUrls.isNotEmpty
                          ? const Text(
                              '...',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 25),
                            )
                          : const SizedBox(),
                      const SizedBox(height: 10),
                      carItems(),
                      const SizedBox(height: 15),
                      driverToken.isNotEmpty ? agreement() : const SizedBox(),
                      driverToken.isNotEmpty ? button() : const SizedBox(),
                    ],
                  ),
                ),
              )
            : const SafeArea(
                child: Center(
                  child: DataLoadedProgress(),
                ),
              ),
      ),
    );
  }

  Widget agreement() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        // Other signup form fields here
        Row(
          children: [
            GestureDetector(
              onTap: () {
                setState(() {
                  if (_isChecked == false) {
                    _isChecked = true;
                  } else {
                    _isChecked = false;
                  }
                });
              },
              child: const Text('I agree to the '),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const TermsPage()));
              },
              child: const Text(
                'terms and conditions',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ),
        Checkbox(
          value: _isChecked,
          onChanged: (value) {
            setState(() {
              _isChecked = value!;
            });
          },
        ),
      ],
    );
  }

  Widget button() {
    return Padding(
      padding: const EdgeInsets.only(left: 30, right: 30),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: MaterialButton(
          color: _isChecked == false
              ? Colors.grey.shade400
              : appcolors.secondaryColorSharp,
          textColor: _isChecked == false ? Colors.grey : Colors.white,
          elevation: 0,
          hoverElevation: 0,
          focusElevation: 0,
          highlightElevation: 0,
          height: 50,
          minWidth: double.infinity,
          onPressed: () {
            if (_isChecked == true) {
              showCustomDateRangePicker(
                context,
                dismissible: true,
                minimumDate: DateTime.now().subtract(const Duration(days: 30)),
                maximumDate: DateTime.now().add(const Duration(days: 30)),
                endDate: endDate,
                startDate: startDate,
                backgroundColor: Colors.white,
                primaryColor: appcolors.secondaryColorSharp,
                onApplyClick: (start, end) {
                  setState(() {
                    endDate = end;
                    startDate = start;

                    const DataLoadedProgress();
                    MainController.sendBookingNotification(
                        driverToken, context, CurrentUserInfo!.id.toString());

                    // Get the current date and time
                    DateTime now = DateTime.now();

                    // Format the Created date and time
                    String formattedDate =
                        "${now.day}-${now.month}-${now.year}";
                    String formattedTime =
                        "${now.hour}:${now.minute}:${now.second}";

                    // Format Booking Dates
                    String formateEndDate =
                        "${endDate!.day}-${endDate!.month}-${endDate!.year}";
                    String formateStartDate =
                        "${start.day}-${start.month}-${start.year}";

                    String bookingid =
                        MainController.generateRandomString(28).toString();

                    DatabaseReference newUserRef = FirebaseDatabase.instance
                        .ref()
                        .child('bookingHistory/$bookingid');
                    // Prepare data to be saved on users table
                    Map dataMap = {
                      'bookingID': bookingid.toString(),
                      'bookedby': CurrentUserInfo!.id,
                      'bookedbyName': CurrentUserInfo!.fullName,
                      'bookedbyEmail': CurrentUserInfo!.email,
                      'bookedbyPhone': CurrentUserInfo!.phone,
                      'carowner': widget.driverid,
                      'carrate': vrate,
                      'ownerphone': driverPhone,
                      'ownername': driverName,
                      'vehicle_color': vcolor,
                      'vehicle_model': vModel,
                      'bookingTill': formateEndDate.toString(),
                      'bookingFrom': formateStartDate.toString(),
                      'createdDate': formattedDate,
                      'createdTime': formattedTime,
                      'status': 'Pending'
                    };

                    newUserRef.set(dataMap);

                    Navigator.pop(context);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Booking Request Successfull')));
                  });
                },
                onCancelClick: () {
                  setState(() {
                    endDate = null;
                    startDate = null;
                  });
                },
              );
            }
          },
          child: Text(
            'Book Now',
            style: TextStyle(
              color: _isChecked == false ? Colors.grey.shade50 : Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  Widget carItems() {
    return Container(
      padding: const EdgeInsets.only(top: 15, bottom: 15),
      width: double.infinity,
      height: 235,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: appcolors.dashboardBG,
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    driverName.isNotEmpty
                        ? MainController.capitalize(driverName)
                        : '',
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontFamily: 'Roboto-Regular',
                      color: Colors.black,
                      fontSize: 18,
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        driverCNIC.isNotEmpty
                            ? driverCNIC.substring(0, 6) +
                                '*' * (driverCNIC.length - 6)
                            : '',
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: 'Roboto-Regular',
                          color: Colors.black,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Icon(
                        Icons.check_circle_rounded,
                        size: 18,
                        color: Colors.blue,
                      )
                    ],
                  )
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Car Owner:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  driverName.isNotEmpty
                      ? MainController.capitalize(driverName)
                      : '',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Car Model:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  vModel.isNotEmpty ? MainController.capitalize(vModel) : '',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Car Color:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  vcolor.isNotEmpty ? MainController.capitalize(vcolor) : '',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 15),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Rate / day:',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  vrate != 'null' && vrate.isNotEmpty
                      ? currency! + MainController.capitalize(vrate)
                      : 'Not Defined',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto-Regular',
                    color: Colors.black38,
                    fontSize: 16,
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

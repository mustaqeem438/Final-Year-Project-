import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:motion_tab_bar_v2/motion-tab-bar.dart';
import 'package:vdrive/views/account.dart';
import 'package:vdrive/views/history.dart';
import 'package:vdrive/views/homepage.dart';
import 'package:vdrive/views/safety.dart';
import 'package:vdrive/statics.dart' as Static;

// optional, only if using provided badge style

class TabsPage extends StatefulWidget {
  static const String id = 'TabsPage';
  const TabsPage({Key? key}) : super(key: key);

  @override
  State<TabsPage> createState() => _TabsPageState();
}

class _TabsPageState extends State<TabsPage>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      initialIndex: 0,
      length: 4,
      vsync: this,
    );
  }

  @override
  void dispose() {
    super.dispose();
    _tabController!.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TabBarView(
        physics:
            const NeverScrollableScrollPhysics(), // swipe navigation handling is not supported
        controller: _tabController,
        children: const <Widget>[
          HomePage(),
          HistoryPage(),
          Account(),
          SafetyPage(),
        ],
      ),
      bottomNavigationBar: Directionality(
        textDirection: TextDirection.ltr,
        child: MotionTabBar(
          initialSelectedTab: "Home",

          labels: const ["Home", "History", "Profile", "Safety"],
          icons: const [
            FeatherIcons.home,
            FeatherIcons.clock,
            FeatherIcons.user,
            FeatherIcons.shield,
          ],

          // optional badges, length must be same with labels
          badges: const [
            //you can add badges on tabbar icons
          ],
          tabSize: 50,
          tabBarHeight: 60,
          textStyle: const TextStyle(fontSize: 12, color: Colors.white),
          tabIconColor: Colors.white,
          tabIconSize: 28.0,
          tabIconSelectedSize: 26.0,
          tabSelectedColor: Static.secondaryColor,
          tabIconSelectedColor: Colors.white,
          tabBarColor: Static.primaryColorblue,

          onTabItemSelected: (int value) {
            setState(() {
              _tabController!.index = value;
            });
          },
        ),
      ),
    );
  }
}

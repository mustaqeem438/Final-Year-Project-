import 'package:flutter_svg/svg.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/views/aboutMore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:vdrive/views/account.dart';
import 'package:vdrive/views/history.dart';
import 'package:vdrive/views/safetyTips.dart';
import 'package:vdrive/views/tabspage.dart';
import 'package:vdrive/widget/ProfileButtonWithBottomSheet.dart';

class SafetyPage extends StatefulWidget {
  const SafetyPage({Key? key}) : super(key: key);
  static const String id = 'SafetyPage';

  @override
  State<SafetyPage> createState() => _SafetyPageState();
}

class _SafetyPageState extends State<SafetyPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Static.dashboardCard,
      appBar: AppBar(
        backgroundColor: Static.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const TabsPage()));
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: const Text(
          'Safety',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 0,
                horizontal: 50,
              ),
              child: Column(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.blue.withOpacity(.2),
                          child: const Icon(
                            Icons.shield_outlined,
                            color: Colors.blue,
                            size: 40,
                          )),
                      const SizedBox(height: 15),
                      const Text(
                        'Who do you want to contact?',
                        style: TextStyle(
                          fontSize: 25,
                          fontFamily: 'Roboto-Bold',
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Static.dashboardCard,
                      ),
                      child: Column(
                        children: [
                          MaterialButton(
                            elevation: 0.0,
                            highlightElevation: 0.0,
                            onPressed: () {
                              launchUrl(Uri.parse("tel://115"));
                            },
                            padding: const EdgeInsets.all(8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  backgroundColor: Colors.white,
                                  child: Icon(
                                    FeatherIcons.phoneCall,
                                    color: Static.primaryColorblue,
                                    size: 20,
                                  ),
                                ),
                                SizedBox(
                                  width: 150,
                                  child: Text(
                                    'Ambulance',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                Icon(FeatherIcons.chevronRight),
                              ],
                            ),
                          ),
                          MaterialButton(
                            elevation: 0.0,
                            highlightElevation: 0.0,
                            onPressed: () {
                              launchUrl(Uri.parse("tel://15"));
                            },
                            padding: const EdgeInsets.all(8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  backgroundColor: Colors.white,
                                  child: Icon(
                                    FeatherIcons.phoneCall,
                                    color: Static.primaryColorblue,
                                    size: 20,
                                  ),
                                ),
                                SizedBox(
                                  width: 150,
                                  child: Text(
                                    'Police',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                Icon(FeatherIcons.chevronRight),
                              ],
                            ),
                          ),
                          // MaterialButton(
                          //   elevation: 0.0,
                          //   highlightElevation: 0.0,
                          //   onPressed: () {
                          //     Navigator.push(
                          //         context,
                          //         MaterialPageRoute(
                          //             builder: (context) =>
                          //                 const SafetyTipsPage()));
                          //   },
                          //   padding: const EdgeInsets.all(8),
                          //   shape: RoundedRectangleBorder(
                          //     borderRadius: BorderRadius.circular(12),
                          //   ),
                          //   child: const Row(
                          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          //     crossAxisAlignment: CrossAxisAlignment.center,
                          //     children: [
                          //       CircleAvatar(
                          //         backgroundColor: Colors.white,
                          //         child: Icon(
                          //           FeatherIcons.shield,
                          //           color: Static.primaryColorblue,
                          //           size: 20,
                          //         ),
                          //       ),
                          //       SizedBox(
                          //         width: 150,
                          //         child: Text(
                          //           'Safety Tips',
                          //           maxLines: 2,
                          //           overflow: TextOverflow.ellipsis,
                          //           style: TextStyle(
                          //             color: Colors.black,
                          //             fontWeight: FontWeight.w400,
                          //           ),
                          //         ),
                          //       ),
                          //       Icon(FeatherIcons.chevronRight),
                          //     ],
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

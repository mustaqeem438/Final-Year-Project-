import 'dart:async';
import 'dart:io';
import 'package:vdrive/controller/firehelper.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/models/userdata.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/views/RentalHistoryPage.dart';
import 'package:vdrive/views/carRentalScreen.dart';
import 'package:vdrive/views/mainpage.dart';
import 'package:vdrive/utils/userpreferences.dart';
import 'package:vdrive/views/roadAssistentScreen.dart';
import 'package:vdrive/widget/brandDivider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../models/nearbydriver.dart';
import '../permissions.dart';
import '../widget/DataLoadedProgress.dart';
import '../widget/ProfileButtonWithBottomSheet.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  static const String id = 'homepage';
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? getUserName = '';
  String? getuserPhone = '';
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  var refreshKey = GlobalKey<RefreshIndicatorState>();

  final Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? mapController;
  BitmapDescriptor? nearbyIcon;
  bool nearbyDriversKeysLoaded = false;
  bool MapLoaded = false;
  Timer? timer;

  /// Custom Map Markers
  Set<Marker> _Markers = {};
  final Set<Circle> _Circles = {};
  late Position currentPosition;

  void setupPositionLocator() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;

    LatLng pos = LatLng(position.latitude, position.longitude);
    CameraPosition cp = CameraPosition(target: pos, zoom: 16);
    mapController?.animateCamera(CameraUpdate.newCameraPosition(cp));

    String address =
        await MainController.findCordinateAddress(position, context);

    // print(address);
    startGeofireListener();
    MapLoaded = true;
  }

  void startGeofireListener() {
    Geofire.initialize('driversAvailable');

    Geofire.queryAtLocation(
            currentPosition.latitude, currentPosition.longitude, 10)
        ?.listen((map) {
      if (map != null) {
        var callBack = map['callBack'];

        switch (callBack) {
          case Geofire.onKeyEntered:
            NearbyDriver nearbyDriver = NearbyDriver();
            nearbyDriver.key = map['key'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];
            FireHelper.nearbyDriverList.add(nearbyDriver);

            if (nearbyDriversKeysLoaded) {
              updateDriversOnMap();
            }
            break;

          case Geofire.onKeyExited:
            FireHelper.removeFromList(map['key']);
            updateDriversOnMap();
            break;

          case Geofire.onKeyMoved:
            // Update your key's location

            NearbyDriver nearbyDriver = NearbyDriver();
            nearbyDriver.key = map['key'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];

            FireHelper.updateNearbyLocation(nearbyDriver);
            updateDriversOnMap();
            break;

          case Geofire.onGeoQueryReady:
            nearbyDriversKeysLoaded = true;
            updateDriversOnMap();
            break;
        }
      }
    });
  }

  void updateDriversOnMap() {
    setState(() {
      _Markers.clear();
    });

    Set<Marker> tempMarkers = <Marker>{};

    for (NearbyDriver driver in FireHelper.nearbyDriverList) {
      var latitude = driver.latitude;
      var longitude = driver.longitude;
      LatLng driverPosition = LatLng(latitude!, longitude!);
      Marker thisMarker = Marker(
        markerId: MarkerId('driver${driver.key}'),
        position: driverPosition,
        // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        icon: nearbyIcon!,
        // rotation: MainController.generateRandomNumber(360),
      );

      tempMarkers.add(thisMarker);
    }

    setState(() {
      _Markers = tempMarkers;
    });
  }

  void createNearByMarker() {
    if (nearbyIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context, size: const Size(2, 2));
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/car_android.png'
                  : 'images/car_android.png')
          .then((icon) {
        nearbyIcon = icon;
      });
    }
  }

  void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final UserRef =
        FirebaseDatabase.instance.ref().child("users").child(userid!);
    UserRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      CurrentUserInfo = UserData.fromSnapshot(DataSnapshot);

      setState(() {
        if (CurrentUserInfo?.fullName.toString() == null) {
          getUserName = UserPreferences.getUsername() ?? '';
        } else {
          getUserName = CurrentUserInfo?.fullName.toString();
          UserPreferences.setUsername(getUserName!);
        }
        if (CurrentUserInfo?.phone.toString() == null) {
          getuserPhone = UserPreferences.getUserPhone() ?? '';
        } else {
          getuserPhone = CurrentUserInfo?.phone.toString();
          UserPreferences.setUserPhone(getuserPhone!);
        }
      });
    });
  }

  //   Initialization
  @override
  void initState() {
    super.initState();
    locationPermision();
    getUserInfo();
    setupPositionLocator();

    // Repeating Function
    // if (!mounted) return;
    // timer = Timer.periodic(
    //   const Duration(seconds: 2),
    //   (Timer t) => setState(() {
    //     getUserInfo();
    //   }),
    // );
  }

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      locationPermision();
      getUserInfo();
      setupPositionLocator();
    });
  }

  @override
  Widget build(BuildContext context) {
    createNearByMarker();
    return RefreshIndicator(
      key: refreshKey,
      onRefresh: refreshList,
      color: Static.secondaryColorSharp,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Static.dashboardBG,
          elevation: 0.0,
          toolbarHeight: 70,
          leadingWidth: 100,
          leading: Row(
            children: [
              Container(
                margin: const EdgeInsets.only(left: 15),
                child: MaterialButton(
                  elevation: 0.0,
                  hoverElevation: 0.0,
                  focusElevation: 0.0,
                  highlightElevation: 0.0,
                  minWidth: 60,
                  height: 60,
                  color: Colors.transparent,
                  onPressed: () {
                    scaffoldKey.currentState?.openDrawer();
                  },
                  shape: const CircleBorder(),
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 0),
                        child: ProfileButtonWithBottomSheet(
                          getUserName: getUserName,
                          getuserPhone: getuserPhone,
                          pageIs: 'home',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: Static.dashboardBG,
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding:
                const EdgeInsets.only(left: 24, top: 10, right: 24, bottom: 20),
            child: Column(
              children: [
                /// Menu Button
                // MenuButton(scaffoldKey: scaffoldKey),
                //
                ///   TOP CONTAINER
                SizedBox(
                  height: 30,
                  width: MediaQuery.of(context).size.width,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Text(
                          'Welcome, ${UserPreferences.getUsername() ?? getUserName}',
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                          softWrap: false,
                          style: const TextStyle(
                              color: Static.primaryColor,
                              fontSize: 23,
                              fontFamily: 'Brand-Bold'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                const BrandDivider(),
                const SizedBox(height: 10),

                ///   2ND CONTAINER
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      MaterialButton(
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Static.dashboardCard,
                        minWidth: 15,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        onPressed: () async {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Mainpage(),
                            ),
                          );
                        },
                        child: SizedBox(
                          width: 120,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Image.asset(
                                'images/uberx.png',
                                height: 60,
                                width: 60,
                              ),
                              const SizedBox(height: 5),
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('New Ride'),
                                  SizedBox(width: 5),
                                  Icon(
                                    Icons.arrow_forward,
                                    size: 18,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Expanded(child: Container()),
                      MaterialButton(
                        elevation: 0.0,
                        hoverElevation: 0.0,
                        focusElevation: 0.0,
                        highlightElevation: 0.0,
                        color: Static.dashboardCard,
                        minWidth: 15,
                        height: 15,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        onPressed: () async {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const RoadAssistent(),
                            ),
                          );
                        },
                        child: SizedBox(
                          width: 120,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              Image.asset(
                                'images/help.png',
                                height: 60,
                                width: 60,
                              ),
                              const SizedBox(height: 5),
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Road Assistent'),
                                  SizedBox(width: 5),
                                  Icon(
                                    Icons.arrow_forward,
                                    size: 18,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                //
                const SizedBox(height: 15),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    MaterialButton(
                      elevation: 0.0,
                      hoverElevation: 0.0,
                      focusElevation: 0.0,
                      highlightElevation: 0.0,
                      color: Static.dashboardCard,
                      minWidth: 15,
                      height: 15,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      onPressed: () async {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const CarRental(),
                          ),
                        );
                      },
                      child: Container(
                        padding: const EdgeInsets.only(bottom: 10, top: 10),
                        width: 110,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            Image.asset(
                              'images/rent.png',
                              height: 60,
                              width: 60,
                            ),
                            const SizedBox(height: 5),
                            const Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('Rent a Car'),
                                SizedBox(width: 5),
                                Icon(
                                  Icons.arrow_forward,
                                  size: 18,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    MaterialButton(
                      elevation: 0.0,
                      hoverElevation: 0.0,
                      focusElevation: 0.0,
                      highlightElevation: 0.0,
                      color: Static.dashboardCard,
                      minWidth: 15,
                      height: 15,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      onPressed: () async {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RentalHistoryPage(),
                          ),
                        );
                      },
                      child: Container(
                        width: 115,
                        padding: const EdgeInsets.only(bottom: 10, top: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          // ignore: prefer_const_literals_to_create_immutables
                          children: [
                            Image.asset(
                              'images/rental.png',
                              height: 60,
                              width: 60,
                            ),
                            const SizedBox(height: 5),
                            const Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('Rental History'),
                                SizedBox(width: 5),
                                Icon(
                                  Icons.arrow_forward,
                                  size: 18,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 15),

                MaterialButton(
                  elevation: 0.0,
                  hoverElevation: 0.0,
                  focusElevation: 0.0,
                  highlightElevation: 0.0,
                  color: Static.dashboardCard,
                  minWidth: 15,
                  height: 15,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const Mainpage(),
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(13),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.search_sharp,
                                size: 30,
                              ),
                            ],
                          ),
                          SizedBox(width: 10),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'Where to?',
                                style: TextStyle(fontSize: 20),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        // ignore: prefer_const_literals_to_create_immutables
                        children: [
                          SizedBox(height: 5),
                          Text(
                            'Nearby Drivers',
                            style: TextStyle(
                              fontSize: 18,
                              fontFamily: 'Brand-Bold',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 300,
                  child: MapLoaded == true
                      ? Center(
                          child: ClipRRect(
                            borderRadius: const BorderRadius.all(
                              Radius.circular(30),
                            ),
                            child: GoogleMap(
                              markers: _Markers,
                              // circles: _Circles,
                              myLocationButtonEnabled: false,
                              myLocationEnabled: false,
                              initialCameraPosition: googlePlex,
                              zoomGesturesEnabled: false,
                              zoomControlsEnabled: false,
                              mapToolbarEnabled: false,
                              rotateGesturesEnabled: false,
                              liteModeEnabled: true,
                              scrollGesturesEnabled: false,
                              onMapCreated:
                                  (GoogleMapController controller) async {
                                mapController = controller;
                                controller
                                    .setMapStyle(MainController.mapStyle());
                                setupPositionLocator();
                              },
                            ),
                          ),
                        )
                      : const Center(child: DataLoadedProgress()),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

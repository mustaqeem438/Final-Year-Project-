import 'package:firebase_database/firebase_database.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/views/carDetails.dart';
import 'package:vdrive/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';

class CarRental extends StatefulWidget {
  const CarRental({Key? key}) : super(key: key);
  static const String id = 'CarRental';

  @override
  State<CarRental> createState() => _CarRentalState();
}

class _CarRentalState extends State<CarRental> {
  
  void getDrivers() {
    DatabaseReference driverRef =
        FirebaseDatabase.instance.ref().child('drivers');

    driverRef.once().then((e) async {
      final snapshot = e.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;
      values.forEach((driverId, driverDetails) {
        if (driverDetails.containsKey('vehicle_details')) {
          Map<String, dynamic> vehicleDetails = {
            'driverId': driverId,
            'driverName': driverDetails['fullname'],
            'vehicleColor': driverDetails['vehicle_details']['vehicle_color'],
            'vehicleModel': driverDetails['vehicle_details']['vehicle_model'],
            'vehicleNumber': driverDetails['vehicle_details']['vehicle_number'],
          };
          setState(() {
            vehicleDetailsList.add(vehicleDetails);
            carsListLoaded = true;
            carsDataLoaded = true;
          });
        } else {
          setState(() {
            carsListLoaded = true;
            carsDataLoaded = true;
          });
        }
      });
    });
  }

  @override
  void initState() {
    super.initState();
    if (carsDataLoaded == false && carsListLoaded == false) {
      getDrivers();
    }

    if (carsDataLoaded == true && vehicleDetailsList.isEmpty) {
      getDrivers();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardBG,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: const Text(
          'Rent a Car',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Scaffold(
        backgroundColor: appcolors.dashboardCard,
        body: Padding(
          padding: const EdgeInsets.all(8),
          child: carItems(),
        ),
      ),
    );
  }

  // Pending Orders
  Widget carItems() {
    return carsDataLoaded == true
        ? vehicleDetailsList.isNotEmpty || carsListLoaded == true
            ? vehicleDetailsList.isNotEmpty
                ? ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    separatorBuilder: (BuildContext context, int index) =>
                        const SizedBox(),
                    itemCount: vehicleDetailsList.length,
                    itemBuilder: (context, index) {
                      return carDetails(
                        kServices: vehicleDetailsList[index],
                      );
                    },
                  )
                : const Center(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('No Cars Available'),
                        ],
                      ),
                    ),
                  )
            : const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('No Cars Available'),
                    ],
                  ),
                ),
              )
        : Container(
            color: appcolors.dashboardCard,
            child: const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DataLoadedProgress(),
                  ],
                ),
              ),
            ),
          );
  }

  carDetails({required Map<String, dynamic> kServices}) {
    return detailsModel(kServices: kServices);
  }

//  Service Item Model
  detailsModel({required Map<String, dynamic> kServices}) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: GestureDetector(
        onTap: () {},
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: appcolors.dashboardBG,
            border: Border.all(color: Colors.black12),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 5,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 10,
            ),
            child: Column(
              children: [
                // Image Row
                //      'vehicleColor': driverDetails['vehicle_details']['vehicle_color'],
                // 'vehicleModel': driverDetails['vehicle_details']['vehicle_model'],
                // 'vehicleNumber': driverDetails['vehicle_details']['vehicle_number'],
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const SizedBox(width: 10),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Text(
                            MainController.capitalize(
                                kServices['vehicleColor'] +
                                    ' ' +
                                    kServices['vehicleModel']),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: Colors.black,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Text(
                            kServices['driverName'],
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: Colors.black45,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.call,
                              size: 15,
                              color: Colors.red,
                            ),
                          ],
                        ),
                      ],
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          TextButton(
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  appcolors.colorBackground),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => CarDetails(
                                    driverid: kServices['driverId'],
                                  ),
                                ),
                              );
                            },
                            child: const Text(
                              'Book Now',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontFamily: 'Roboto-Regular',
                                color: Colors.black,
                                // color: appcolors.secondaryColorSharp,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

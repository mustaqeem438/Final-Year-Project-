import 'dart:ui';
import 'package:vdrive/statics.dart' as Static;
import 'package:vdrive/views/onboarding/pages/boarding/model/onboard_page_model.dart';

List<OnboardPageModel> onboardData = [
  OnboardPageModel(
    Color.fromARGB(255, 255, 255, 255),
    Static.secondaryColorSharp,
    Color.fromARGB(255, 34, 43, 69),
    2,
    'images/boarding_01.gif',
    'Welcome to FARE',
    '',
    'Fare is helping you reach work at rates cheaper than a rickshaw etc, Fare can do it all and more. Ride Fairly.',
  ),
  OnboardPageModel(
    Color.fromARGB(255, 255, 255, 255),
    Color.fromARGB(255, 0, 148, 247),
    Color.fromARGB(255, 34, 43, 69),
    1,
    'images/boarding_04.gif',
    'Get cashback',
    '',
    'Pay your partner using wallet and earn incredible cashbacks in your wallet instantly.',
  ),
  OnboardPageModel(
    Color.fromARGB(255, 255, 255, 255),
    Color.fromARGB(255, 222, 193, 89),
    Color.fromARGB(255, 34, 43, 69),
    2,
    'images/boarding_02.gif',
    'Track your driver',
    '',
    'No More Wait! because FARE uses The GPS in your phone to track you’re driver’s realtime location.',
  ),

  OnboardPageModel(
    Color.fromARGB(255, 255, 255, 255),
    Color(0xFF39393A),
    Color.fromARGB(255, 34, 43, 69),
    0,
    'images/boarding_03.gif',
    'Enjoy your ride',
    '',
    'Enjoy your Fair ride with FARE, Find information about how to take trips with the FARE app, ',
  ),

  //  OnboardPageModel(
  //   Color.fromARGB(255, 255, 255, 255),
  //   Color.fromARGB(255, 222, 193, 89),
  //   Color.fromARGB(255, 34, 43, 69),
  //   2,
  //   'images/boarding_02.gif',
  //   'Become Partner & Earn',
  //   '',
  //   'Already have a driver’s licence? Once you’ve obtained a driver’s licence, you’re ready to get started with Fare. ',
  // ),
];

import 'package:firebase_database/firebase_database.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';

class RentalHistoryPage extends StatefulWidget {
  const RentalHistoryPage({Key? key}) : super(key: key);
  static const String id = 'RentalHistoryPage';

  @override
  State<RentalHistoryPage> createState() => _RentalHistoryPageState();
}

class _RentalHistoryPageState extends State<RentalHistoryPage> {
  void getDrivers() {
    DatabaseReference driverRef =
        FirebaseDatabase.instance.ref().child('bookingHistory');

    driverRef.once().then((e) async {
      final snapshot = e.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;
      values.forEach((key, driverDetails) {
        // if (driverDetails.containsKey(CurrentUserInfo!.id)) {
        //   Map<String, dynamic> vehicleDetails = {
        //     'vehicleColor': driverDetails['vehicle_color'],
        //     'ownerName': driverDetails['ownername'],
        //   };
        //   setState(() {
        //     rentalHistoryList.add(vehicleDetails);
        //     rentalHistoryLoaded = true;
        //     rentalDataLoaded = true;
        //   });
        // } else {
        //   setState(() {
        //     rentalHistoryLoaded = true;
        //     rentalDataLoaded = true;
        //   });
        // }

        values.forEach((key, values) {
          print("Booking ID: $key");
          print("Booked by: ${values['bookedby']}");
          print("Booking From: ${values['bookingFrom']}");
          print("Booking Till: ${values['bookingTill']}");
          print("Car Owner: ${values['carowner']}");
          print("Created Date: ${values['createdDate']}");
          print("Created Time: ${values['createdTime']}");
          print("Owner Name: ${values['ownername']}");
          print("Owner Phone: ${values['ownerphone']}");
          print("Vehicle Color: ${values['vehicle_color']}");
          print("Vehicle Model: ${values['vehicle_model']}");
          print("\n");
        });
      });
    });
  }

  void fetchDataFromFirebase() {
    DatabaseReference databaseReference =
        FirebaseDatabase.instance.ref().child('bookingHistory');

    databaseReference.once().then((e) async {
      final snapshot = e.snapshot;
      Map<dynamic, dynamic> values = snapshot.value as Map;

      values.forEach((key, values) {
        if (values['bookedby'] == CurrentUserInfo!.id) {
          Map<String, dynamic> vehicleDetails = {
            'vehicleColor': values['vehicle_color'],
            'vehicleModel': values['vehicle_model'],
            'ownerName': values['ownername'],
            'bookingFrom': values['bookingFrom'],
            'bookingTill': values['bookingTill'],
            'status': values['status'],
            'ownerphone': values['ownerphone'],
          };

          setState(() {
            rentalHistoryList.add(vehicleDetails);
            rentalHistoryLoaded = true;
            rentalDataLoaded = true;
          });
        } else {
          setState(() {
            rentalHistoryLoaded = true;
            rentalDataLoaded = true;
          });
        }
      });
    });
  }

  @override
  void initState() {
    super.initState();
    rentalHistoryList.clear();
    if (rentalDataLoaded == false && rentalHistoryLoaded == false) {
      fetchDataFromFirebase();
    }

    if (rentalDataLoaded == true && rentalHistoryList.isEmpty) {
      fetchDataFromFirebase();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardBG,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: const Text(
          'Rental History',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Scaffold(
        backgroundColor: appcolors.dashboardCard,
        body: Padding(
          padding: const EdgeInsets.all(8),
          child: carItems(),
        ),
      ),
    );
  }

  // Pending Orders
  Widget carItems() {
    return rentalDataLoaded == true
        ? rentalHistoryList.isNotEmpty || rentalHistoryLoaded == true
            ? rentalHistoryList.isNotEmpty
                ? ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    separatorBuilder: (BuildContext context, int index) =>
                        const SizedBox(),
                    itemCount: rentalHistoryList.length,
                    itemBuilder: (context, index) {
                      return carDetails(
                        kServices: rentalHistoryList[index],
                      );
                    },
                  )
                : const Center(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('No History Found'),
                        ],
                      ),
                    ),
                  )
            : const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('No History Found'),
                    ],
                  ),
                ),
              )
        : Container(
            color: appcolors.dashboardCard,
            child: const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DataLoadedProgress(),
                  ],
                ),
              ),
            ),
          );
  }

  carDetails({required Map<String, dynamic> kServices}) {
    return detailsModel(kServices: kServices);
  }

//  Service Item Model
  detailsModel({required Map<String, dynamic> kServices}) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: GestureDetector(
        onTap: () {},
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: appcolors.dashboardBG,
            border: Border.all(color: Colors.black12),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 5,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 10,
            ),
            child: Column(
              children: [
                // Image Row
                //      'vehicleColor': driverDetails['vehicle_details']['vehicle_color'],
                // 'vehicleModel': driverDetails['vehicle_details']['vehicle_model'],
                // 'vehicleNumber': driverDetails['vehicle_details']['vehicle_number'],
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const SizedBox(width: 10),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Text(
                            MainController.capitalize(
                                  kServices['vehicleModel'],
                                ) +
                                ' ' +
                                MainController.capitalize(
                                  kServices['vehicleColor'],
                                ),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: Colors.black,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Text(
                            kServices['ownerName'],
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: Colors.black45,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .4,
                          child: Row(
                            children: [
                              const Icon(
                                Icons.phone,
                                size: 17,
                                color: Colors.red,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                kServices['ownerphone'],
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontFamily: 'Roboto-Regular',
                                  color: Colors.black45,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              kServices['bookingFrom'] +
                                  ' - ' +
                                  kServices['bookingTill'],
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontFamily: 'Roboto-Regular',
                                color: Colors.black45,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const SizedBox(height: 20),
                          Text(
                            kServices['status'],
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: kServices['status'] == 'Pending'
                                  ? Colors.red
                                  : Colors.green,
                              // color: appcolors.secondaryColorSharp,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

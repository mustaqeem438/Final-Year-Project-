import 'package:vdrive/config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vdrive/statics.dart' as Static;

class TermsPage extends StatefulWidget {
  const TermsPage({Key? key}) : super(key: key);
  static const String id = 'terms';

  @override
  State<TermsPage> createState() => _TermsPageState();
}

class _TermsPageState extends State<TermsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Static.dashboardBG,
      appBar: AppBar(
        backgroundColor: Static.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 10,
                horizontal: 24,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Terms & Conditions',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Roboto-Bold',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Welcome to $appName! By using our platform, you agree to the following terms and conditions. Our car rental service includes a driver, and self-driving is not available.',
                    style: const TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 30),
                  //
                  const Text(
                    'When renting a car through our app, rest assured that our drivers are professional, experienced, and fully licensed, guaranteeing a safe and comfortable ride.',
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  // const SizedBox(height: 30),
                  // const Text(
                  //   'Your Responsibilities',
                  //   style: TextStyle(
                  //     fontSize: 18,
                  //     fontWeight: FontWeight.bold,
                  //     fontFamily: 'Roboto-Bold',
                  //   ),
                  //   textAlign: TextAlign.left,
                  // ),
                  const SizedBox(height: 20),
                  const Text(
                    'Please note that our rental service strictly prohibits self-driving to ensure the safety of our customers and compliance with local regulations. We also remind you to treat the rented vehicle with care and respect, and any damage caused by negligence may result in additional charges. Your safety and satisfaction are our top priorities, and we look forward to providing you with a reliable and enjoyable transportation experience.',
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 40),
                  MaterialButton(
                    onPressed: () {
                      setState(() {
                        Navigator.pop(context);
                      });
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 15,
                    ),
                    elevation: 0,
                    highlightElevation: 0,
                    color: Colors.black87,
                    textColor: Colors.white,
                    child: const Text(
                      'Go Back ━━━',
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

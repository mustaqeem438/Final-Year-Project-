import 'dart:async';

import 'package:vdrive/controller/HistoryController.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/models/historyModal.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/views/tabspage.dart';
import 'package:vdrive/widget/DataLoadedProgress.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as appcolors;
import 'package:flutter_svg/flutter_svg.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);
  static const String id = 'HistoryPage';

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  Timer? timer;

  @override
  void initState() {
    super.initState();

    HistoryController.getHistoryInfo(context);

    if (historyDataLoaded == true && historyItemsList.isEmpty) {
      HistoryController.getHistoryInfo(context);
    }

    // Repeating Function
    // timer = Timer.periodic(
    //   repeatTime,
    //   (Timer t) => setState(() {}),
    // );
  }

  @override
  void dispose() {
    super.dispose();
    historyItemsList.clear();
    historyListLoaded = false;
    historyDataLoaded = false;
    timer?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appcolors.dashboardBG,
      appBar: AppBar(
        backgroundColor: appcolors.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const TabsPage()));
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: const Text(
          'History',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: Scaffold(
        backgroundColor: appcolors.dashboardCard,
        body: Padding(
          padding: const EdgeInsets.all(8),
          child: historyItems(),
        ),
      ),
    );
  }

  // Pending Orders
  Widget historyItems() {
    return historyDataLoaded == true
        ? historyItemsList.isNotEmpty || historyListLoaded == true
            ? historyItemsList.isNotEmpty
                ? ListView.separated(
                    separatorBuilder: (BuildContext context, int index) =>
                        const SizedBox(),
                    itemCount: historyItemsList.length,
                    itemBuilder: (context, index) {
                      return HistoryDetails(
                        kServices: historyItemsList[index],
                      );
                    },
                  )
                : const Center(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('No Previous History Found'),
                        ],
                      ),
                    ),
                  )
            : const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('No Previous History Found'),
                    ],
                  ),
                ),
              )
        : Container(
            color: appcolors.dashboardCard,
            child: const Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    DataLoadedProgress(),
                  ],
                ),
              ),
            ),
          );
  }

  // Pending Items
  HistoryDetails({required HistoryModal kServices}) {
    return detailsModel(kServices: kServices);
  }

  //  Service Item Model
  detailsModel({required HistoryModal kServices}) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: GestureDetector(
        onTap: () {
          // Loader.page(
          //     context,
          //     OrderDetailsPage(
          //       reqID: kServices.key,
          //       status: kServices.status,
          //     ));
        },
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            color: appcolors.dashboardBG,
            border: Border.all(color: Colors.black12),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 5,
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 10,
            ),
            child: Column(
              children: [
                // Image Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(width: 10),
                    Column(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * .6,
                          child: Text(
                            kServices.destination!.isEmpty
                                ? kServices.pickup!
                                : kServices.destination!,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Roboto-Regular',
                              color: Colors.black,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Booking Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Estimate Fare:',
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Roboto-Bold',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    Text(
                      kServices.fares!,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Brand-Regular',
                        fontSize: 13,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                // Status Row
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Status: ',
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Roboto-Bold',
                        fontSize: 13,
                      ),
                    ),
                    Text(
                      MainController.capitalize(kServices.status!),
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'Brand-Regular',
                        color: kServices.status == 'Pending' ||
                                kServices.status == 'canceled' ||
                                kServices.status == 'Canceled'
                            ? Colors.red
                            : Colors.green,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

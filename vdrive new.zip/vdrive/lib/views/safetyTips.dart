import 'package:url_launcher/url_launcher.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/views/aboutMore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:vdrive/views/account.dart';
import 'package:vdrive/views/history.dart';
import 'package:vdrive/widget/ProfileButtonWithBottomSheet.dart';

class SafetyTipsPage extends StatefulWidget {
  const SafetyTipsPage({Key? key}) : super(key: key);
  static const String id = 'SafetyTipsPage';

  @override
  State<SafetyTipsPage> createState() => _SafetyTipsPageState();
}

class _SafetyTipsPageState extends State<SafetyTipsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Static.dashboardCard,
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Safety Tips',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Static.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 70,
        leadingWidth: 70,
        leading: IconButton(
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: const Icon(
            FeatherIcons.arrowLeft,
            color: Colors.black,
          ),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 0,
              horizontal: 50,
            ),
            child: Column(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.blue.withOpacity(.2),

                        // backgroundColor:
                        //     Static.secondaryColorSharp.withOpacity(.2),
                        child: const Icon(
                          Icons.health_and_safety_rounded,
                          color: Colors.blue,
                          size: 40,
                        )),
                    const SizedBox(height: 25),
                    const Text(
                      'Safety First: Rules and Guildelines to Keep Everyone Secure',
                      style: TextStyle(
                        fontSize: 14,
                        fontFamily: 'Roboto-Bold',
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Static.dashboardCard,
                    ),
                    child: Column(
                      children: [
                        MaterialButton(
                          elevation: 0.0,
                          highlightElevation: 0.0,
                          onPressed: () {
                            //
                          },
                          padding: const EdgeInsets.all(8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 200,
                                child: Text(
                                  'How to Make Every Ride Safe and Comfortable',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Icon(FeatherIcons.chevronRight),
                            ],
                          ),
                        ),
                        MaterialButton(
                          elevation: 0.0,
                          highlightElevation: 0.0,
                          onPressed: () {
                            //
                          },
                          padding: const EdgeInsets.all(8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 200,
                                child: Text(
                                  'Tips For Riders',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Icon(FeatherIcons.chevronRight),
                            ],
                          ),
                        ),
                        MaterialButton(
                          elevation: 0.0,
                          highlightElevation: 0.0,
                          onPressed: () {
                            //
                          },
                          padding: const EdgeInsets.all(8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 200,
                                child: Text(
                                  'Making Every Ride a Safe Ride',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Icon(FeatherIcons.chevronRight),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

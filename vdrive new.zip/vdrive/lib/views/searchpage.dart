import 'package:vdrive/models/prediction.dart';
import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/controller/requesthelper.dart';
import 'package:vdrive/widget/brandDivider.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:http/http.dart';
import 'package:provider/provider.dart';

import '../models/address.dart';
import '../widget/PredictionTile.dart';
import '../widget/pickupPredictionTile.dart';

var pickupController = TextEditingController();
var destinationController = TextEditingController();

class SearchPage extends StatefulWidget {
  final String placename;
  const SearchPage({Key? key, required this.placename}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  //

  static int counter = 0;

  //
  var focusDestination = FocusNode();
  //
  bool focused = true;

  String get placename => '';

  void setFocus() {
    if (!focused) {
      FocusScope.of(context).requestFocus(focusDestination);
      focused = true;
    }
  }
  //

  List<Prediction> destinationPredicitionList = [];
  List<Prediction> pickupPredicitionList = [];

  void searchPlace(String placeName) async {
    if (placeName.length > 1) {
      var url = Uri.parse(
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=$mapKey&components=country:pk');
      var response = await RequestHelper.getRequest(url);

      if (response == 'Failed') {
        return;
      }

      if (response['status'] == 'OK') {
        var predictionJson = response['predictions'];
        var thisList = (predictionJson as List)
            .map((e) => Prediction.fromJson(e))
            .toList();

        if (!mounted) return;
        setState(() {
          destinationPredicitionList = thisList;
        });
      }
    }
  }

  void pickupPlace(String placeName) async {
    if (placeName.length > 1) {
      var url = Uri.parse(
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=$mapKey&components=country:pk');
      var response = await RequestHelper.getRequest(url);

      if (response == 'Failed') {
        return;
      }

      if (response['status'] == 'OK') {
        var predictionJson = response['predictions'];
        var thisList = (predictionJson as List)
            .map((e) => Prediction.fromJson(e))
            .toList();

        if (!mounted) return;
        setState(() {
          pickupPredicitionList = thisList;
        });
      }
    }
  }

  // dispose it when the widget is unmounted
  @override
  void dispose() {
    // pickupController.dispose();
    // destinationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    setFocus();

    String address = (Provider.of<AppData>(context).pickupAddress != null)
        ? Provider.of<AppData>(context).pickupAddress!.placeName
        : "";
    pickupController.text = address;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 0,
        backgroundColor: Static.primaryColorblue,
        elevation: 0,
        shadowColor: Colors.transparent,
      ),
      body: Column(
        children: <Widget>[
          Container(
            height: 200,
            decoration: const BoxDecoration(
              color: Static.primaryColorblue,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(50),
                bottomRight: Radius.circular(50),
              ),
            ),
            child: Container(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 24, top: 20, right: 24, bottom: 20),
                child: Column(
                  children: <Widget>[
                    const SizedBox(height: 5),
                    //
                    Stack(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child:
                              const Icon(Icons.arrow_back, color: Colors.white),
                        ),
                        const Center(
                          child: Text(
                            'Set Destination',
                            style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Brand-Bold',
                                color: Colors.white),
                          ),
                        )
                      ],
                    ),
                    //
                    const SizedBox(height: 18),

                    Row(
                      children: <Widget>[
                        Image.asset(
                          'images/pickicon.png',
                          width: 20,
                          height: 20,
                        ),
                        const SizedBox(width: 18),
                        //
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(2),
                              child: TextField(
                                onChanged: (value) {
                                  (pickupController.text == '')
                                      ? setState(() {
                                          pickupPredicitionList = [];
                                        })
                                      : pickupPlace(value);
                                },
                                controller: pickupController,
                                decoration: const InputDecoration(
                                    hintText: 'Pickup Location',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                      top: 8,
                                      bottom: 8,
                                    )),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    //
                    const SizedBox(height: 10),
                    //
                    Row(
                      children: <Widget>[
                        Image.asset(
                          'images/desticon.png',
                          width: 20,
                          height: 20,
                        ),
                        const SizedBox(width: 18),
                        //
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(2),
                              child: TextField(
                                onChanged: (value) {
                                  (destinationController.text == '')
                                      ? setState(() {
                                          destinationPredicitionList = [];
                                        })
                                      : searchPlace(value);
                                },
                                focusNode: focusDestination,
                                controller: destinationController,
                                decoration: const InputDecoration(
                                    hintText: 'Where to?',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(
                                      left: 10,
                                      top: 8,
                                      bottom: 8,
                                    )),
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
          //

          Column(
            children: <Widget>[
              (destinationPredicitionList.isNotEmpty)
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 8,
                        horizontal: 16,
                      ),
                      child: SingleChildScrollView(
                        child: ListView.separated(
                          padding: const EdgeInsets.all(0),
                          itemBuilder: (context, index) {
                            return PredicitionTile(
                              prediction: destinationPredicitionList[index],
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) =>
                              const BrandDivider(),
                          itemCount: destinationPredicitionList.length,
                          shrinkWrap: true,
                          physics: const ClampingScrollPhysics(),
                        ),
                      ),
                    )
                  : Container(
                      child: const Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: 10,
                          horizontal: 16,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [],
                        ),
                      ),
                    ),
              //
              //
              ///   Pickup Prediction
              (pickupPredicitionList.isNotEmpty)
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 0,
                        horizontal: 16,
                      ),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            const Text('Select Pickup Point'),
                            const SizedBox(height: 10),
                            ListView.separated(
                              padding: const EdgeInsets.all(0),
                              itemBuilder: (context, index) {
                                return PickupPredicitionTile(
                                  prediction: pickupPredicitionList[index],
                                  placename: '',
                                );
                              },
                              separatorBuilder:
                                  (BuildContext context, int index) =>
                                      const BrandDivider(),
                              itemCount: pickupPredicitionList.length,
                              shrinkWrap: true,
                              physics: const ClampingScrollPhysics(),
                            ),
                          ],
                        ),
                      ),
                    )
                  : Container(
                      child: const Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: 50,
                          horizontal: 16,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [],
                        ),
                      ),
                    ),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:vdrive/config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:vdrive/statics.dart' as Static;

class AboutDetails extends StatefulWidget {
  const AboutDetails({Key? key}) : super(key: key);
  static const String id = 'AboutDetails';

  @override
  State<AboutDetails> createState() => _AboutDetailsState();
}

class _AboutDetailsState extends State<AboutDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Static.dashboardBG,
      appBar: AppBar(
        backgroundColor: Static.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.pop(context);
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 10,
                horizontal: 24,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Who We Are?',
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Roboto-Bold',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    '$appName Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor a sem a ultricies. Fusce ut commodo urna, in suscipit velit. Nam rutrum erat a augue molestie semper. Phasellus porttitor hendrerit mauris non suscipit. Morbi nibh elit, tincidunt a dolor in, malesuada eleifend elit. Aenean sed metus egestas, suscipit libero in, malesuada felis. Nam leo enim, convallis sed porta non.',
                    style: const TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 30),
                  //
                  //
                  const Text(
                    'What We Do?',
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Roboto-Bold',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor a sem a ultricies. Fusce ut commodo urna, in suscipit velit. Nam rutrum erat a augue molestie semper. Phasellus porttitor hendrerit mauris non suscipit. Morbi nibh elit, tincidunt a dolor in, malesuada eleifend elit. Aenean sed metus egestas, suscipit libero in, malesuada felis. Nam leo enim, convallis sed porta non.',
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 30),
                  //
                  //
                  const Text(
                    'How We Do It – Technician ?',
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Roboto-Bold',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'vitae laoreet lacus. Integer tristique mattis imperdiet. Curabitur ut justo sit amet nisl feugiat dictum eget vel enim. Nunc quis metus at lacus feugiat efficitur. Proin mi est, pellentesque vel luctus volutpat, molestie eget ligula. In eleifend, augue at molestie aliquet, augue lacus maximus ex, vel consequat enim lorem facilisis felis. Vestibulum eu neque ac dui fringilla molestie. Duis nisl ante, tincidunt id leo at, sollicitudin vehicula sem.',
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'Roboto-Regular',
                    ),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 40),
                  MaterialButton(
                    onPressed: () {
                      setState(() {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      });
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 15,
                    ),
                    elevation: 0,
                    highlightElevation: 0,
                    color: Colors.black87,
                    textColor: Colors.white,
                    child: const Text(
                      'Go Home ━━━',
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

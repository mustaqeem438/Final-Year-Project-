import 'package:vdrive/models/userdata.dart';
import 'package:vdrive/utils/globalConstants.dart';
import 'package:vdrive/utils/userpreferences.dart';
import 'package:vdrive/views/tabspage.dart';
import 'package:vdrive/widget/DataLoadedProgress.dart';
import 'package:vdrive/widget/ProfileWidget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:flutter_svg/flutter_svg.dart';

class Account extends StatefulWidget {
  const Account({Key? key}) : super(key: key);
  static const String id = 'Account';

  @override
  _AccountState createState() => _AccountState();
}

class _AccountState extends State<Account> with TickerProviderStateMixin {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  final _formKey = GlobalKey<FormState>();
  late TabController _tabController;
  final int _groupValue = 1;
  bool manualAdressExists = false;
  String? getUserName = '';
  String? getuserPhone = '';
  // Text Field Controllers

  late final _nameController = TextEditingController();
  final _phoneController = TextEditingController();

  Future<void> refreshList() async {
    refreshKey.currentState?.show(atTop: false);
    await Future.delayed(const Duration(seconds: 2));
  }

  void getUserInfo() async {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    if (UserPreferences.getUsername() != null &&
        UserPreferences.getUserPhone() != null) {
      _nameController.text = UserPreferences.getUsername() ?? '';
      _phoneController.text = UserPreferences.getUserPhone() ?? '';
    } else {
      final UserRef =
          FirebaseDatabase.instance.ref().child("users").child(userid!);
      UserRef.once().then((e) async {
        final DataSnapshot = e.snapshot;

        CurrentUserInfo = UserData.fromSnapshot(DataSnapshot);
        if (mounted) {
          setState(() {
            if (UserPreferences.getUsername() == null) {
              _nameController.text = CurrentUserInfo!.fullName.toString();
            } else {
              _nameController.text = UserPreferences.getUsername() ?? '';
            }
            if (UserPreferences.getUserPhone() == null) {
              _phoneController.text = CurrentUserInfo!.phone.toString();
            } else {
              _phoneController.text = UserPreferences.getUserPhone() ?? '';
            }
          });
        }
      });
    }
  }

  Future<void> updateProfile() async {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => const Center(
        child: DataLoadedProgress(),
      ),
    );

    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    DatabaseReference profileRef =
        FirebaseDatabase.instance.ref().child('users/$userid');

    await profileRef.update({
      "fullname": _nameController.text.toString(),
    });
    Navigator.pop(context);
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => Center(
        child: Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          backgroundColor: Colors.transparent,
          child: Container(
            margin: const EdgeInsets.all(16.0),
            width: double.infinity,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(4)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Icon(
                    FeatherIcons.check,
                    size: 35,
                    color: Colors.green,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Profile Updated Successfully!',
                    style: TextStyle(fontSize: 15),
                  ),
                  Center(
                      child: TextButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(
                        Colors.black,
                      ),
                      foregroundColor: MaterialStateProperty.all(
                        Colors.white,
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Close'),
                  ))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    getUserInfo();
  }

  @override
  void dispose() {
    super.dispose();
    _nameController.dispose();
    _phoneController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: Static.dashboardCard,
      appBar: AppBar(
        backgroundColor: Static.dashboardBG,
        elevation: 0.0,
        toolbarHeight: 80,
        leadingWidth: 100,
        iconTheme: const IconThemeData(
          color: Colors.black,
        ),
        leading: IconButton(
          splashColor: Colors.transparent,
          onPressed: () {
            setState(() {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const TabsPage()));
            });
          },
          icon: SvgPicture.asset('images/svg_icons/arrowLeft.svg'),
        ),
        centerTitle: true,
        title: const Text(
          'Profile',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            left: leftPadding,
            right: rightPadding,
            bottom: bottomPadding,
            top: topPadding,
          ),
          child: Column(
            children: [
              const SizedBox(height: 30),
              ProfileWidget(
                imagePath: 'images/user_icon.png',
                onClicked: () async {},
              ),
              Container(
                padding: const EdgeInsets.all(10),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 0,
                          vertical: 5,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: TextFormField(
                            controller: _nameController,
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              isDense: true,
                              labelText: 'Name',
                              hintText: 'Enter Full Name',
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please Enter Full Name';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'Phone Number Can Not be Changed!',
                        style: TextStyle(fontSize: 14),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 0,
                          vertical: 5,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: TextFormField(
                            enabled: false,
                            controller: _phoneController,
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              isDense: true,
                              labelText: 'Phone',
                              hintText: 'Enter Phone Number',
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please Enter Phone Number';
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Center(
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width * .6,
                          child: MaterialButton(
                            elevation: 0.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            height: 40,
                            color: Static.primaryColorblue,
                            textColor: Colors.white,
                            disabledColor: Colors.grey,
                            child: const Text('Update Profile'),
                            //
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                //
                                updateProfile();
                              }
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget addressRadio(
      {required String title,
      required int value,
      required bool selected,
      required Function(int?) onChanged}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.black87,
          border: Border.all(color: Colors.black26),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(),
          child: RadioListTile(
            value: value,
            groupValue: _groupValue,
            onChanged: onChanged,
            selected: selected,
            title: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

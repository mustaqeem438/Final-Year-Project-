import 'dart:io';
import 'package:vdrive/models/directiondetails.dart';

import 'package:vdrive/models/nearbydriver.dart';
import 'package:vdrive/provider/appdata.dart';
import 'package:vdrive/config.dart';
import 'package:vdrive/controller/firehelper.dart';
import 'package:vdrive/controller/mainController.dart';
import 'package:vdrive/views/homepage.dart';
import 'package:vdrive/views/searchpage.dart';
import 'package:vdrive/widget/ProfileButtonWithBottomSheet.dart';
import 'package:vdrive/widget/brandDivider.dart';
import 'package:vdrive/widget/progressDialog.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:vdrive/statics.dart' as Static;
import 'package:flutter_feather_icons/flutter_feather_icons.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widget/CollectPaymentDialog.dart';
import '../permissions.dart';
import '../utils/globalConstants.dart';
import '../widget/NoDriverDialog.dart';

class RoadAssistent extends StatefulWidget {
  const RoadAssistent({Key? key}) : super(key: key);

  static const String id = 'RoadAssistent';

  @override
  State<RoadAssistent> createState() => _RoadAssistentState();
}

class _RoadAssistentState extends State<RoadAssistent>
    with TickerProviderStateMixin {
  //
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? mapController;
  double searchSheetHeight = (Platform.isIOS) ? 300 : 300;
  double riderDetailsSheetHeight =
      (Platform.isIOS) ? 300 : 300; // (Platform.isIOS) ? 235 : 260;
  double requestingSheetHeight = 0; // (Platform.isAndroid) ? 195 : 220
  double tripSheetHeight = 0; // (Platform.isAndroid) ? 275 : 300
  double mapBottomPadding = 0;
  int _groupValue = 1;
  String cartype = '';

  //
  Map<PolylineId, Polyline> polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();

  /// Custom Map Markers
  Set<Marker> _Markers = {};
  final Set<Circle> _Circles = {};

  var geoLocator = Geolocator();
  late Position currentPosition;
  DirectionDetails? tripDirectionDetails;

  String appState = 'NORMAL';

  ///   Nearby Riders Variables
  late StreamSubscription<DatabaseEvent> rideSubscription;
  List<NearbyDriver> availableDrivers = [];
  bool nearbyDriversKeysLoaded = false;
  bool isRequestingLocationDetails = false;

  ///   End

  bool resetRide = false;

  DatabaseReference? rideRef;

  BitmapDescriptor? nearbyIcon;
  BitmapDescriptor? destIcon;
  BitmapDescriptor? pickIcon;

  Object? get address => null;

  void setupPositionLocator() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);
    currentPosition = position;

    LatLng pos = LatLng(position.latitude, position.longitude);
    CameraPosition cp = CameraPosition(target: pos, zoom: 16);
    mapController?.animateCamera(CameraUpdate.newCameraPosition(cp));

    String address =
        await MainController.findCordinateAddress(position, context);

    // print(address);
    startGeofireListener();
  }

  void showDetalSheet() async {
    await getDirection();
    //
    setState(() {
      searchSheetHeight = 0;
      riderDetailsSheetHeight = (Platform.isAndroid) ? 290 : 260;
      mapBottomPadding = (Platform.isAndroid) ? 235 : 230;

      resetRide = true;
    });
  }

  showTripSheet() {
    setState(() {
      requestingSheetHeight = 0;
      tripSheetHeight = (Platform.isAndroid) ? 200 : 300;
      mapBottomPadding = (Platform.isAndroid) ? 280 : 270;
    });
  }

  void showRequestingSheet() {
    setState(() {
      riderDetailsSheetHeight = 0;
      requestingSheetHeight = (Platform.isAndroid) ? 235 : 220;
      mapBottomPadding = (Platform.isAndroid) ? 235 : 220;
    });

    createRideRequest();
  }

  void createRideRequest() {
    rideRef = FirebaseDatabase.instance.ref().child('rideRequest').push();

    var pickup = Provider.of<AppData>(context, listen: false).pickupAddress;
    var destination =
        Provider.of<AppData>(context, listen: false).destinationAddress;

    Map pickupMap = {
      'latitude': pickup?.latitude.toString(),
      'longitude': pickup?.longitude.toString(),
    };

    Map destinationMap = {
      'latitude': destination?.latitude.toString(),
      'longitude': destination?.longitude.toString(),
    };

    Map rideMap = {
      'created_at': DateTime.now().toString(),
      'rider_name': CurrentUserInfo?.fullName,
      'rider_phone': CurrentUserInfo?.phone,
      'pickup_address': pickup?.placeName,
      'destination_address': destination?.placeName,
      'location': pickupMap,
      'destination': destinationMap,
      'payment_method': 'card',
      'driver_id': 'waiting',
    };

    rideRef?.set(rideMap);

    rideSubscription = rideRef!.onValue.listen((event) async {
      //check for null snapshot
      if (event.snapshot.value == null) {
        return;
      }

      //get car details
      setState(() {
        driverCarDetails = event.snapshot.child('car_details').value.toString();
      });

      // get driver name
      setState(() {
        driverFullName = event.snapshot.child('driver_name').value.toString();
      });

      // get driver phone number
      if (event.snapshot.child('driver_phone').value != null) {
        setState(() {
          driverPhoneNumber =
              event.snapshot.child('driver_phone').value.toString();
        });
      }

      //get and use driver location updates
      if (event.snapshot.child('driver_location').value != null) {
        double driverLat = double.parse(event.snapshot
            .child('driver_location')
            .child('latitude')
            .value
            .toString());
        double driverLng = double.parse(event.snapshot
            .child('driver_location')
            .child('longitude')
            .value
            .toString());
        LatLng driverLocation = LatLng(driverLat, driverLng);

        if (status == 'accepted') {
          updateToPickup(driverLocation);
        } else if (status == 'ontrip') {
          updateToDestination(driverLocation);
        } else if (status == 'arrived') {
          setState(() {
            tripStatusDisplay = 'Driver has arrived';
          });
        }
      }

      if (event.snapshot.child('status').value != null) {
        status = event.snapshot.child('status').value.toString();
      }

      if (status == 'accepted') {
        showTripSheet();
        Geofire.stopListener();
        removeGeofireMarkers();
      }

      if (status == 'ended') {
        if (event.snapshot.child('fares').value != null) {
          int fares = int.parse(event.snapshot.child('fares').value.toString());

          var response = await showDialog(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) => CollectPayment(
              paymentMethod: 'cash',
              fares: fares,
            ),
          );
          updateHistory();

          if (response == 'close') {
            rideRef?.onDisconnect();
            rideRef = null;
            rideSubscription.cancel();
            resetApp();
          }
        }
      }
    });
  }

  void updateHistory() {
    currentFirebaseUser = FirebaseAuth.instance.currentUser;
    String? userid = currentFirebaseUser?.uid;

    final historyRef = FirebaseDatabase.instance
        .ref()
        .child("users")
        .child(userid!)
        .child('history');
    historyRef.update({'${rideRef!.key}': 'true'});
  }

  void removeGeofireMarkers() {
    setState(() {
      _Markers.removeWhere((m) => m.markerId.value.contains('driver'));
    });
  }

  void updateToPickup(LatLng driverLocation) async {
    if (!isRequestingLocationDetails) {
      isRequestingLocationDetails = true;

      var positionLatLng =
          LatLng(currentPosition.latitude, currentPosition.longitude);

      var thisDetails = await MainController.getDirectionDetails(
          driverLocation, positionLatLng);

      if (thisDetails == null) {
        return;
      }

      setState(() {
        tripStatusDisplay = 'Person is Arriving - ${thisDetails.durationText}';
      });

      isRequestingLocationDetails = false;
    }
  }

  void updateToDestination(LatLng driverLocation) async {
    if (!isRequestingLocationDetails) {
      isRequestingLocationDetails = true;

      var destination =
          Provider.of<AppData>(context, listen: false).destinationAddress;

      var destinationLatLng =
          LatLng(destination!.latitude, destination.longitude);

      var thisDetails = await MainController.getDirectionDetails(
          driverLocation, destinationLatLng);

      if (thisDetails == null) {
        return;
      }

      setState(() {
        tripStatusDisplay =
            'Driving to Destination - ${thisDetails.durationText}';
      });

      isRequestingLocationDetails = false;
    }
  }

  void cancelRequest() {
    rideRef?.remove();

    setState(() {
      appState = 'NORMAL';
    });
  }

  void resetApp() {
    setState(() {
      polylineCoordinates.clear();
      polylines.clear();
      _Markers.clear();
      _Circles.clear();
      riderDetailsSheetHeight = (Platform.isAndroid) ? 300 : 300;
      requestingSheetHeight = 0;
      tripSheetHeight = 0;
      searchSheetHeight = (Platform.isAndroid) ? 300 : 300;
      mapBottomPadding = (Platform.isAndroid) ? 160 : 220;

      status = '';
      driverFullName = '';
      driverPhoneNumber = '';
      driverCarDetails = '';
      tripStatusDisplay = 'Driver is Arriving';
    });
    setupPositionLocator();
  }

  void startGeofireListener() {
    Geofire.initialize('driversAvailable');
    Geofire.queryAtLocation(
            currentPosition.latitude, currentPosition.longitude, 10)
        ?.listen((map) {
      if (map != null) {
        var callBack = map['callBack'];

        switch (callBack) {
          case Geofire.onKeyEntered:
            NearbyDriver nearbyDriver = NearbyDriver();
            nearbyDriver.key = map['key'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];
            nearbyDriver.fullname = map['fullname'];

            FireHelper.nearbyDriverList.add(nearbyDriver);

            if (nearbyDriversKeysLoaded) {
              updateDriversOnMap();
            }
            break;

          case Geofire.onKeyExited:
            FireHelper.removeFromList(map['key']);
            updateDriversOnMap();
            break;

          case Geofire.onKeyMoved:
            // Update your key's location

            NearbyDriver nearbyDriver = NearbyDriver();
            nearbyDriver.key = map['key'];
            nearbyDriver.fullname = map['fullname'];
            nearbyDriver.latitude = map['latitude'];
            nearbyDriver.longitude = map['longitude'];

            FireHelper.updateNearbyLocation(nearbyDriver);
            updateDriversOnMap();
            break;

          case Geofire.onGeoQueryReady:
            nearbyDriversKeysLoaded = true;
            updateDriversOnMap();
            break;
        }
      }
    });
  }

  void updateDriversOnMap() {
    setState(() {
      _Markers.clear();
    });

    Set<Marker> tempMarkers = <Marker>{};

    for (NearbyDriver driver in FireHelper.nearbyDriverList) {
      var latitude = driver.latitude;
      var longitude = driver.longitude;
      print('Driver name is ${driver.fullname}');
      LatLng driverPosition = LatLng(latitude!, longitude!);
      Marker thisMarker = Marker(
        markerId: MarkerId('driver${driver.key}'),
        position: driverPosition,
        // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        icon: nearbyIcon!,
        // rotation: MainController.generateRandomNumber(360),
      );

      tempMarkers.add(thisMarker);
    }

    setState(() {
      _Markers = tempMarkers;
    });
  }

  void createMarker() {
    if (nearbyIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context);
      BitmapDescriptor.fromAssetImage(imageConfiguration,
              (Platform.isIOS) ? 'images/taxi.png' : 'images/taxi.png')
          .then((icon) {
        nearbyIcon = icon;
      });
    }
  }

  void destinationMarker() {
    if (destIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context);
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/desticon-black.png'
                  : 'images/desticon-black.png')
          .then((icon) {
        destIcon = icon;
      });
    }
  }

  void pickupMarker() {
    if (pickIcon == null) {
      ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context);
      BitmapDescriptor.fromAssetImage(
              imageConfiguration,
              (Platform.isIOS)
                  ? 'images/pickicon-black.png'
                  : 'images/pickicon-black.png')
          .then((icon) {
        pickIcon = icon;
      });
    }
  }

// Find Nearby Drivers

  void noDriverFound() {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => NoDriverDialog());
  }

  void findDriver() {
    if (availableDrivers.isEmpty) {
      cancelRequest();
      resetApp();
      noDriverFound();
      return;
    }

    var driver = availableDrivers[0];

    notifyDriver(driver);

    availableDrivers.removeAt(0);

    print('driver key ${driver.key}');
  }

  void notifyDriver(NearbyDriver driver) {
    DatabaseReference driverTripRef =
        FirebaseDatabase.instance.ref().child('drivers/${driver.key}/newtrip');
    driverTripRef.set(rideRef?.key);

    // Get and notify driver using token
    DatabaseReference tokenRef =
        FirebaseDatabase.instance.ref().child('drivers/${driver.key}/token');

    tokenRef.once().then((e) async {
      final DataSnapshot = e.snapshot;

      if (DataSnapshot != null) {
        var token = DataSnapshot.value.toString();

        print('key tokan $token');

        // send notification to selected driver
        MainController.sendNotification(
            token, context, rideRef?.key, 'New Help Request', 'help');
      } else {
        return;
      }

      const oneSecTick = Duration(seconds: 1);

      var timer = Timer.periodic(oneSecTick, (timer) {
        // stop timer when ride request is cancelled;
        if (appState != 'SENDING REQUEST') {
          driverTripRef.set('cancelled');
          driverTripRef.onDisconnect();
          timer.cancel();
          driverRequestTimeout = 30;
        }

        driverRequestTimeout--;

        // a value event listener for driver accepting trip request
        driverTripRef.onValue.listen((event) {
          // confirms that driver has clicked accepted for the new trip request
          if (event.snapshot.value.toString() == 'accepted') {
            driverTripRef.onDisconnect();
            timer.cancel();
            driverRequestTimeout = 30;
          }
        });

        if (driverRequestTimeout == 0) {
          //informs driver that ride has timed out
          driverTripRef.set('timeout');
          driverTripRef.onDisconnect();
          driverRequestTimeout = 30;
          timer.cancel();

          //select the next closest driver
          findDriver();
        }
      });
    });
  }

  ///   Initialization
  @override
  void initState() {
    super.initState();
    locationPermision();
    MainController.getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    createMarker();
    pickupMarker();
    destinationMarker();

    String address = (Provider.of<AppData>(context).pickupAddress != null)
        ? Provider.of<AppData>(context).pickupAddress!.placeName
        : "";
    pickupController.text = address;

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: const Color(0xffe2e7ef),
      body: Stack(
        children: <Widget>[
          GoogleMap(
            padding: EdgeInsets.only(bottom: mapBottomPadding),
            polylines: Set<Polyline>.of(polylines.values),
            markers: _Markers,
            circles: _Circles,
            myLocationButtonEnabled: false,
            initialCameraPosition: googlePlex,
            myLocationEnabled: true,
            liteModeEnabled: true,
            scrollGesturesEnabled: false,
            zoomGesturesEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            rotateGesturesEnabled: false,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
              mapController = controller;
              controller.setMapStyle(MainController.mapStyle());

              setState(() {
                mapBottomPadding = 160;
              });
              setupPositionLocator();
            },
          ),
          //
          //
          ///   SearchSheet

          //  Ride Details Sheet
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: AnimatedSize(
              // vsync: this,
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeIn,
              child: SizedBox(
                height: riderDetailsSheetHeight,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 25,
                  ),
                  child: Column(
                    children: <Widget>[
                      //
                      //
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                              50.0,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                decoration: BoxDecoration(
                                  color: Static.primaryColorblue,
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 18,
                                    vertical: 12,
                                  ),
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        width: double.infinity,
                                        child: carRadio(
                                          image: 'taxi.png',
                                          fare: (tripDirectionDetails != null)
                                              ? '$currency${MainController.estimateFaresCar(tripDirectionDetails!)}'
                                              : currency! + '250',
                                          selected: true,
                                          background: Static.primaryColorblue,
                                          title: 'Car',
                                          value: 1,
                                          onChanged: (status) {
                                            setState(() {
                                              _groupValue = 2;
                                              cartype = 'car';
                                            });
                                          },
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 16),
                                        child: Row(
                                          // ignore: prefer_const_literals_to_create_immutable
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            const Row(
                                              children: [
                                                Icon(
                                                  FontAwesomeIcons.creditCard,
                                                  size: 20,
                                                  color: Colors.white,
                                                ),
                                                SizedBox(width: 16),
                                                Text(
                                                  'Cash',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(width: 0),
                                            SizedBox(
                                              width: 220,
                                              child: Text(
                                                pickupController.text,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                    fontSize: 16,
                                                    color: Colors.white),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      //
                      const SizedBox(height: 30),
                      //
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          children: <Widget>[
                            Column(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    // resetApp();
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const HomePage(),
                                      ),
                                    );
                                  },
                                  child: const CircleAvatar(
                                    backgroundColor: Static.primaryColorblue,
                                    radius: 30,
                                    child: Icon(
                                      FeatherIcons.arrowLeft,
                                      size: 35,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            //
                            Expanded(child: Container()),
                            //
                            GestureDetector(
                              onTap: () {
                                setState(() {
                                  appState = 'SENDING REQUEST';
                                });
                                showRequestingSheet();

                                availableDrivers = FireHelper.nearbyDriverList;

                                findDriver();
                              },
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Static.primaryColorblue,
                                          borderRadius:
                                              BorderRadius.circular(50),
                                        ),
                                        child: const Row(
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                vertical: 16,
                                                horizontal: 30,
                                              ),
                                              child: Text(
                                                'SEND REQUEST',
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                            CircleAvatar(
                                              backgroundColor:
                                                  Static.primaryColorblue,
                                              radius: 30,
                                              child: Icon(
                                                FeatherIcons.arrowRight,
                                                size: 35,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      //
                    ],
                  ),
                ),
                //
              ),
            ),
          ),
          //
          //
          //  Ride Request Sheet
          Positioned(
            left: 0,
            bottom: 0,
            right: 0,
            child: AnimatedSize(
              // vsync: this,
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeIn,
              child: Container(
                height: requestingSheetHeight,
                decoration: const BoxDecoration(
                  color: Color.fromARGB(255, 242, 249, 252),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    const SizedBox(height: 10),
                    Column(
                      children: [
                        Image.asset(
                          'images/bikeloading2.gif',
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'Requesting for help...',
                          style: TextStyle(
                            color: Static.primaryColorblue,
                            fontSize: 20,
                            fontFamily: 'Brand-Bold',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    GestureDetector(
                      onTap: () {
                        cancelRequest();
                        resetApp();
                      },
                      child: Column(children: <Widget>[
                        Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 242, 249, 252),
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                              width: 1.0,
                              color: Static.colorLightGrayFair,
                            ),
                          ),
                          child: const Icon(
                            Icons.close,
                            size: 25,
                            color: Static.primaryColorblue,
                          ),
                        ),
                        //
                        const SizedBox(height: 10),
                        //
                        const SizedBox(
                          width: double.infinity,
                          child: Text(
                            'Cancel Request',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              color: Static.primaryColorblue,
                            ),
                          ),
                        ),
                      ]),
                    ),
                    //
                  ],
                ),
              ),
            ),
          ),
          //

          /// Trip Sheet
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: AnimatedSize(
              // vsync: this,
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeIn,
              child: Container(
                decoration: const BoxDecoration(
                  color: Static.primaryColorblue,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 15.0, // soften the shadow
                      spreadRadius: 0.5, //extend the shadow
                      offset: Offset(
                        0.7, // Move to right 10  horizontally
                        0.7, // Move to bottom 10 Vertically
                      ),
                    )
                  ],
                ),
                height: tripSheetHeight,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            tripStatusDisplay,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontFamily: 'Brand-Bold'),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const BrandDivider(),
                      const SizedBox(
                        height: 20,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                driverCarDetails == ''
                                    ? ''
                                    : MainController.capitalize(
                                        driverCarDetails),
                                style: const TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                driverFullName,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 20),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () {
                                  launchUrl(
                                      Uri.parse("tel://$driverPhoneNumber"));
                                },
                                child: Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular((25))),
                                    border: Border.all(
                                      width: 1.0,
                                      color: Colors.white,
                                    ),
                                  ),
                                  child: const Icon(
                                    Icons.call,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                'Call',
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget carRadio(
      {required String title,
      required int value,
      required String fare,
      required String image,
      required bool selected,
      required Color background,
      required Function(int?) onChanged}) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: background,
        ),
        child: Theme(
          data: Theme.of(context).copyWith(),
          child: RadioListTile(
            value: value,
            groupValue: _groupValue,
            onChanged: onChanged,
            selected: selected,
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  'images/$image',
                  height: 45,
                  width: 45,
                ),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                  ),
                ),
                Text(
                  fare,
                  style: const TextStyle(
                      fontSize: 18,
                      fontFamily: 'Brand-Bold',
                      color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _addPolyLine() {
    PolylineId id = const PolylineId("poly");
    Polyline polyline = Polyline(
      polylineId: id,
      color: Static.primaryColor,
      width: 3,
      jointType: JointType.round,
      points: polylineCoordinates,
      startCap: Cap.roundCap,
      endCap: Cap.roundCap,
      geodesic: true,
    );
    polylines[id] = polyline;
    setState(() {});
  }

  Future<void> getDirection() async {
    var pickupLocation =
        Provider.of<AppData>(context, listen: false).pickupAddress;
    var destination =
        Provider.of<AppData>(context, listen: false).destinationAddress;

    var pickLatLng = LatLng(pickupLocation!.latitude, pickupLocation.longitude);
    var destinationLatLng =
        LatLng(destination!.latitude, destination.longitude);

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) => ProgressDialog(
        status: 'Finding Route...',
      ),
    );

    var thisDetails =
        await MainController.getDirectionDetails(pickLatLng, destinationLatLng);

    setState(() {
      tripDirectionDetails = thisDetails;
    });

    Navigator.pop(context);

    PolylinePoints polylinePoints = PolylinePoints();

    polylineCoordinates.clear();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        mapKey,
        PointLatLng(pickupLocation.latitude, pickupLocation.longitude),
        PointLatLng(destination.latitude, destination.longitude),
        travelMode: TravelMode.driving);
    if (result.points.isNotEmpty) {
      for (var point in result.points) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      }
    }
    polylines.clear();

    _addPolyLine();

    LatLngBounds bounds;

    if (pickLatLng.latitude > destinationLatLng.latitude &&
        pickLatLng.longitude > destinationLatLng.longitude) {
      bounds =
          LatLngBounds(southwest: destinationLatLng, northeast: pickLatLng);
    } else if (pickLatLng.longitude > destinationLatLng.longitude) {
      bounds = LatLngBounds(
          southwest: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
          northeast: LatLng(destinationLatLng.latitude, pickLatLng.longitude));
    } else if (pickLatLng.latitude > destinationLatLng.latitude) {
      bounds = LatLngBounds(
        southwest: LatLng(destinationLatLng.latitude, pickLatLng.longitude),
        northeast: LatLng(pickLatLng.latitude, destinationLatLng.longitude),
      );
    } else {
      bounds =
          LatLngBounds(southwest: pickLatLng, northeast: destinationLatLng);
    }

    mapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 70));

    setState(() {
      _Markers.clear();
    });

    Set<Marker> tempPDMarkers = <Marker>{};

    Marker pickupMarker = Marker(
      markerId: const MarkerId('pickup'),
      position: pickLatLng,
      icon: pickIcon!,
      infoWindow:
          InfoWindow(title: pickupLocation.placeName, snippet: 'My Location'),
    );

    Marker destinationMarker = Marker(
      markerId: const MarkerId('destination'),
      position: destinationLatLng,
      // icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      icon: destIcon!,
      infoWindow:
          InfoWindow(title: destination.placeName, snippet: 'Destination'),
    );

    setState(() {
      tempPDMarkers.add(pickupMarker);
      tempPDMarkers.add(destinationMarker);
      _Markers = tempPDMarkers;
    });

    setState(() {
      _Markers.add(pickupMarker);
      _Markers.add(destinationMarker);
    });

    Circle pickupCircle = Circle(
      circleId: const CircleId('pickup'),
      strokeColor: Static.primaryColorblue,
      strokeWidth: 3,
      radius: 12,
      center: pickLatLng,
      fillColor: Static.primaryColorblue,
    );

    Circle destinationCircle = Circle(
      circleId: const CircleId('destination'),
      strokeColor: Static.primaryColorblue,
      strokeWidth: 3,
      radius: 12,
      center: destinationLatLng,
      fillColor: Static.primaryColorblue,
    );

    setState(() {
      _Circles.add(pickupCircle);
      _Circles.add(destinationCircle);
    });
  }
}

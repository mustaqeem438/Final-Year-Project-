import 'package:shared_preferences/shared_preferences.dart';

class UserPreferences {
  static SharedPreferences? _preferences;

  static const _keyUsername = 'username';
  static const _keyPhone = 'phone';
  static const _keyEmail = 'email';

  static Future init() async =>
      _preferences = await SharedPreferences.getInstance();

  static Future setUsername(String username) async =>
      await _preferences?.setString(_keyUsername, username);

  static String? getUsername() => _preferences?.getString(_keyUsername);


  
  static Future setUserPhone(String phone) async =>
      await _preferences?.setString(_keyPhone, phone);

  static String? getUserPhone() => _preferences?.getString(_keyPhone);


  
  
  static Future setUserEmail(String email) async =>
      await _preferences?.setString(_keyEmail, email);

  static String? getUserEmail() => _preferences?.getString(_keyEmail);
}

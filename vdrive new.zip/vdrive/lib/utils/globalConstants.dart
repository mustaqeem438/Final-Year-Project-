import 'package:vdrive/models/cars.dart';
import 'package:vdrive/models/historyModal.dart';
import 'package:vdrive/models/userdata.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

// App Padding
double leftPadding = 13;
double rightPadding = 13;
double topPadding = 0;
double bottomPadding = 0;

// Default Google Maps Camera Position
CameraPosition googlePlex = const CameraPosition(
  target: LatLng(24.860966, 66.990501),
  zoom: 14.4746,
);

// Get Firebase User
User? currentFirebaseUser;

// Current Firebase User Data
UserData? CurrentUserInfo;
Cars? carInfo;

// Get User RealTime Details
String? getUserName = '';
String? getuserPhone = '';

// ===========================
//      Ride Constants
// ===========================
int driverRequestTimeout = 30;
String status = '';
String driverCarDetails = '';
String driverFullName = '';
String? driverPhoneNumber;
String tripStatusDisplay = 'Driver is Arriving';

// Global Durations
const repeatTime = Duration(seconds: 2); // Function Repeater
const pageLoadAnimation = Duration(milliseconds: 150); // Page Loading

//  History Data Loading
bool historyListLoaded = false;
bool historyDataLoaded = false;
List<HistoryModal> historyItemsList = [];
// Details
bool orderDetailsDataLoaded = false;
bool orderDetailsListLoaded = false;
List<HistoryModal> orderDetailsItemsList = [];

//  Cars Data Loading
List<Map<String, dynamic>> vehicleDetailsList = [];
bool carsListLoaded = false;
bool carsDataLoaded = false;

List<Map<String, dynamic>> rentalHistoryList = [];

bool rentalHistoryLoaded = false;
bool rentalDataLoaded = false;

import 'package:firebase_database/firebase_database.dart';

class UserData {
  String? fullName;
  String? email;
  String? phone;
  String? id;

  UserData({
    this.fullName = '',
    this.email = '',
    this.phone = '',
    this.id = '',
  });

  UserData.fromSnapshot(DataSnapshot snapshot) {
    id = snapshot.key;
    email = snapshot.child('email').value.toString();
    phone = snapshot.child('phone').value.toString();
    fullName = snapshot.child('fullname').value.toString();
  }
}

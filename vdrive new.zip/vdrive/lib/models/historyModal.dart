import 'package:firebase_database/firebase_database.dart';

class HistoryModal{
  String? pickup;
  String? destination;
  String? fares;
  String? status;
  String? createdAt;
  String? paymentMethod;


  HistoryModal({
    required this.pickup,
    required this.destination,
    required this.fares,
    required this.status,
    required this.createdAt,
    required this.paymentMethod,
  });

  HistoryModal.fromSnapshot(DataSnapshot snapshot) {
    pickup = snapshot.child('pickup_address').value.toString();
    destination = snapshot.child('destination_address').value.toString();
    fares = snapshot.child('fares').value.toString();
    createdAt = snapshot.child('created_at').value.toString();
    status = snapshot.child('status').value.toString();
    paymentMethod = snapshot.child('payment_method').value.toString();
  }
}

class DirectionDetails {
  String distanceText;
  String durationText;
  int distanceValue;
  int durationValue;
  String encodedPoints;

  DirectionDetails({
    this.distanceText = '',
    this.durationText = '',
    this.distanceValue = 0,
    this.durationValue = 0,
    this.encodedPoints = '',
  });
}

import 'package:firebase_database/firebase_database.dart';

class Cars {
  String? key;
  String? vehicle_color;
  String? vehicle_model;

  Cars({
    required this.key,
    required this.vehicle_color,
    required this.vehicle_model,
  });

  
  Cars.fromSnapshot(DataSnapshot snapshot) {
    vehicle_color = snapshot.child('vehicle_color').value.toString();
    vehicle_model = snapshot.child('vehicle_model').value.toString();
  }
}


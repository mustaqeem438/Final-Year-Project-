class NearbyDriver{
  String? key;
  String? fullname;
  double? latitude;
  double? longitude;

  NearbyDriver({
    this.key,
    this.fullname,
    this.latitude,
    this.longitude,
});

}